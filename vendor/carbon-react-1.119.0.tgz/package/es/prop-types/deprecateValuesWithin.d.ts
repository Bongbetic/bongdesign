/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { Requireable, Validator } from 'prop-types';
export declare const deprecateValuesWithin: <T>(propType: Requireable<T>, allowedValues?: readonly unknown[], propMappingFunction?: (deprecatedValue: T) => T) => Validator<T> | Requireable<T>;
