/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
type PropValidator = (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
/**
 * Wraps a prop-type validator with a deprecation warning.
 *
 * @param propType - The original prop validator function.
 * @param message - Deprecation message.
 * @returns A new validator function that emits a warning the first time a
 *          deprecated prop is used.
 */
export declare const deprecate: (propType: PropValidator, message?: string) => PropValidator;
export {};
