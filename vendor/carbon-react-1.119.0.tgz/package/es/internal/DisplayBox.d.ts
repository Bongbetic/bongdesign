/**
 * Copyright IBM Corp. 2022, 2022
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ReactNode } from 'react';
interface DisplayBoxProps {
    children?: ReactNode;
    className?: string;
    msg?: ReactNode;
}
export declare const DisplayBox: ({ children, className, msg }: DisplayBoxProps) => import("react/jsx-runtime").JSX.Element;
export {};
