/**
 * used to calculate if a element is overflowing the width or height of an area
 */
export declare const checkWidthOverflow: (el: HTMLElement | null) => boolean;
export declare const checkHeightOverflow: (el: HTMLElement | null) => boolean;
