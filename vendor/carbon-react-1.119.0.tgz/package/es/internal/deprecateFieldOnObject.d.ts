/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const deprecateFieldOnObject: <T extends {
    displayName?: string;
}>(object: T, field: string, Component: {
    displayName?: string;
    name?: string;
}, message?: string) => void;
