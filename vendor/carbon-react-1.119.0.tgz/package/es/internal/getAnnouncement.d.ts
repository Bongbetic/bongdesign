/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { TFunc } from '../types/common';
interface AnnouncementTranslationArgs {
    count: number;
    maxCount: number;
}
/** Returns an announcement message when the remaining count is low. */
export declare const getAnnouncement: <TranslationKey extends string>(count: number, maxCount: number | undefined, translationIds: {
    remaining: TranslationKey;
    maxReached: TranslationKey;
}, t: TFunc<TranslationKey, AnnouncementTranslationArgs>) => string | null;
export {};
