/**
 * Copyright IBM Corp. 2023, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { IconButton } from '../IconButton';
import Button from '../Button';
import { Menu } from '../Menu';
import { MenuAlignment } from '../MenuButton';
import type { TranslateWithId } from '../../types/common';
declare const translationIds: {
    readonly 'carbon.combo-button.additional-actions': "carbon.combo-button.additional-actions";
};
type TranslationKey = keyof typeof translationIds;
interface ComboButtonProps extends TranslateWithId<TranslationKey> {
    /**
     * A collection of `MenuItems` to be rendered as additional actions for this `ComboButton`.
     */
    children: React.ComponentProps<typeof Menu>['children'];
    /**
     * Additional CSS class names.
     */
    className?: string;
    /**
     * Specify whether the `ComboButton` should be disabled, or not.
     */
    disabled?: boolean;
    /**
     * Provide the label to be rendered on the primary action button.
     */
    label: React.ComponentProps<typeof Button>['title'];
    /**
     * Experimental property. Specify how the menu should align with the button element
     */
    menuAlignment?: MenuAlignment;
    /**
     * Provide an optional function to be called when the primary action element is clicked.
     */
    onClick?: React.ComponentProps<typeof Button>['onClick'];
    /**
     * Specify the size of the buttons and menu.
     */
    size?: 'xs' | 'sm' | 'md' | 'lg';
    /**
     * Specify how the trigger tooltip should be aligned.
     */
    tooltipAlignment?: React.ComponentProps<typeof IconButton>['align'];
}
declare const ComboButton: React.ForwardRefExoticComponent<ComboButtonProps & React.RefAttributes<HTMLDivElement>>;
export { ComboButton, type ComboButtonProps };
