/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { PropsWithChildren, ReactNode } from 'react';
export type IdPrefixProps = {
    children?: ReactNode;
    /**
     * The value used to prefix the auto-generated id placed on some DOM elements
     */
    prefix?: string;
};
declare function IdPrefix({ children, prefix }: PropsWithChildren<IdPrefixProps>): import("react/jsx-runtime").JSX.Element;
declare namespace IdPrefix {
    var propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * The value used to prefix the auto-generated id placed on some DOM elements
         */
        prefix: PropTypes.Requireable<string>;
    };
}
export { IdPrefix };
