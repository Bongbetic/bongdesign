/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { PropsWithChildren } from 'react';
export interface ClassPrefixProps {
    /**
     *   The value used to prefix the CSS selectors
     *   used by Carbon components.
     */
    prefix: string;
}
declare function ClassPrefix({ children, prefix, }: PropsWithChildren<ClassPrefixProps>): import("react/jsx-runtime").JSX.Element;
declare namespace ClassPrefix {
    var propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * The value used to prefix the CSS selectors used by Carbon components
         */
        prefix: PropTypes.Validator<string>;
    };
}
export { ClassPrefix };
