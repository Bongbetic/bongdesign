/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type HTMLAttributes } from 'react';
export interface FormGroupProps extends HTMLAttributes<HTMLFieldSetElement> {
    /**
     * Provide the children form elements to be rendered inside of the <fieldset>
     */
    children: React.ReactNode;
    /**
     * Provide a custom className to be applied to the containing <fieldset> node
     */
    className?: string;
    /**
     * Specify whether the FormGroup should be disabled
     */
    disabled?: boolean;
    /**
     * Specify whether the <FormGroup> is invalid
     */
    invalid?: boolean;
    /**
     * Provide id for the fieldset <legend> which corresponds to the fieldset
     * `aria-labelledby`
     */
    legendId?: string;
    /**
     * Provide the text to be rendered inside of the fieldset <legend>
     */
    legendText: React.ReactNode;
    /**
     * Specify whether the message should be displayed in the <FormGroup>
     */
    message?: boolean;
    /**
     * Provide the text for the message in the <FormGroup>
     */
    messageText?: string;
}
declare const FormGroup: {
    ({ disabled, legendId, legendText, invalid, children, className, message, messageText, ...rest }: FormGroupProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Provide the children form elements to be rendered inside of the <fieldset>
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom className to be applied to the containing <fieldset> node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether the FormGroup should be disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Specify whether the <FormGroup> is invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Provide id for the fieldset <legend> which corresponds to the fieldset
         * `aria-labelledby`
         */
        legendId: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide the text to be rendered inside of the fieldset <legend>
         */
        legendText: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Specify whether the message should be displayed in the <FormGroup>
         */
        message: PropTypes.Requireable<boolean>;
        /**
         * Provide the text for the message in the <FormGroup>
         */
        messageText: PropTypes.Requireable<string>;
    };
};
export default FormGroup;
