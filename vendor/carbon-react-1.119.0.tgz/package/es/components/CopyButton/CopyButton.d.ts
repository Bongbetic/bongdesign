/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { MouseEventHandler } from 'react';
import { ButtonProps } from '../Button';
import type { DeprecatedPopoverAlignment, NewPopoverAlignment, PopoverAlignment } from '../Popover';
export type DeprecatedCopyButtonAlignment = DeprecatedPopoverAlignment;
export type NewCopyButtonAlignment = NewPopoverAlignment;
export type CopyButtonAlignment = PopoverAlignment;
export interface CopyButtonProps extends ButtonProps<'button'> {
    /**
     * Specify how the trigger should align with the tooltip
     */
    align?: CopyButtonAlignment;
    /**
     * **Experimental**: Will attempt to automatically align the tooltip. Requires React v17+
     * @see https://github.com/carbon-design-system/carbon/issues/18714
     */
    autoAlign?: boolean;
    /**
     * Specify an optional className to be applied to the underlying `<button>`
     */
    className?: string;
    /**
     * Specify the string that is displayed when the button is clicked and the
     * content is copied
     */
    feedback?: string;
    /**
     * Specify the time it takes for the feedback message to timeout
     */
    feedbackTimeout?: number;
    /**
     * Provide a description for the icon representing the copy action that can
     * be read by screen readers
     */
    iconDescription?: string;
    /**
     * Specify an optional `onClick` handler that is called when the underlying
     * `<button>` is clicked
     */
    onClick?: MouseEventHandler<HTMLButtonElement>;
}
declare function CopyButton({ align, autoAlign, feedback, feedbackTimeout, iconDescription, className, onClick, ...other }: CopyButtonProps): import("react/jsx-runtime").JSX.Element;
declare namespace CopyButton {
    var propTypes: {
        /**
         * Specify how the trigger should align with the tooltip
         */
        align: PropTypes.Requireable<import("@floating-ui/utils").Placement | "top-left" | "top-right" | "bottom-left" | "bottom-right" | "left-bottom" | "left-top" | "right-bottom" | "right-top"> | PropTypes.Validator<import("@floating-ui/utils").Placement | "top-left" | "top-right" | "bottom-left" | "bottom-right" | "left-bottom" | "left-top" | "right-bottom" | "right-top">;
        /**
         * **Experimental**: Will attempt to automatically align the tooltip. Requires
         * React v17+
         * @see https://github.com/carbon-design-system/carbon/issues/18714
         */
        autoAlign: PropTypes.Requireable<boolean>;
        /**
         * Specify an optional className to be applied to the underlying `<button>`
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the string that is displayed when the button is clicked and the
         * content is copied
         */
        feedback: PropTypes.Requireable<string>;
        /**
         * Specify the time it takes for the feedback message to timeout
         */
        feedbackTimeout: PropTypes.Requireable<number>;
        /**
         * Provide a description for the icon representing the copy action that can
         * be read by screen readers
         */
        iconDescription: PropTypes.Requireable<string>;
        /**
         * Specify an optional `onClick` handler that is called when the underlying
         * `<button>` is clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
    };
}
export default CopyButton;
