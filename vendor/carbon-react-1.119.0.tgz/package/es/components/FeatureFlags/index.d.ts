/**
 * Copyright IBM Corp. 2015, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type ReactNode } from 'react';
export interface FeatureFlagsProps {
    children?: ReactNode;
    /**
     * Provide the feature flags to enable or disable in the current React tree.
     *
     * @deprecated Use the individual boolean props instead. Run the
     * `featureflag-deprecate-flags-prop` codemod to migrate:
     * `npx @carbon/upgrade migrate featureflag-deprecate-flags-prop --write`
     */
    flags?: Record<string, boolean>;
    /**
     * Enable the features and functionality for the v12 Release.
     *
     * Enabling this turns on every `enableV12*` flag at once, as well as
     * `enableFocusWrapWithoutSentinels`.
     */
    enableV12Release?: boolean;
    /**
     * Enable rendering of default icons in the tile components.
     *
     * Becomes the default behavior in v12.
     */
    enableV12TileDefaultIcons?: boolean;
    /**
     * Enable rendering of radio icons in the `RadioTile` component.
     *
     * Becomes the default behavior in v12.
     */
    enableV12TileRadioIcons?: boolean;
    /**
     * Enable the use of the v12 `OverflowMenu` leveraging the `Menu`
     * subcomponents.
     *
     * Becomes the default behavior in v12.
     */
    enableV12Overflowmenu?: boolean;
    /**
     * Enable the new `TreeView` controllable API.
     */
    enableTreeviewControllable?: boolean;
    /**
     * Enable the new focus wrap behavior that doesn't use sentinel nodes.
     *
     * @deprecated Use `enableFocusWrapWithoutSentinels` instead.
     */
    enableExperimentalFocusWrapWithoutSentinels?: boolean;
    /**
     * Enable the new focus wrap behavior that doesn't use sentinel nodes.
     */
    enableFocusWrapWithoutSentinels?: boolean;
    /**
     * Enable components to utilize the native `dialog` element.
     */
    enableDialogElement?: boolean;
    /**
     * Enable dynamic setting of floating styles for components like `Popover`,
     * `Tooltip`, etc.
     *
     * Becomes the default behavior in v12.
     */
    enableV12DynamicFloatingStyles?: boolean;
    /**
     * Enable `autoAlign` by default for components that support it, like
     * `Popover`, `Tooltip`, `Toggletip`, `Dropdown`, etc. An explicit
     * `autoAlign` prop always takes precedence.
     *
     * Becomes the default behavior in v12.
     */
    enableV12Autoalign?: boolean;
    /**
     * Enable enhanced functionality for the `FileUploader` component, including
     * richer callback data and expanded trigger events for `onChange` and
     * `onDelete`.
     */
    enableEnhancedFileUploader?: boolean;
    /**
     * Enable components to remain unmounted in closed state and mount in open
     * state.
     */
    enablePresence?: boolean;
}
/**
 * Supports an object of feature flag values with the `flags` prop, merging them
 * along with the current `FeatureFlagContext` to provide consumers to check if
 * a feature flag is enabled or disabled in a given React tree
 */
export declare const FeatureFlags: {
    ({ children, flags, enableV12Release, enableV12TileDefaultIcons, enableV12TileRadioIcons, enableV12Overflowmenu, enableTreeviewControllable, enableExperimentalFocusWrapWithoutSentinels, enableFocusWrapWithoutSentinels, enableDialogElement, enableV12DynamicFloatingStyles, enableV12Autoalign, enableEnhancedFileUploader, enablePresence, }: FeatureFlagsProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide the feature flags to enabled or disabled in the current Rea,ct tree
         */
        flags: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
        enableV12Release: PropTypes.Requireable<boolean>;
        enableV12TileDefaultIcons: PropTypes.Requireable<boolean>;
        enableV12TileRadioIcons: PropTypes.Requireable<boolean>;
        enableV12Overflowmenu: PropTypes.Requireable<boolean>;
        enableTreeviewControllable: PropTypes.Requireable<boolean>;
        enableExperimentalFocusWrapWithoutSentinels: PropTypes.Requireable<boolean>;
        enableFocusWrapWithoutSentinels: PropTypes.Requireable<boolean>;
        enableDialogElement: PropTypes.Requireable<boolean>;
        enableV12DynamicFloatingStyles: PropTypes.Requireable<boolean>;
        enableV12Autoalign: PropTypes.Requireable<boolean>;
        enableEnhancedFileUploader: PropTypes.Requireable<boolean>;
        enablePresence: PropTypes.Requireable<boolean>;
    };
};
/**
 * Access whether a given flag is enabled or disabled in a given
 * FeatureFlagContext
 */
export declare const useFeatureFlag: (flag: string) => any;
/**
 * Access all feature flag information for the given FeatureFlagContext
 */
export declare const useFeatureFlags: () => {
    flags: Map<any, any>;
    checkForFlag(name: any): void;
    add(name: any, enabled: any): void;
    enable(name: any): void;
    disable(name: any): void;
    merge(flags: any): void;
    mergeWithScope(scope: any): void;
    enabled(name: any): any;
};
