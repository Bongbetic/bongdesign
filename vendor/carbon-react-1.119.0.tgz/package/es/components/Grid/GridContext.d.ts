/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export type GridMode = 'flexbox' | 'css-grid';
export interface GridSettingContext {
    /**
     * The gutter mode for the GridContext
     */
    mode: GridMode;
    /**
     * Specifies whether subgrid should be enabled
     */
    subgrid?: boolean;
}
export interface GridSettingsProps {
    /**
     * Pass in components which will be rendered within the `GridSettings`
     * component
     */
    children?: React.ReactNode;
    /**
     * Specify the gutter mode for the GridContext
     */
    mode: GridMode;
    /**
     * Specify whether subgrid should be enabled
     */
    subgrid?: boolean;
}
export declare const GridSettings: {
    ({ children, mode, subgrid, }: GridSettingsProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Pass in components which will be rendered within the `GridSettings`
         * component
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify the gutter mode for the GridContext
         */
        mode: PropTypes.Validator<NonNullable<GridMode>>;
        /**
         * Specify whether subgrid should be enabled
         */
        subgrid: PropTypes.Requireable<boolean>;
    };
};
/**
 * Helper function for accessing the GridContext value
 */
export declare const useGridSettings: () => GridSettingContext;
