/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ReactElement } from 'react';
import { PolymorphicProps } from '../../types/common';
interface ColumnHangBaseProps {
    /**
     * Pass in content that will be rendered within the `ColumnHang`
     */
    children?: React.ReactNode;
    /**
     * Specify a custom className to be applied to the `ColumnHang`
     */
    className?: string;
}
export type ColumnHangProps<T extends React.ElementType> = PolymorphicProps<T, ColumnHangBaseProps>;
export interface ColumnHangComponent {
    <T extends React.ElementType>(props: ColumnHangProps<T>, context?: any): ReactElement | null;
}
declare const ColumnHangComponent: ColumnHangComponent;
export { ColumnHangComponent as ColumnHang };
