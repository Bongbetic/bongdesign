/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export interface FormLabelProps extends Omit<React.LabelHTMLAttributes<HTMLLabelElement>, 'htmlFor'> {
    /**
     * Specify the content of the form label
     */
    children?: React.ReactNode;
    /**
     * Provide a custom className to be applied to the containing <label> node
     */
    className?: string;
    /**
     * Provide a unique id for the given `FormLabel`
     */
    id?: string;
}
declare function FormLabel({ className: customClassName, children, id, ...rest }: FormLabelProps): import("react/jsx-runtime").JSX.Element;
declare namespace FormLabel {
    var propTypes: {
        /**
         * Specify the content of the form label
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom className to be applied to the containing <label> node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Provide a unique id for the given `FormLabel`
         */
        id: PropTypes.Requireable<string>;
    };
}
export default FormLabel;
