export default getDerivedStateFromProps;
/**
 * Helper to derive the next state from the given props and the
 * prevState. Potential future-facing API hook for React v17.
 *
 * Currently, it's being used as a way to normalize the incoming data that we
 * are receiving for rows
 */
declare function getDerivedStateFromProps(props: any, prevState: any): {
    rowIds: any;
    rowsById: any;
    cellsById: any;
    sortDirection: any;
    sortHeaderKey: any;
    initialRowOrder: any;
    filterInputValue: any;
    shouldShowBatchActions: any;
    isExpandedAll: boolean;
};
