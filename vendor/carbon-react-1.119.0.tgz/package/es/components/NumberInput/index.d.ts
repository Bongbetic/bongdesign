/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export { default as NumberInputSkeleton } from './NumberInput.Skeleton';
export { NumberInput, validateNumberSeparators, type NumberInputProps, } from './NumberInput';
