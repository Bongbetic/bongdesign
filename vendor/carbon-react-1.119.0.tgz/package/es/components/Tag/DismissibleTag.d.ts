/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ReactNode } from 'react';
import { PolymorphicProps } from '../../types/common';
import { SIZES, TYPES } from './Tag';
import { PopoverAlignment } from '../Popover';
export interface DismissibleTagBaseProps {
    /**
     * Provide a custom className that is applied to the containing <span>
     */
    className?: string;
    /**
     * **Experimental:** Provide a `decorator` component to be rendered inside the `DismissibleTag` component
     */
    decorator?: ReactNode;
    /**
     * Specify if the `DismissibleTag` is disabled
     */
    disabled?: boolean;
    /**
     * Specify the tooltip alignment for the dismiss button
     */
    dismissTooltipAlignment?: PopoverAlignment;
    /**
     * Provide a custom tooltip label for the dismiss button
     */
    dismissTooltipLabel?: string;
    /**
     * Specify the id for the selectable tag.
     */
    id?: string;
    /**
     * Click handler for filter tag close button.
     */
    onClose?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * A component used to render an icon.
     */
    renderIcon?: React.ElementType;
    /**
     * Specify the size of the Tag. Currently supports either `sm`,
     * `md` (default) or `lg` sizes.
     */
    size?: keyof typeof SIZES;
    /**
     * @deprecated please use `decorator` instead.
     * **Experimental:** Provide a `Slug` component to be rendered inside the `DismissibleTag` component
     */
    slug?: ReactNode;
    /**
     * Provide text to be rendered inside of a the tag.
     */
    text?: string;
    /**
     * Provide a custom `title` to be inserted in the tag.
     */
    tagTitle?: string;
    /**
     * Text to show on clear filters
     */
    title?: string;
    /**
     * Specify the type of the `Tag`
     */
    type?: keyof typeof TYPES;
}
export type DismissibleTagProps<T extends React.ElementType> = PolymorphicProps<T, DismissibleTagBaseProps>;
declare const DismissibleTag: React.ForwardRefExoticComponent<Omit<DismissibleTagProps<React.ElementType<any, keyof React.JSX.IntrinsicElements>>, "ref"> & React.RefAttributes<HTMLDivElement>>;
export declare const types: string[];
export default DismissibleTag;
