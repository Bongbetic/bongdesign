/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface FluidSelectSkeletonProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
}
declare const FluidSelectSkeleton: {
    ({ className, ...rest }: FluidSelectSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
    };
};
export default FluidSelectSkeleton;
