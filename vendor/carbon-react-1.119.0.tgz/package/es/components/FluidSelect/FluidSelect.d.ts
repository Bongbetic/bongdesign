/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type SelectHTMLAttributes } from 'react';
export interface FluidSelectProps {
    /**
     * Provide the contents of your Select
     */
    children?: React.ReactNode;
    /**
     * Specify an optional className to be applied to the node containing the label and the select box
     */
    className?: string;
    /**
     * Optionally provide the default value of the `<select>`
     */
    defaultValue?: SelectHTMLAttributes<HTMLSelectElement>['defaultValue'];
    /**
     * Specify whether the control is disabled
     */
    disabled?: boolean;
    /**
     * Specify a custom `id` for the `<select>`
     */
    id: string;
    /**
     * Specify if the currently value is invalid.
     */
    invalid?: boolean;
    /**
     * Message which is displayed if the value is invalid.
     */
    invalidText?: React.ReactNode;
    /**
     * Provide label text to be read by screen readers when interacting with the
     * control
     */
    labelText?: React.ReactNode;
    /**
     * Provide an optional `onChange` hook that is called each time the value of
     * the underlying `<input>` changes
     */
    onChange?: React.ChangeEventHandler<HTMLSelectElement>;
    /**
     * Specify whether the control is currently in warning state
     */
    warn?: boolean;
    /**
     * Provide the text that is displayed when the control is in warning state
     */
    warnText?: React.ReactNode;
    /**
     * Whether or not the component is readonly
     */
    readOnly?: boolean;
}
declare const FluidSelect: React.ForwardRefExoticComponent<FluidSelectProps & React.RefAttributes<HTMLSelectElement>>;
export default FluidSelect;
