/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ElementType, type ReactNode } from 'react';
import PropTypes from 'prop-types';
interface ContainedListItemProps {
    /**
     * A slot for a possible interactive element to render within the item.
     */
    action?: ReactNode;
    /**
     * The content of this item. Must not contain any interactive elements. Use props.action to include those.
     */
    children?: ReactNode;
    /**
     * Additional CSS class names.
     */
    className?: string;
    /**
     * Whether this item is disabled.
     */
    disabled?: boolean;
    /**
     * Provide an optional function to be called when the item is clicked.
     */
    onClick?: () => void;
    /**
     * A component used to render an icon.
     */
    renderIcon?: ElementType;
}
declare const ContainedListItem: {
    ({ action, children, className, disabled, onClick, renderIcon: IconElement, ...rest }: ContainedListItemProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * A slot for a possible interactive element to render within the item.
         */
        action: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * The content of this item. Must not contain any interactive elements. Use props.action to include those.
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Additional CSS class names.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Whether this item is disabled.
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Provide an optional function to be called when the item is clicked.
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * A component used to render an icon.
         */
        renderIcon: PropTypes.Requireable<object>;
    };
};
export default ContainedListItem;
