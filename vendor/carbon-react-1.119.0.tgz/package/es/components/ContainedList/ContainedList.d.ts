/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { ReactNode } from 'react';
import PropTypes from 'prop-types';
declare const variants: readonly ["on-page", "disclosed"];
export type Variants = (typeof variants)[number];
export interface ContainedListProps {
    /**
     * A slot for a possible interactive element to render.
     */
    action?: ReactNode;
    /**
     * A collection of ContainedListItems to be rendered in the ContainedList
     */
    children?: ReactNode;
    /**
     * Additional CSS class names.
     */
    className?: string;
    /**
     * Specify whether the dividing lines in between list items should be inset.
     */
    isInset?: boolean;
    /**
     * The kind of ContainedList you want to display
     */
    kind?: Variants;
    /**
     * A label describing the contained list.
     */
    label?: string | ReactNode;
    /**
     * Specify the size of the contained list.
     */
    size?: 'sm' | 'md' | 'lg' | 'xl';
}
declare const ContainedList: {
    ({ action, children, className, isInset, kind, label, size, ...rest }: ContainedListProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * A slot for a possible interactive element to render.
         */
        action: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * A collection of ContainedListItems to be rendered in the ContainedList
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Additional CSS class names.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether the dividing lines in between list items should be inset.
         */
        isInset: PropTypes.Requireable<boolean>;
        /**
         * The kind of ContainedList you want to display
         */
        kind: PropTypes.Requireable<"on-page" | "disclosed">;
        /**
         * A label describing the contained list.
         */
        label: PropTypes.Requireable<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Specify the size of the contained list.
         */
        size: PropTypes.Requireable<string>;
    };
};
export default ContainedList;
