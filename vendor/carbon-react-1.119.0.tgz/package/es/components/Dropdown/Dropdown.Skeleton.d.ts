/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type HTMLAttributes } from 'react';
import { type ListBoxSize } from '../ListBox';
export interface DropdownSkeletonProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Specify whether the label should be hidden, or not
     */
    hideLabel?: boolean;
    /**
     * Specify the size of the ListBox.
     */
    size?: ListBoxSize;
}
declare const DropdownSkeleton: {
    ({ className, size, hideLabel, ...rest }: DropdownSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether the label should be hidden, or not
         */
        hideLabel: PropTypes.Requireable<boolean>;
        /**
         * Specify the size of the ListBox.
         */
        size: PropTypes.Requireable<"sm" | "md" | "lg" | "xs">;
    };
};
export default DropdownSkeleton;
export { DropdownSkeleton };
