/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export type FormItemProps = {
    /**
     * Provide content to be rendered in the form item
     */
    children?: React.ReactNode;
    /**
     * Provide a custom className to be applied to the containing node
     */
    className?: string;
};
declare function FormItem({ className, children, ...rest }: FormItemProps): import("react/jsx-runtime").JSX.Element;
declare namespace FormItem {
    var propTypes: {
        /**
         * Provide content to be rendered in the form item
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom className to be applied to the containing node
         */
        className: PropTypes.Requireable<string>;
    };
}
export default FormItem;
