/**
 * Copyright IBM Corp. 2023, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ElementType, HTMLAttributes, ReactNode } from 'react';
/**
 * Density of components within this layout
 */
type Density = 'condensed' | 'normal';
/**
 * Size of components within this layout
 */
type Size = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
export interface LayoutProps extends HTMLAttributes<HTMLElement> {
    /**
     * Specify a custom component or element to be rendered as the top-level
     * element in the component
     */
    as?: (() => ReactNode) | string | ElementType;
    /**
     * Provide child elements to be rendered inside of `Layout`
     */
    children?: ReactNode;
    /**
     * Provide a custom class name to be used on the outermost element rendered by
     * the component
     */
    className?: string;
    /**
     * Specify the desired density of components within this layout
     */
    density?: Density;
    /**
     * Specify the desired size of components within this layout
     */
    size?: Size;
}
declare const Layout: React.ForwardRefExoticComponent<LayoutProps & React.RefAttributes<React.ReactNode>>;
export interface LayoutConstraintProps extends HTMLAttributes<HTMLElement> {
    /**
     * Specify a custom component or element to be rendered as the top-level
     * element in the component
     */
    as?: (() => ReactNode) | string | ElementType;
    /**
     * Provide child elements to be rendered inside of `LayoutConstraint`
     */
    children?: ReactNode;
    /**
     * Provide a custom class name to be used on the outermost element rendered by
     * the component
     */
    className?: string;
    /**
     * Specify the desired layout density constraints of this element's children
     */
    density?: {
        min?: Density | null;
        default?: Density | null;
        max?: Density | null;
    } | null;
    /**
     * Specify the desired layout size constraints of this element's children
     */
    size?: {
        min?: Size | null;
        default?: Size | null;
        max?: Size | null;
    } | null;
}
declare const LayoutConstraint: React.ForwardRefExoticComponent<LayoutConstraintProps & React.RefAttributes<React.ReactNode>>;
export { Layout, LayoutConstraint };
