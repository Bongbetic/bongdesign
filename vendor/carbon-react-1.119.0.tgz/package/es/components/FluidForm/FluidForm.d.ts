/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type HTMLAttributes } from 'react';
export type FluidFormProps = HTMLAttributes<HTMLFormElement>;
declare const FluidForm: {
    ({ className, children, ...other }: FluidFormProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Provide children to be rendered inside of the <form> element
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom className to be applied on the containing <form> node
         */
        className: PropTypes.Requireable<string>;
    };
};
export default FluidForm;
