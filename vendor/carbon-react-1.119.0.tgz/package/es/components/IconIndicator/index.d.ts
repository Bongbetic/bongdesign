/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { PopoverAlignment } from '../Popover';
declare const iconTypes: {
    readonly failed: import("@carbon/icons-react").CarbonIconType;
    readonly 'caution-major': import("@carbon/icons-react").CarbonIconType;
    readonly 'caution-minor': import("@carbon/icons-react").CarbonIconType;
    readonly undefined: import("@carbon/icons-react").CarbonIconType;
    readonly succeeded: import("@carbon/icons-react").CarbonIconType;
    readonly normal: import("@carbon/icons-react").CarbonIconType;
    readonly 'in-progress': import("@carbon/icons-react").CarbonIconType;
    readonly incomplete: import("@carbon/icons-react").CarbonIconType;
    readonly 'not-started': import("@carbon/icons-react").CarbonIconType;
    readonly pending: import("@carbon/icons-react").CarbonIconType;
    readonly unknown: import("@carbon/icons-react").CarbonIconType;
    readonly informative: import("@carbon/icons-react").CarbonIconType;
};
export declare const IconIndicatorKinds: (keyof typeof iconTypes)[];
export type IconIndicatorKind = (typeof IconIndicatorKinds)[number];
export interface IconIndicatorProps {
    /**
     * Specify how the tooltip should align with the icon in compact mode
     */
    align?: PopoverAlignment;
    /**
     * Will auto-align the tooltip in compact mode.
     */
    autoAlign?: boolean;
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * When true, displays only the icon with the label in a tooltip
     */
    compact?: boolean;
    /**
     * Description for the icon announced to screen readers in compact mode.
     * Defaults to `label` when not provided.
     */
    iconDescription?: string;
    /**
     * Specify the kind of icon to be used
     */
    kind: IconIndicatorKind;
    /**
     * Label next to the icon
     */
    label: string;
    /**
     * Specify the size of the Icon Indicator. Defaults to 16.
     */
    size?: 16 | 20;
}
export declare const IconIndicator: React.ForwardRefExoticComponent<IconIndicatorProps & React.RefAttributes<HTMLDivElement>>;
export default IconIndicator;
