/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import Search from './Search';
export * from './Search';
export default Search;
export { Search };
export { default as SearchSkeleton } from './Search.Skeleton';
