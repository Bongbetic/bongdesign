/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { AnimationEventHandler, MouseEventHandler, PropsWithChildren } from 'react';
import type { DeprecatedPopoverAlignment, NewPopoverAlignment, PopoverAlignment } from '../Popover';
export type DeprecatedCopyAlignment = DeprecatedPopoverAlignment;
export type NewCopyAlignment = NewPopoverAlignment;
export type CopyAlignment = PopoverAlignment;
export interface CopyProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    /**
     * Specify how the trigger should align with the tooltip
     */
    align?: CopyAlignment;
    /**
     * **Experimental**: Will attempt to automatically align the tooltip. Requires React v17+
     * @see https://github.com/carbon-design-system/carbon/issues/18714
     */
    autoAlign?: boolean;
    /**
     * Specify an optional className to be applied to the underlying `<button>`
     */
    className?: string;
    /**
     * Specify the string that is displayed when the button is clicked and the
     * content is copied
     */
    feedback?: string;
    /**
     * Specify the time it takes for the feedback message to timeout
     */
    feedbackTimeout?: number;
    /**
     * Specify an optional `onAnimationEnd` handler that is called when the underlying
     * animation ends
     */
    onAnimationEnd?: AnimationEventHandler<HTMLButtonElement>;
    /**
     * Specify an optional `onClick` handler that is called when the underlying
     * `<button>` is clicked
     */
    onClick?: MouseEventHandler<HTMLButtonElement>;
}
declare function Copy({ align, autoAlign, children, className, feedback, feedbackTimeout, onAnimationEnd, onClick, ...other }: PropsWithChildren<CopyProps>): import("react/jsx-runtime").JSX.Element;
declare namespace Copy {
    var propTypes: {
        /**
         * Specify how the trigger should align with the tooltip
         */
        align: PropTypes.Requireable<import("@floating-ui/utils").Placement | "top-left" | "top-right" | "bottom-left" | "bottom-right" | "left-bottom" | "left-top" | "right-bottom" | "right-top"> | PropTypes.Validator<import("@floating-ui/utils").Placement | "top-left" | "top-right" | "bottom-left" | "bottom-right" | "left-bottom" | "left-top" | "right-bottom" | "right-top">;
        /**
         * **Experimental**: Will attempt to automatically align the tooltip. Requires
         * React v17+
         * @see https://github.com/carbon-design-system/carbon/issues/18714
         */
        autoAlign: PropTypes.Requireable<boolean>;
        /**
         * Pass in content to be rendered in the underlying `<button>`
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify an optional className to be applied to the underlying `<button>`
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the string that is displayed when the button is clicked and the
         * content is copied
         */
        feedback: PropTypes.Requireable<string>;
        /**
         * Specify the time it takes for the feedback message to timeout
         */
        feedbackTimeout: PropTypes.Requireable<number>;
        /**
         * Specify an optional `onAnimationEnd` handler that is called when the underlying
         * animation ends
         */
        onAnimationEnd: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Specify an optional `onClick` handler that is called when the underlying
         * `<button>` is clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
    };
}
export default Copy;
