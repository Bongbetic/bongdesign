/**
 * Copyright IBM Corp. 2025, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { PopoverAlignment } from '../Popover';
export declare const ShapeIndicatorKinds: string[];
export type ShapeIndicatorKind = (typeof ShapeIndicatorKinds)[number];
export interface ShapeIndicatorProps {
    /**
     * Specify how the tooltip should align with the shape in compact mode
     */
    align?: PopoverAlignment;
    /**
     * Will auto-align the tooltip in compact mode.
     */
    autoAlign?: boolean;
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * When true, displays only the shape with the label in a tooltip
     */
    compact?: boolean;
    /**
     * Specify the kind of shape to be used
     */
    kind: ShapeIndicatorKind;
    /**
     * Label next to the shape
     */
    label: string;
    /**
     * Description for the shape announced to screen readers in compact mode.
     * Defaults to `label` when not provided.
     */
    shapeDescription?: string;
    /**
     * Specify the text size of the Shape Indicator. Defaults to 12.
     */
    textSize?: 12 | 14;
}
export declare const ShapeIndicator: React.ForwardRefExoticComponent<ShapeIndicatorProps & React.RefAttributes<HTMLDivElement>>;
export default ShapeIndicator;
