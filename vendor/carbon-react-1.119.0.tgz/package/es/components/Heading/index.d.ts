/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ElementType } from 'react';
import type { PolymorphicProps } from '../../types/common';
type HeadingLevel = 1 | 2 | 3 | 4 | 5 | 6;
type SectionBaseProps = {
    level?: HeadingLevel;
};
export type SectionProps<E extends ElementType> = PolymorphicProps<E, SectionBaseProps>;
export declare const Section: React.ForwardRefExoticComponent<Omit<SectionProps<React.ElementType>, "ref"> & React.RefAttributes<unknown>>;
export declare const Heading: React.ForwardRefExoticComponent<Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "ref"> & React.RefAttributes<HTMLHeadingElement>>;
export {};
