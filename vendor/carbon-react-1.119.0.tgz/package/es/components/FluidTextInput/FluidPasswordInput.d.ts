/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export interface FluidPasswordInputProps {
    /**
     * Specify an optional className to be applied to the outer FluidForm wrapper
     */
    className?: string;
    /**
     * Optionally provide the default value of the `<input>`
     */
    defaultValue?: string | number;
    /**
     * Specify whether the `<input>` should be disabled
     */
    disabled?: boolean;
    /**
     * "Hide password" tooltip text on password visibility toggle
     */
    hidePasswordLabel?: string;
    /**
     * Specify a custom `id` for the `<input>`
     */
    id: string;
    /**
     * Specify whether the control is currently invalid
     */
    invalid?: boolean;
    /**
     * Provide the text that is displayed when the control is in an invalid state
     */
    invalidText?: React.ReactNode;
    /**
     * Specify whether the control is a password input
     */
    isPassword?: boolean;
    /**
     * Provide the text that will be read by a screen reader when visiting this
     * control
     */
    labelText: React.ReactNode;
    /**
     * Optionally provide an `onChange` handler that is called whenever `<input>`
     * is updated
     */
    onChange?: React.ChangeEventHandler<HTMLInputElement>;
    /**
     * Optionally provide an `onClick` handler that is called whenever the
     * `<input>` is clicked
     */
    onClick?: React.MouseEventHandler<HTMLInputElement>;
    /**
     * Callback function that is called whenever the toggle password visibility
     * button is clicked
     */
    onTogglePasswordVisibility?: React.MouseEventHandler<HTMLButtonElement>;
    /**
     * Specify the placeholder attribute for the `<input>`
     */
    placeholder?: string;
    /**
     * "Show password" tooltip text on password visibility toggle
     */
    showPasswordLabel?: string;
    /**
     * Specify the value of the `<input>`
     */
    value?: string | number;
    /**
     * Specify whether the control is currently in warning state
     */
    warn?: boolean;
    /**
     * Provide the text that is displayed when the control is in warning state
     */
    warnText?: React.ReactNode;
    /**
     * Whether or not the component is readonly
     */
    readOnly?: boolean;
}
declare const FluidPasswordInput: {
    ({ className, ...other }: FluidPasswordInputProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to be applied to the outer FluidForm wrapper
         */
        className: PropTypes.Requireable<string>;
        /**
         * Optionally provide the default value of the `<input>`
         */
        defaultValue: PropTypes.Requireable<NonNullable<string | number | null | undefined>>;
        /**
         * Specify whether the `<input>` should be disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * "Hide password" tooltip text on password visibility toggle
         */
        hidePasswordLabel: PropTypes.Requireable<string>;
        /**
         * Specify a custom `id` for the `<input>`
         */
        id: PropTypes.Validator<string>;
        /**
         * Specify whether the control is currently invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the control is in an invalid state
         */
        invalidText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify whether the control is a password input
         */
        isPassword: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that will be read by a screen reader when visiting this
         * control
         */
        labelText: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Optionally provide an `onChange` handler that is called whenever `<input>`
         * is updated
         */
        onChange: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Optionally provide an `onClick` handler that is called whenever the
         * `<input>` is clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Callback function that is called whenever the toggle password visibility
         * button is clicked
         */
        onTogglePasswordVisibility: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Specify the placeholder attribute for the `<input>`
         */
        placeholder: PropTypes.Requireable<string>;
        /**
         * "Show password" tooltip text on password visibility toggle
         */
        showPasswordLabel: PropTypes.Requireable<string>;
        /**
         * Specify the value of the `<input>`
         */
        value: PropTypes.Requireable<NonNullable<string | number | null | undefined>>;
        /**
         * Specify whether the control is currently in warning state
         */
        warn: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the control is in warning state
         */
        warnText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Whether or not the component is readonly
         */
        readOnly: PropTypes.Requireable<boolean>;
    };
};
export default FluidPasswordInput;
