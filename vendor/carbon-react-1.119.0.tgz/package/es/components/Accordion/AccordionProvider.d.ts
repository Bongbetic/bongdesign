/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { PropsWithChildren } from 'react';
type AccordionProviderProp = {
    /**
     * Global setting to disable all AccordionItems
     * within the Accordion. Individual AccordionItems can be
     * disabled by passing the `disabled` prop to the AccordionItem.
     */
    disabled: boolean;
};
export declare const AccordionContext: React.Context<{
    disabled: boolean;
}>;
export declare const AccordionProvider: ({ disabled, children, }: PropsWithChildren<AccordionProviderProp>) => import("react/jsx-runtime").JSX.Element;
export {};
