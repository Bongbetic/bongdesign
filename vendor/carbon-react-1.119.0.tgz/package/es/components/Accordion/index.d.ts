/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import Accordion, { type AccordionProps } from './Accordion';
export default Accordion;
export { Accordion, type AccordionProps };
export { default as AccordionItem } from './AccordionItem';
export { default as AccordionSkeleton } from './Accordion.Skeleton';
