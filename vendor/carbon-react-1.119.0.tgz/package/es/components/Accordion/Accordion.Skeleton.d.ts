/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface AccordionSkeletonProps {
    /**
     * Specify the alignment of the accordion heading
     * title and chevron.
     */
    align?: 'start' | 'end';
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Set number of items to render.
     */
    count?: number;
    /**
     * Specify whether an individual AccordionItem should
     * be flush, default is false.
     */
    isFlush?: boolean;
    /**
     * `false` to not display the first item opened.
     */
    open?: boolean;
    /**
     * Specify if the Accordion should be an ordered list,
     * default is `false`
     */
    ordered?: boolean;
}
declare function AccordionSkeleton({ align, className, count, isFlush, open, ordered, ...rest }: AccordionSkeletonProps): import("react/jsx-runtime").JSX.Element;
declare namespace AccordionSkeleton {
    var propTypes: {
        /**
         * Specify the alignment of the accordion heading title and chevron.
         */
        align: PropTypes.Requireable<string>;
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Set number of items to render
         */
        count: PropTypes.Requireable<number>;
        /**
         * Specify whether an individual AccordionItem should be flush, default is false
         */
        isFlush: PropTypes.Requireable<boolean>;
        /**
         * `false` to not display the first item opened
         */
        open: PropTypes.Requireable<boolean>;
    };
}
export default AccordionSkeleton;
export { AccordionSkeleton };
