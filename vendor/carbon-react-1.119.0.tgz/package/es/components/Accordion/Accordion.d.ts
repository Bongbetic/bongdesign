/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { PropsWithChildren, ReactNode } from 'react';
export interface AccordionProps {
    /**
     * Specify the alignment of the accordion heading
     * title and chevron. Defaults to `end`.
     */
    align?: 'start' | 'end';
    /**
     * Specify an optional className to be applied to
     * the container node.
     */
    className?: string;
    /**
     * Pass in the children that will be rendered within the Accordion
     */
    children?: ReactNode;
    /**
     * Specify whether an individual AccordionItem
     * should be disabled.
     */
    disabled?: boolean;
    /**
     * Specify whether Accordion text should be flush,
     * default is `false`, does not work with `align="start"`.
     */
    isFlush?: boolean;
    /**
     * Specify if the Accordion should be an ordered list,
     * default is `false`
     */
    ordered?: boolean;
    /**
     * Specify the size of the Accordion. Currently
     * supports the following: `sm`, `md`, `lg`
     */
    size?: 'sm' | 'md' | 'lg';
}
declare function Accordion({ align, children, className: customClassName, disabled, isFlush, ordered, size, ...rest }: PropsWithChildren<AccordionProps>): import("react/jsx-runtime").JSX.Element;
declare namespace Accordion {
    var propTypes: {
        /**
         * Specify the alignment of the accordion heading title and chevron.
         */
        align: PropTypes.Requireable<string>;
        /**
         * Pass in the children that will be rendered within the Accordion
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify an optional className to be applied to the container node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether an individual AccordionItem should be disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Specify whether Accordion text should be flush, default is false, does not work with align="start"
         */
        isFlush: PropTypes.Requireable<boolean>;
        /**
         * Specify if the Accordion should be an ordered list,
         * default is `false`
         */
        ordered: PropTypes.Requireable<boolean>;
        /**
         * Specify the size of the Accordion. Currently supports the following:
         */
        size: PropTypes.Requireable<string>;
    };
}
export default Accordion;
