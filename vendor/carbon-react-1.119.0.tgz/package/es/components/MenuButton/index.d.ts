/**
 * Copyright IBM Corp. 2023, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ComponentProps, ReactNode } from 'react';
export type MenuAlignment = 'top' | 'top-start' | 'top-end' | 'bottom' | 'bottom-start' | 'bottom-end';
export interface MenuButtonProps extends ComponentProps<'div'> {
    /**
     * A collection of MenuItems to be rendered as actions for this MenuButton.
     */
    children?: ReactNode;
    /**
     * Additional CSS class names.
     */
    className?: string;
    /**
     * Specify whether the MenuButton should be disabled, or not.
     */
    disabled?: boolean;
    /**
     * Specify the type of button to be used as the base for the trigger button.
     */
    kind?: 'primary' | 'tertiary' | 'ghost';
    /**
     * Provide the label to be rendered on the trigger button.
     */
    label: string;
    /**
     * Experimental property. Specify how the menu should align with the button element
     */
    menuAlignment?: MenuAlignment;
    /**
     * Specify the size of the button and menu.
     */
    size?: 'xs' | 'sm' | 'md' | 'lg';
    /**
     * Specify the tabIndex of the button.
     */
    tabIndex?: number;
    /**
     * Specify the background token to use for the menu. Default is 'layer'.
     */
    menuBackgroundToken?: 'layer' | 'background';
    /**
     * Specify whether a border should be rendered on the menu
     */
    menuBorder?: boolean;
    /**
     * Specify a DOM node where the Menu should be rendered in. Defaults to document.body.
     */
    menuTarget?: Element;
}
declare const MenuButton: React.ForwardRefExoticComponent<Omit<MenuButtonProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
export { MenuButton };
