/**
 * Copyright IBM Corp. 2019, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { Plugin } from 'flatpickr/dist/types/options';
interface AppendToPluginConfig {
    appendTo: HTMLElement;
}
export declare const appendToPlugin: (config: AppendToPluginConfig) => Plugin;
export {};
