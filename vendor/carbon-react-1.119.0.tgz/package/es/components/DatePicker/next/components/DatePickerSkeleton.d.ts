/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
export interface DatePickerSkeletonProps {
    /**
     * Specify whether the skeleton should be a range date picker
     */
    range?: boolean;
    /**
     * Additional CSS class names
     */
    className?: string;
}
/**
 * DatePickerSkeleton component for loading states
 */
export declare const DatePickerSkeleton: React.FC<DatePickerSkeletonProps>;
export default DatePickerSkeleton;
