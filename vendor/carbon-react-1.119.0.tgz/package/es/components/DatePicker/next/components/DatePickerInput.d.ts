/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
/**
 * DatePickerInput component props
 * Maintains 100% backwards compatibility with Carbon React v11 API
 */
export interface DatePickerInputProps {
    /**
     * The unique identifier for the input (required)
     */
    id: string;
    /**
     * The label text
     */
    labelText?: React.ReactNode;
    /**
     * The placeholder text
     */
    placeholder?: string;
    /**
     * The input size
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * Whether the input is disabled
     */
    disabled?: boolean;
    /**
     * Whether the input is invalid
     */
    invalid?: boolean;
    /**
     * The invalid text to display
     */
    invalidText?: React.ReactNode;
    /**
     * Whether the input has a warning
     */
    warn?: boolean;
    /**
     * The warning text to display
     */
    warnText?: React.ReactNode;
    /**
     * Helper text to display below the input
     */
    helperText?: React.ReactNode;
    /**
     * Whether to hide the label visually (still accessible)
     */
    hideLabel?: boolean;
    /**
     * Additional CSS class names
     */
    className?: string;
    /**
     * The input value
     */
    value?: string;
    /**
     * Default value for uncontrolled component
     */
    defaultValue?: string;
    /**
     * Change handler
     */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    /**
     * Focus handler
     */
    onFocus?: (event: React.FocusEvent<HTMLInputElement>) => void;
    /**
     * Blur handler
     */
    onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
    /**
     * Keydown handler
     */
    onKeyDown?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
    /**
     * Click handler
     */
    onClick?: (event: React.MouseEvent<HTMLInputElement>) => void;
    /**
     * Icon description for accessibility
     */
    iconDescription?: string;
    /**
     * Calendar icon click handler
     */
    onIconClick?: () => void;
    /**
     * Whether to show the calendar icon
     */
    hideIcon?: boolean;
    /**
     * Pattern for input validation
     */
    pattern?: string;
    /**
     * Type of input
     */
    type?: string;
    /**
     * Whether the input is read-only
     */
    readOnly?: boolean;
    /**
     * Autocomplete attribute
     */
    autoComplete?: string;
    /**
     * Name attribute
     */
    name?: string;
    /**
     * Whether the field is required
     */
    required?: boolean;
    /**
     * Callback when calendar opens (for internal use)
     */
    onOpen?: () => void;
    /**
     * Decorator component (e.g., AI Label)
     */
    decorator?: React.ReactNode;
    /**
     * @deprecated Use `decorator` instead. Will be removed in next major version.
     */
    slug?: React.ReactNode;
}
/**
 * DatePickerInput component
 * Input field for date picker with Carbon Design System styling
 * Maintains 100% backwards compatibility with Carbon React v11
 */
export declare const DatePickerInput: React.ForwardRefExoticComponent<DatePickerInputProps & React.RefAttributes<HTMLInputElement>>;
