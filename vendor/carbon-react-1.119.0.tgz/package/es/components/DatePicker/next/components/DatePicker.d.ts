/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
/**
 * DatePicker component props
 * Maintains 100% backwards compatibility with Carbon React v11 API
 */
export interface DatePickerProps {
    /**
     * The type of date picker
     */
    datePickerType?: 'simple' | 'single' | 'range';
    /**
     * The date format string
     */
    dateFormat?: string;
    /**
     * Minimum selectable date (mm/dd/yyyy format)
     */
    minDate?: string;
    /**
     * Maximum selectable date (mm/dd/yyyy format)
     */
    maxDate?: string;
    /**
     * Locale for date formatting
     */
    locale?: string;
    /**
     * Whether the picker is read-only
     */
    readOnly?: boolean;
    /**
     * Whether to use the light variant
     */
    light?: boolean;
    /**
     * Whether to use the short variant
     */
    short?: boolean;
    /**
     * Whether to allow manual input
     */
    allowInput?: boolean;
    /**
     * Whether to close calendar on date selection
     */
    closeOnSelect?: boolean;
    /**
     * Change handler - receives array of Date objects
     */
    onChange?: (dates: Date[]) => void;
    /**
     * Close handler
     */
    onClose?: () => void;
    /**
     * Open handler
     */
    onOpen?: () => void;
    /**
     * Additional CSS class names
     */
    className?: string;
    /**
     * Children (DatePickerInput components)
     */
    children?: React.ReactNode;
    /**
     * Initial value
     */
    value?: string;
}
/**
 * DatePicker component
 * Main wrapper component that orchestrates date picker functionality
 * Maintains 100% backwards compatibility with Carbon React v11
 */
export declare function DatePicker({ datePickerType, dateFormat, minDate, maxDate, locale, readOnly, light, short, allowInput, closeOnSelect, onChange, onClose, onOpen, className, children, value, }: DatePickerProps): import("react/jsx-runtime").JSX.Element;
export declare namespace DatePicker {
    var displayName: string;
}
