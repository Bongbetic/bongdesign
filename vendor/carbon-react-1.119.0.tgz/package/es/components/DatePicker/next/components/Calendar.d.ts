/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { DatePickerContext } from '@carbon/utilities/date-picker';
/**
 * Calendar component props
 */
export interface CalendarProps {
    /**
     * State machine context
     */
    context: DatePickerContext;
    /**
     * Date selection handler
     */
    onDateSelect: (date: Temporal.PlainDate) => void;
    /**
     * Navigation handler
     */
    onNavigate: (eventType: string) => void;
    /**
     * Additional CSS class names
     */
    className?: string;
    /**
     * BCP 47 locale tag used to localize month and weekday labels
     */
    locale?: string;
}
/**
 * Calendar component
 * Renders a calendar grid for date selection
 */
export declare function Calendar({ context, onDateSelect, onNavigate, className, locale, }: CalendarProps): import("react/jsx-runtime").JSX.Element | null;
export declare namespace Calendar {
    var displayName: string;
}
