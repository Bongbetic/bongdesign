/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * The full list of supported locales can be found here:
 * https://github.com/flatpickr/flatpickr/tree/master/src/l10n
 */
export declare const SUPPORTED_LOCALES: readonly ["ar", "at", "az", "be", "bg", "bn", "bs", "cat", "cs", "cy", "da", "de", "en", "eo", "es", "et", "fa", "fi", "fo", "fr", "ga", "gr", "he", "hi", "hr", "hu", "id", "is", "it", "ja", "ka", "km", "ko", "kz", "lt", "lv", "mk", "mn", "ms", "my", "nl", "no", "pa", "pl", "pt", "ro", "ru", "si", "sk", "sl", "sq", "sr", "sv", "th", "tr", "uk", "uz", "uz_latn", "vn", "zh_tw", "zh"];
export type SupportedLocale = (typeof SUPPORTED_LOCALES)[number];
