/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type HTMLAttributes } from 'react';
export interface DatePickerSkeletonProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Specify whether to hide the label.
     */
    hideLabel?: boolean;
    /**
     * Specify whether to render the range skeleton variant.
     */
    range?: boolean;
}
declare const DatePickerSkeleton: {
    ({ range, id, hideLabel, className, ...rest }: DatePickerSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether to hide the label.
         */
        hideLabel: PropTypes.Requireable<boolean>;
        /**
         * Specify the id to add.
         */
        id: PropTypes.Requireable<string>;
        /**
         * Specify whether to render the range skeleton variant.
         */
        range: PropTypes.Requireable<boolean>;
    };
};
export default DatePickerSkeleton;
export { DatePickerSkeleton };
