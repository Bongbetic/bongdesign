/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
interface BadgeIndicatorProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Count of badge indicator
     */
    count?: number;
    /**
     * Provide an `id` to uniquely identify the BadgeIndidcator
     */
    id?: string;
}
export declare const BadgeIndicator: React.ForwardRefExoticComponent<BadgeIndicatorProps & React.RefAttributes<HTMLDivElement>>;
export default BadgeIndicator;
