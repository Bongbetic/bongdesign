/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { FluidTextInputProps } from '../FluidTextInput';
export interface FluidTimePickerProps extends FluidTextInputProps {
    /**
     * The child node(s)
     */
    children?: React.ReactNode;
    /**
     * Specify an optional className to be applied to the outer FluidTimePicker wrapper
     */
    className?: string;
    /**
     * Specify whether the `<input>` should be disabled
     */
    disabled?: boolean;
    /**
     * Specify whether or not the control is invalid
     */
    invalid?: boolean;
    /**
     * Provide the text that is displayed when the control is in error state
     */
    invalidText?: React.ReactNode;
    /**
     * Provide the text that will be read by a screen reader when visiting this
     * control
     */
    labelText: React.ReactNode;
    /**
     * Specify whether the control is currently in warning state
     */
    warn?: boolean;
    /**
     * Provide the text that is displayed when the control is in warning state
     */
    warnText?: React.ReactNode;
    /**
     * Specify if the component is readonly
     */
    readOnly?: boolean;
}
declare const FluidTimePicker: React.ForwardRefExoticComponent<FluidTimePickerProps & React.RefAttributes<HTMLInputElement>>;
export default FluidTimePicker;
