/**
 * Copyright IBM Corp. 2022
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface FluidTimePickerSkeletonProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Specify if there are only two TimePicker elements
     */
    isOnlyTwo?: boolean;
}
declare const FluidTimePickerSkeleton: {
    ({ className, isOnlyTwo, ...rest }: {
        [x: string]: any;
        className: any;
        isOnlyTwo: any;
    }): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify if there are only two TimePicker elements
         */
        isOnlyTwo: PropTypes.Requireable<boolean>;
    };
};
export default FluidTimePickerSkeleton;
