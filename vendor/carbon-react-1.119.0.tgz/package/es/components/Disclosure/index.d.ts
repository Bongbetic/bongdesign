/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare function useDisclosure(id: any): {
    buttonProps: {
        'aria-controls': any;
        'aria-expanded': boolean;
        onClick(): void;
    };
    contentProps: {
        id: any;
    };
    open: boolean;
};
export { useDisclosure };
