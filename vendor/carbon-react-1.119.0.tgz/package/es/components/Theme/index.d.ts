/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type ElementType } from 'react';
import { PolymorphicProps } from '../../types/common';
export interface GlobalThemeProps {
    theme?: 'white' | 'g10' | 'g90' | 'g100';
    children?: React.ReactNode;
}
export declare const ThemeContext: React.Context<GlobalThemeProps>;
export declare const GlobalTheme: React.ForwardRefExoticComponent<GlobalThemeProps & {
    children?: React.ReactNode | undefined;
} & React.RefAttributes<unknown>>;
type ThemeBaseProps = GlobalThemeProps & {
    className?: string;
};
type ThemeProps<E extends ElementType> = PolymorphicProps<E, ThemeBaseProps>;
/**
 * Specify the theme to be applied to a page, or a region in a page
 */
export declare function Theme<E extends ElementType = 'div'>({ as: BaseComponent, className: customClassName, theme, ...rest }: ThemeProps<E>): import("react/jsx-runtime").JSX.Element;
export declare namespace Theme {
    var propTypes: {
        /**
         * Specify a custom component or element to be rendered as the top-level
         * element in the component
         */
        as: PropTypes.Requireable<NonNullable<((...args: any[]) => any) | PropTypes.ReactComponentLike | null | undefined>>;
        /**
         * Provide child elements to be rendered inside of `Theme`
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom class name to be used on the outermost element rendered by
         * the component
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the theme
         */
        theme: PropTypes.Requireable<string>;
    };
}
/**
 * Get access to the current theme
 */
export declare function useTheme(): GlobalThemeProps;
export declare function usePrefersDarkScheme(): boolean;
export {};
