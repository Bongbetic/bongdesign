/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { ErrorInfo } from 'react';
export interface ErrorBoundaryContextType {
    log: (error: Error, errorInfo: ErrorInfo) => void;
}
export declare const ErrorBoundaryContext: import("react").Context<ErrorBoundaryContextType>;
