/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { ReactNode } from 'react';
export interface CardActionsProps {
    /**
     * Provide the contents of the CardActions (typically CardAction components).
     */
    children?: ReactNode;
    /**
     * Provide an optional class to be applied to the containing node.
     */
    className?: string;
    /**
     * Aria label for the overflow menu
     */
    overflowMenuLabel?: string;
}
/**
 * CardActions is a container for action buttons in the card header.
 * Positioned in the top-right corner with 8px gap between actions.
 * When actions exceed 50% of available header space, overflow menu is shown.
 */
export declare const CardActions: {
    ({ children, className, overflowMenuLabel, ...rest }: CardActionsProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
