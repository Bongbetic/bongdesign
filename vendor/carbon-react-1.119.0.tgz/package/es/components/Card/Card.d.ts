/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { CardProps } from './Card.types';
import { CardHeader } from './CardHeader';
import { CardBody } from './CardBody';
import { CardFooter } from './CardFooter';
import { CardHeaderMedia } from './CardHeaderMedia';
import { CardMedia } from './CardMedia';
import { CardTitle } from './CardTitle';
import { CardTitleMedia } from './CardTitleMedia';
import { CardActions } from './CardActions';
import { CardAction } from './CardAction';
export declare const Card: React.ForwardRefExoticComponent<CardProps & React.RefAttributes<HTMLDivElement>> & {
    Header: React.ForwardRefExoticComponent<import("./Card.types").CardBaseProps & React.RefAttributes<HTMLDivElement>>;
    Body: React.ForwardRefExoticComponent<import("./Card.types").CardBodyProps & React.RefAttributes<HTMLDivElement>>;
    Footer: React.ForwardRefExoticComponent<import("./Card.types").CardBaseProps & React.RefAttributes<HTMLDivElement>>;
    HeaderMedia: {
        ({ children, className, ...rest }: import("./CardHeaderMedia").CardHeaderMediaProps): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Media: {
        ({ children, className, ratio, mediaWidth, ...rest }: import("./CardMedia").CardMediaProps): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Title: React.ForwardRefExoticComponent<import("./CardTitle").CardTitleProps & React.RefAttributes<HTMLDivElement>>;
    TitleMedia: React.ForwardRefExoticComponent<import("./CardTitleMedia").CardTitleMediaProps & React.RefAttributes<HTMLDivElement>>;
    Actions: {
        ({ children, className, overflowMenuLabel, ...rest }: import("./CardActions").CardActionsProps): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
    Action: {
        ({ children, className, ...rest }: import("./CardAction").CardActionProps): import("react/jsx-runtime").JSX.Element;
        displayName: string;
    };
};
export { Card as default, CardHeader, CardBody, CardFooter, CardHeaderMedia, CardMedia, CardTitle, CardTitleMedia, CardActions, CardAction, };
export type { CardProps, CardHeaderProps, CardBodyProps, CardFooterProps, } from './Card.types';
export type { CardHeaderMediaProps } from './CardHeaderMedia';
export type { CardMediaProps } from './CardMedia';
export type { CardTitleProps } from './CardTitle';
export type { CardTitleMediaProps } from './CardTitleMedia';
export type { CardActionsProps } from './CardActions';
export type { CardActionProps } from './CardAction';
