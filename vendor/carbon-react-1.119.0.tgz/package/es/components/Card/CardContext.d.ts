/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { CardContextValue } from './Card.types';
/**
 * Context for sharing Card state with child components
 */
export declare const CardContext: import("react").Context<CardContextValue | undefined>;
/**
 * Hook to access Card context
 * @returns CardContextValue
 * @throws Error if used outside of Card component
 */
export declare const useCardContext: () => CardContextValue;
