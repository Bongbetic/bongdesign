/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
/**
 * CardFooter component - Footer section of the card.
 *
 * Not supported inside a `clickable` card. A clickable card renders its own
 * built-in footer affordance automatically. Use the `renderFooterIcon` prop on
 * `Card` to customize the icon.
 */
export declare const CardFooter: React.ForwardRefExoticComponent<import("./Card.types").CardBaseProps & React.RefAttributes<HTMLDivElement>>;
