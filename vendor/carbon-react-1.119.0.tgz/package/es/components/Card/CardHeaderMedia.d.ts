/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { ReactNode } from 'react';
export interface CardHeaderMediaProps {
    /**
     * Provide the contents of the CardHeaderMedia.
     */
    children?: ReactNode;
    /**
     * Provide an optional class to be applied to the containing node.
     */
    className?: string;
}
export declare const CardHeaderMedia: {
    ({ children, className, ...rest }: CardHeaderMediaProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
