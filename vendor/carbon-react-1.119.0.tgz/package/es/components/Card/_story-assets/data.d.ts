declare const _default: {
    group: string;
    date: string;
    value: number;
}[];
export default _default;
