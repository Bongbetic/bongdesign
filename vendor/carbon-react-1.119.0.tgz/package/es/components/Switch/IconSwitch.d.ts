/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { type IconButtonProps } from '../IconButton';
import type { SwitchEventHandlersParams } from './Switch';
interface IconSwitchProps extends Omit<IconButtonProps, 'onClick' | 'onKeyDown' | 'label' | 'name'> {
    /**
     * The index of the `IconSwitch`.
     *
     * Reserved for usage in `ContentSwitcher`.
     */
    index?: number;
    /**
     * The name of the `IconSwitch`.
     */
    name?: string | number;
    /**
     * A handler that is invoked when a user clicks on the control.
     *
     * Reserved for usage in `ContentSwitcher`.
     */
    onClick?: (params: SwitchEventHandlersParams) => void;
    /**
     * A handler that is invoked on the key down event for the control.
     *
     * Reserved for usage in `ContentSwitcher`.
     */
    onKeyDown?: (params: SwitchEventHandlersParams) => void;
    /**
     * Whether the `IconSwitch` is selected.
     *
     * Reserved for usage in `ContentSwitcher`.
     */
    selected?: boolean;
    /**
     * `Tooltip` text.
     */
    text?: string;
}
declare const IconSwitch: React.ForwardRefExoticComponent<IconSwitchProps & React.RefAttributes<HTMLButtonElement>>;
export default IconSwitch;
