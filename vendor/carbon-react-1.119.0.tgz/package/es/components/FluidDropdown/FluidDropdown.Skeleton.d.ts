/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface FluidDropdownSkeletonProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
}
declare const FluidDropdownSkeleton: {
    ({ className, ...rest }: FluidDropdownSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
    };
};
export default FluidDropdownSkeleton;
