/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { LayerLevel } from './LayerLevel';
import { PolymorphicComponentPropWithRef } from '../../internal/PolymorphicProps';
/**
 * A custom hook that will return information about the current layer. A common
 * field to pull from this is the `level` for the layer that the component that
 * calls this hook is currently in
 */
export declare function useLayer(): {
    level: 0 | 1 | 2;
};
export interface LayerBaseProps {
    /**
     * Provide child elements to be rendered inside of `Theme`
     */
    children?: React.ReactNode;
    /**
     * Provide a custom class name to be used on the outermost element rendered by
     * the component
     */
    className?: string;
    /**
     * Specify the layer level and override any existing levels based on hierarchy
     */
    level?: LayerLevel;
    /**
     * Applies a css background-color set to $layer-background
     */
    withBackground?: boolean;
}
export type LayerProps<T extends React.ElementType> = PolymorphicComponentPropWithRef<T, LayerBaseProps>;
declare const Layer: React.ForwardRefExoticComponent<Omit<LayerProps<React.ElementType<any, keyof React.JSX.IntrinsicElements>>, "ref"> & React.RefAttributes<unknown>>;
export { Layer };
