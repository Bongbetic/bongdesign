/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type ComponentProps } from 'react';
import TextArea from '../TextArea';
export interface FluidTextAreaProps extends Pick<ComponentProps<typeof TextArea>, 'translateWithId'> {
    /**
     * Provide a custom className that is applied to the wrapper node
     */
    className?: string;
    /**
     * Specify the `cols` attribute for the underlying `<textarea>` node
     */
    cols?: number;
    /**
     * Optionally provide the default value of the `<textarea>`
     */
    defaultValue?: string | number;
    /**
     * Specify whether the control is disabled
     */
    disabled?: boolean;
    /**
     * Specify whether to display the character counter
     */
    enableCounter?: boolean;
    /**
     * Provide text that is used alongside the control label for additional help
     */
    helperText?: React.ReactNode;
    /**
     * Specify whether you want the underlying label to be visually hidden
     */
    hideLabel?: boolean;
    /**
     * Provide a unique identifier for the control
     */
    id?: string;
    /**
     * Specify whether the control is currently invalid
     */
    invalid?: boolean;
    /**
     * Provide the text that is displayed when the control is in an invalid state
     */
    invalidText?: React.ReactNode;
    /**
     * Provide the text that will be read by a screen reader when visiting this
     * control
     */
    labelText: React.ReactNode;
    /**
     * `true` to use the light version. For use on $ui-01 backgrounds only.
     * Don't use this to make tile background color same as container background color.
     */
    light?: boolean;
    /**
     * Max character count allowed for the textarea. This is needed in order for enableCounter to display
     */
    maxCount?: number;
    /**
     * Optionally provide an `onChange` handler that is called whenever `<textarea>`
     * is updated
     */
    onChange?: React.ChangeEventHandler<HTMLTextAreaElement>;
    /**
     * Optionally provide an `onClick` handler that is called whenever the
     * `<textarea>` is clicked
     */
    onClick?: React.MouseEventHandler<HTMLTextAreaElement>;
    /**
     * Specify the placeholder attribute for the `<textarea>`
     */
    placeholder?: string;
    /**
     * Specify the rows attribute for the `<textarea>`
     */
    rows?: number;
    /**
     * Provide the current value of the `<textarea>`
     */
    value?: string | number;
    /**
     * Specify whether the control is currently in warning state
     */
    warn?: boolean;
    /**
     *  Provide the text that is displayed when the control is in warning state
     */
    warnText?: React.ReactNode;
    /**
     * Whether or not the component is readonly
     */
    readOnly?: boolean;
}
declare const FluidTextArea: {
    ({ className, ...other }: FluidTextAreaProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Provide a custom className that is applied to the wrapper node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the `cols` attribute for the underlying `<textarea>` node
         */
        cols: PropTypes.Requireable<number>;
        /**
         * Optionally provide the default value of the `<textarea>`
         */
        defaultValue: PropTypes.Requireable<NonNullable<string | number | null | undefined>>;
        /**
         * Specify whether the control is disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Specify whether to display the character counter
         */
        enableCounter: PropTypes.Requireable<boolean>;
        /**
         * Provide text that is used alongside the control label for additional help
         */
        helperText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify whether you want the underlying label to be visually hidden
         */
        hideLabel: PropTypes.Requireable<boolean>;
        /**
         * Provide a unique identifier for the control
         */
        id: PropTypes.Requireable<string>;
        /**
         * Specify whether the control is currently invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the control is in an invalid state
         */
        invalidText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide the text that will be read by a screen reader when visiting this
         * control
         */
        labelText: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * `true` to use the light version. For use on $ui-01 backgrounds only.
         * Don't use this to make tile background color same as container background color.
         */
        light: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
        /**
         * Max character count allowed for the textarea. This is needed in order for enableCounter to display
         */
        maxCount: PropTypes.Requireable<number>;
        /**
         * Optionally provide an `onChange` handler that is called whenever `<textarea>`
         * is updated
         */
        onChange: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Optionally provide an `onClick` handler that is called whenever the
         * `<textarea>` is clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Specify the placeholder attribute for the `<textarea>`
         */
        placeholder: PropTypes.Requireable<string>;
        /**
         * Specify the rows attribute for the `<textarea>`
         */
        rows: PropTypes.Requireable<number>;
        /**
         * Translates component strings using your i18n tool.
         */
        translateWithId: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Provide the current value of the `<textarea>`
         */
        value: PropTypes.Requireable<NonNullable<string | number | null | undefined>>;
        /**
         * Specify whether the control is currently in warning state
         */
        warn: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the control is in warning state
         */
        warnText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Whether or not the component is readonly
         */
        readOnly: PropTypes.Requireable<boolean>;
    };
};
export default FluidTextArea;
