/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ElementType } from 'react';
import { TextProps } from './Text';
export declare const Legend: {
    (props: TextProps<ElementType>): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
