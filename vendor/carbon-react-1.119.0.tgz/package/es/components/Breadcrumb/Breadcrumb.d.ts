/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
export interface BreadcrumbProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * Specify the label for the breadcrumb container
     */
    'aria-label'?: string;
    /**
     * Specify an optional className to be applied to the container node
     */
    className?: string;
    /**
     * Optional prop to omit the trailing slash for the breadcrumbs
     */
    noTrailingSlash?: boolean;
    /**
     * Specify the size of the Breadcrumb. Currently
     * supports the following: `sm` & `md` (default: 'md')
     */
    size?: 'sm' | 'md';
}
declare const Breadcrumb: React.ForwardRefExoticComponent<BreadcrumbProps & React.RefAttributes<HTMLElement>>;
export default Breadcrumb;
