/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type AriaAttributes } from 'react';
export interface BreadcrumbItemProps extends React.HTMLAttributes<HTMLLIElement> {
    'aria-current'?: AriaAttributes['aria-current'];
    /**
     * Specify an optional className to be applied to the container node
     */
    className?: string;
    /**
     * Optional string representing the link location for the BreadcrumbItem
     */
    href?: string;
    /**
     * Provide if this breadcrumb item represents the current page
     */
    isCurrentPage?: boolean;
}
declare const BreadcrumbItem: React.ForwardRefExoticComponent<BreadcrumbItemProps & React.RefAttributes<HTMLLIElement>>;
export default BreadcrumbItem;
