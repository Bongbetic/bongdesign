/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export interface BreadcrumbSkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Specify the number of items
     */
    items?: number;
    /**
     * Optional prop to omit the trailing slash for the breadcrumbs
     */
    noTrailingSlash?: boolean;
    /**
     * Specify the size of the Breadcrumb. Currently
     * supports the following: `sm` & `md` (default: 'md')
     */
    size?: 'sm' | 'md';
}
declare function BreadcrumbSkeleton({ className, items, noTrailingSlash, size, ...rest }: BreadcrumbSkeletonProps): import("react/jsx-runtime").JSX.Element;
declare namespace BreadcrumbSkeleton {
    var propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the number of items
         */
        items: PropTypes.Requireable<number>;
        /**
         * Optional prop to omit the trailing slash for the breadcrumbs
         */
        noTrailingSlash: PropTypes.Requireable<boolean>;
        /**
         * Specify the size of the Breadcrumb. Currently supports the following: `sm` & `md` (default: 'md')
         */
        size: PropTypes.Requireable<string>;
    };
}
export default BreadcrumbSkeleton;
export { BreadcrumbSkeleton };
