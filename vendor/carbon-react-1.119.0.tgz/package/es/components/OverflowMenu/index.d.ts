/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
import { type OverflowMenuProps as OverflowMenuV12Props } from './next';
import { type OverflowMenuProps as OverflowMenuV11Props } from './OverflowMenu';
type OverflowMenuProps = OverflowMenuV11Props | OverflowMenuV12Props;
declare const OverflowMenu: React.ForwardRefExoticComponent<(Omit<OverflowMenuV12Props, "ref"> | OverflowMenuV11Props) & React.RefAttributes<HTMLDivElement>>;
export default OverflowMenu;
export { OverflowMenu, type OverflowMenuProps };
