/**
 * Copyright IBM Corp. 2020, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ComponentProps, type ElementType } from 'react';
import type { PopoverAlignment } from '../../Popover';
export interface OverflowMenuProps extends ComponentProps<'div'> {
    /**
     * **Experimental**: Will attempt to automatically align the floating element
     * to avoid collisions with the viewport and being clipped by ancestor
     * elements. Requires React v17+
     * @see https://github.com/carbon-design-system/carbon/issues/18714
     */
    autoAlign?: boolean;
    /**
     * A collection of MenuItems to be rendered within this OverflowMenu.
     */
    children?: React.ReactNode;
    /**
     * Additional CSS class names for the trigger button.
     */
    className?: string;
    /**
     * Specify whether the tooltip on the trigger button should be open when it
     * first renders.
     */
    tooltipDefaultOpen?: boolean;
    /**
     * Specify whether the trigger button should be disabled.
     */
    disabled?: boolean;
    /**
     * Specify the duration in milliseconds to delay before displaying the tooltip
     * on the trigger button.
     */
    tooltipEnterDelayMs?: number;
    /**
     * Specify the duration in milliseconds to delay before displaying the tooltip
     * on the trigger button.
     *
     * @deprecated please use `tooltipEnterDelayMs` instead.
     */
    enterDelayMs?: number;
    /**
     * Specify the duration in milliseconds to delay before hiding the tooltip
     * on the trigger button.
     */
    tooltipLeaveDelayMs?: number;
    /**
     * Specify the duration in milliseconds to delay before hiding the tooltip
     * on the trigger button.
     *
     * @deprecated please use `tooltipLeaveDelayMs` instead.
     */
    leaveDelayMs?: number;
    /**
     * A label describing the options available. Is used in the trigger tooltip and as the menu's accessible label.
     */
    label?: string;
    /**
     * Experimental property. Specify how the menu should align with the button element
     */
    menuAlignment?: 'top-start' | 'top-end' | 'bottom-start' | 'bottom-end';
    /**
     * A component used to render an icon.
     */
    renderIcon?: ElementType;
    /**
     * Specify the size of the menu, from a list of available sizes.
     */
    size?: 'xs' | 'sm' | 'md' | 'lg';
    /**
     * Specify how the trigger tooltip should be aligned.
     */
    tooltipAlignment?: PopoverAlignment;
    /**
     * **Experimental**: Will attempt to automatically align the tooltip on the
     * trigger button to avoid collisions with the viewport. Requires React v17+
     * @see https://github.com/carbon-design-system/carbon/issues/18714
     */
    tooltipAutoAlign?: boolean;
    /**
     * Specify the tab index of the trigger button.
     */
    tabIndex?: number;
    /**
     * Specify a DOM node where the Menu should be rendered in. Defaults to document.body.
     */
    menuTarget?: Element;
}
declare const OverflowMenu: React.ForwardRefExoticComponent<Omit<OverflowMenuProps, "ref"> & React.RefAttributes<HTMLDivElement>>;
export { OverflowMenu };
