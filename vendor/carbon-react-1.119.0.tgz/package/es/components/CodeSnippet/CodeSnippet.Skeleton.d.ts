/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export interface CodeSnippetSkeletonProps extends React.HTMLAttributes<Omit<HTMLDivElement, 'children'>> {
    /**
     * Specify an optional className to be applied to the container node
     */
    className?: string;
    /**
     * The type of the code snippet, including single or multi
     */
    type?: 'single' | 'multi' | undefined;
}
declare function CodeSnippetSkeleton({ className: containerClassName, type, ...rest }: {
    [x: string]: any;
    className: any;
    type?: string | undefined;
}): import("react/jsx-runtime").JSX.Element | undefined;
declare namespace CodeSnippetSkeleton {
    var propTypes: {
        /**
         * Specify an optional className to be applied to the container node
         */
        className: PropTypes.Requireable<string>;
        /**
         * The type of the code snippet, including single or multi
         */
        type: PropTypes.Requireable<string>;
    };
}
export default CodeSnippetSkeleton;
export { CodeSnippetSkeleton };
