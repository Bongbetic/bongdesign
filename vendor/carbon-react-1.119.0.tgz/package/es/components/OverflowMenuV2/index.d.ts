export function OverflowMenuV2(props: any): import("react/jsx-runtime").JSX.Element;
