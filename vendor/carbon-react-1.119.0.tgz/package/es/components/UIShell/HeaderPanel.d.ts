/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ReactNode } from 'react';
export interface HeaderPanelProps {
    /**
     * Specify whether focus and blur listeners are added. They are by default.
     */
    addFocusListeners?: boolean;
    /**
     * The content that will render inside of the `HeaderPanel`
     */
    children?: ReactNode;
    /**
     * Optionally provide a custom class to apply to the underlying `<li>` node
     */
    className?: string;
    /**
     * Specify whether the panel is expanded
     */
    expanded?: boolean;
    /**
     * Provide the `href` to the id of the element on your package that could
     * be target.
     */
    href?: string;
    /**
     * An optional listener that is called a callback to collapse the HeaderPanel
     */
    onHeaderPanelFocus?: () => void;
}
declare const HeaderPanel: React.ForwardRefExoticComponent<HeaderPanelProps & React.RefAttributes<HTMLDivElement>>;
export default HeaderPanel;
