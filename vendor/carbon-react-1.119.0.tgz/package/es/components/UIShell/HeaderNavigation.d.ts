/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ComponentProps } from 'react';
import PropTypes from 'prop-types';
export type HeaderNavigationProps = ComponentProps<'nav'>;
declare function HeaderNavigation({ 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledBy, children, className: customClassName, ...rest }: HeaderNavigationProps): import("react/jsx-runtime").JSX.Element;
declare namespace HeaderNavigation {
    var propTypes: {
        /**
         * Provide valid children of HeaderNavigation, for example `HeaderMenuItem`
         * or `HeaderMenu`
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Optionally provide a custom class to apply to the underlying <nav> node
         */
        className: PropTypes.Requireable<string>;
    };
}
export default HeaderNavigation;
