/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ReactNode } from 'react';
import PropTypes from 'prop-types';
export interface HeaderSideNavItemsProps {
    className?: string | undefined;
    children?: ReactNode;
    hasDivider?: boolean | undefined;
}
declare function HeaderSideNavItems({ className: customClassName, children, hasDivider, }: HeaderSideNavItemsProps): import("react/jsx-runtime").JSX.Element;
declare namespace HeaderSideNavItems {
    var propTypes: {
        /**
         * The child nodes to be rendered
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Optionally provide a custom class name that is applied to the underlying
         * button
         */
        className: PropTypes.Requireable<string>;
        /**
         * Optionally specify if container will have a bottom divider to differentiate
         * between original sidenav items and header menu items. False by default.
         */
        hasDivider: PropTypes.Requireable<boolean>;
    };
}
export default HeaderSideNavItems;
