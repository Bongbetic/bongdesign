/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ComponentProps, type JSX } from 'react';
import PropTypes from 'prop-types';
type HeaderMenuButtonBaseProps = Omit<ComponentProps<'button'>, 'title' | 'type'>;
export interface HeaderMenuButtonProps extends HeaderMenuButtonBaseProps {
    'aria-label'?: string;
    'aria-labelledby'?: string;
    className?: string;
    renderMenuIcon?: JSX.Element;
    renderCloseIcon?: JSX.Element;
    isActive?: boolean;
    isCollapsible?: boolean;
}
declare function HeaderMenuButton({ 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledBy, className: customClassName, renderMenuIcon, renderCloseIcon, isActive, isCollapsible, ...rest }: HeaderMenuButtonProps): import("react/jsx-runtime").JSX.Element;
declare namespace HeaderMenuButton {
    var propTypes: {
        /**
         * Optionally provide a custom class name that is applied to the underlying
         * button
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether the menu button is "active".
         */
        isActive: PropTypes.Requireable<boolean>;
        /**
         * Specify whether the menu button is collapsible.
         */
        isCollapsible: PropTypes.Requireable<boolean>;
        /**
         * Optionally provide an onClick handler that is called when the underlying
         * button fires it's onclick event
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
    };
}
export default HeaderMenuButton;
