/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { ReactNode } from 'react';
export interface HeaderGlobalActionProps {
    /**
     * Required props for the accessibility label of the button
     */
    'aria-label'?: string;
    /**
     * Required props for the accessibility label of the button
     */
    'aria-labelledby'?: string;
    /**
     * Provide a custom icon for this global action
     */
    children: ReactNode;
    /**
     * Optionally provide a custom class name that is applied to the underlying
     * button
     */
    className?: string;
    /**
     * Specify whether the action is currently active
     */
    isActive?: boolean;
    /**
     * Optionally provide an onClick handler that is called when the underlying
     * button fires it's onclick event
     */
    onClick?: () => void;
    /**
     * Specify the alignment of the tooltip to the icon-only button.
     * Can be one of: start, center, or end.
     */
    tooltipAlignment?: 'start' | 'center' | 'end';
    /**
     * Enable drop shadow for tooltips for icon-only buttons.
     */
    tooltipDropShadow?: boolean;
    /**
     * Render the tooltip using the high-contrast theme
     * Default is true
     */
    tooltipHighContrast?: boolean;
}
/**
 * HeaderGlobalAction is used as a part of the `HeaderGlobalBar`. It is
 * essentially an Icon Button with an additional state to indicate whether it is
 * "active". The active state comes from when a user clicks on the global action
 * which should trigger a panel to appear.
 *
 * Note: children passed to this component should be an Icon.
 */
declare const HeaderGlobalAction: React.ForwardRefExoticComponent<HeaderGlobalActionProps & React.RefAttributes<HTMLButtonElement>>;
export default HeaderGlobalAction;
