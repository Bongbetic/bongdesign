/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { ReactNode } from 'react';
export interface HeaderProps {
    children?: ReactNode;
    /**
     * Optionally provide aria-label
     */
    'aria-label'?: string;
    /**
     * Optionally provide aria-labelledby
     */
    'aria-labelledby'?: string;
    /**
     * Optionally provide a custom class name that is applied to the underlying header
     */
    className?: string;
}
declare const Header: {
    ({ className: customClassName, children, ...rest }: HeaderProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Optionally provide aria-label
         */
        'aria-label': PropTypes.Requireable<string>;
        /**
         * Optionally provide aria-labelledby
         */
        'aria-labelledby': PropTypes.Requireable<string>;
        /**
         * Optionally provide a custom class name that is applied to the underlying header
         */
        className: PropTypes.Requireable<string>;
    };
};
export default Header;
