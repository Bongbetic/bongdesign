/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { WeakValidationMap } from 'prop-types';
import { type ComponentProps, type ReactNode, ElementType, JSX } from 'react';
import { PolymorphicComponentPropWithRef } from '../../internal/PolymorphicProps';
export interface HeaderMenuItemBaseProps {
    className?: string | undefined;
    isActive?: boolean | undefined;
    isCurrentPage?: boolean | undefined;
    'aria-current'?: string | undefined;
    children: ReactNode;
    role?: ComponentProps<'li'>['role'];
    tabIndex?: number | undefined;
}
export type HeaderMenuItemProps<E extends ElementType = 'a'> = PolymorphicComponentPropWithRef<E, HeaderMenuItemBaseProps>;
export interface HeaderMenuItemComponent {
    <E extends ElementType = 'a'>(props: HeaderMenuItemProps<E>): JSX.Element | null;
    displayName?: string;
    propTypes?: WeakValidationMap<HeaderMenuItemProps<any>>;
}
declare const HeaderMenuItem: HeaderMenuItemComponent;
export default HeaderMenuItem;
