/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type ElementType } from 'react';
import PropTypes from 'prop-types';
import { type LinkProps } from './Link';
export type HeaderNameProps<E extends ElementType> = LinkProps<E> & {
    prefix?: string | undefined;
};
declare function HeaderName<E extends ElementType = 'a'>({ children, className: customClassName, prefix, ...rest }: HeaderNameProps<E>): import("react/jsx-runtime").JSX.Element;
declare namespace HeaderName {
    var propTypes: {
        /**
         * Pass in children that are either a string or can be read as a string by
         * screen readers
         */
        children: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Optionally provide a custom class to apply to the underlying `<li>` node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Provide an href for the name to link to
         */
        href: PropTypes.Requireable<string>;
        /**
         * Optionally specify a prefix to your header name. Useful for companies, for
         * example: IBM [Product Name] versus solely [Product Name]
         */
        prefix: PropTypes.Requireable<string>;
        as: PropTypes.Requireable<PropTypes.ReactComponentLike>;
        element: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
        isSideNavExpanded: PropTypes.Requireable<boolean>;
    };
}
export default HeaderName;
