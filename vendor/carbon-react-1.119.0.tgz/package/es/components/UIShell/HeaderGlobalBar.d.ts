/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Generic container for `HeaderGlobalAction` components
 */
declare const HeaderGlobalBar: (props: import("react").HTMLAttributes<"div">) => import("react").ReactElement;
export default HeaderGlobalBar;
