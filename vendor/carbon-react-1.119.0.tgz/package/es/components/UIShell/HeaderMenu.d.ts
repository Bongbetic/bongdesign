/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type FocusEvent, type KeyboardEvent, type MouseEvent, type ReactNode, type Ref } from 'react';
export interface HeaderMenuProps {
    /**
     * Required props for the accessibility label of the menu
     */
    'aria-label'?: string;
    'aria-labelledby'?: string;
    /**
     * Optionally provide a custom class to apply to the underlying `<li>` node
     */
    className?: string;
    /**
     * Provide a custom ref handler for the menu button
     */
    focusRef?: Ref<any>;
    /**
     * Applies selected styles to the item if a user sets this to true and `aria-current !== 'page'`.
     */
    isActive?: boolean;
    /**
     * Applies selected styles to the item if a user sets this to true and `aria-current !== 'page'`.
     * @deprecated Please use `isActive` instead. This will be removed in the next major release.
     */
    isCurrentPage?: boolean;
    /**
     * Provide a label for the link text
     */
    menuLinkName: string;
    /**
     * Optionally provide an onBlur handler that is called when the underlying
     * button fires it's onblur event
     */
    onBlur?: (event: FocusEvent<HTMLLIElement>) => void;
    /**
     * Optionally provide an onClick handler that is called when the underlying
     * button fires it's onclick event
     */
    onClick?: (event: MouseEvent<HTMLLIElement>) => void;
    /**
     * Optionally provide an onKeyDown handler that is called when the underlying
     * button fires it's onkeydown event
     */
    onKeyDown?: (event: KeyboardEvent<HTMLLIElement>) => void;
    /**
     * Optional component to render instead of string
     */
    renderMenuContent?: () => ReactNode;
    /**
     * Optionally provide a tabIndex for the underlying menu button
     */
    tabIndex?: number;
    /**
     * The children should be a series of `HeaderMenuItem` components.
     */
    children?: ReactNode;
}
export declare const HeaderMenu: React.ForwardRefExoticComponent<HeaderMenuProps & React.RefAttributes<HTMLLIElement>>;
export default HeaderMenu;
