/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
import { ButtonSize } from './Button';
export interface ButtonSkeletonProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * Optionally specify an href for your Button to become an `<a>` element
     */
    href?: string;
    /**
     * Specify the size of the button, from a list of available sizes.
     */
    size?: ButtonSize;
    /**
     * @deprecated This property will be removed in the next major Carbon version,
     * use size={sm} instead.
     *
     * Specify whether the Button should be a small variant
     */
    small?: boolean;
}
declare const ButtonSkeleton: {
    ({ className, small, href, size, ...rest }: ButtonSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Optionally specify an href for your Button to become an `<a>` element
         */
        href: PropTypes.Requireable<string>;
        /**
         * Specify the size of the button, from a list of available sizes.
         * For `default` buttons, this prop can remain unspecified or use `default`.
         * In the next major release of Carbon, `default`, `field`, and `small` will be removed
         */
        size: PropTypes.Requireable<string>;
        /**
         * @deprecated This property will be removed in the next major Carbon version,
         * use size={sm} instead.
         *
         * Specify whether the Button should be a small variant
         */
        small: PropTypes.Requireable<boolean>;
    };
};
export default ButtonSkeleton;
export { ButtonSkeleton };
