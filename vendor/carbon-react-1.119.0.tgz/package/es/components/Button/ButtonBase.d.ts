/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type JSX } from 'react';
import { ButtonProps } from './Button';
declare const ButtonBase: React.ForwardRefExoticComponent<Omit<ButtonProps<React.ElementType<any, keyof JSX.IntrinsicElements>>, "ref"> & React.RefAttributes<unknown>>;
export default ButtonBase;
