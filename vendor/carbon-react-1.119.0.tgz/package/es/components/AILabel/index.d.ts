/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
import { ToggletipBaseProps } from '../Toggletip';
import type { DeprecatedPopoverAlignment, NewPopoverAlignment, PopoverAlignment } from '../Popover';
export type AILabelContentProps = React.HTMLAttributes<HTMLSpanElement>;
export declare const AILabelContent: {
    ({ className, children, }: AILabelContentProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
    propTypes: {
        /**
         * Specify the content you want rendered inside the AILabel ToggleTip
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify an optional className to be added to the AILabel callout
         */
        className: PropTypes.Requireable<string>;
    };
};
export type AILabelActionsProps = React.HTMLAttributes<HTMLSpanElement>;
export declare const AILabelActions: {
    ({ className, children, }: AILabelActionsProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
    propTypes: {
        /**
         * Specify the content you want rendered inside the AILabel callout toolbar
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify an optional className to be added to the AILabel toolbar
         */
        className: PropTypes.Requireable<string>;
    };
};
/**
 * Deprecated popover alignment values.
 * @deprecated Use NewPopoverAlignment instead.
 */
export type DeprecatedAlignment = DeprecatedPopoverAlignment;
export type NewAlignment = NewPopoverAlignment;
export type Alignment = PopoverAlignment;
export interface AILabelProps extends ToggletipBaseProps {
    AILabelContent?: React.ReactNode;
    aiText?: string;
    aiTextLabel?: string;
    textLabel?: string;
    kind?: 'default' | 'inline';
    onRevertClick?: (evt: React.MouseEvent<HTMLButtonElement>) => void;
    revertActive?: boolean;
    revertLabel?: string;
    size?: 'mini' | '2xs' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
    'aria-label'?: string;
    slugLabel?: string;
}
export declare const AILabel: React.ForwardRefExoticComponent<AILabelProps & React.RefAttributes<HTMLDivElement>>;
