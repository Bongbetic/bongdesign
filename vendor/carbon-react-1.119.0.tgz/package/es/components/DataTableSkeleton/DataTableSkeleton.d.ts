/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type TableHTMLAttributes } from 'react';
import { DataTableSize } from '../DataTable/DataTable';
export interface DataTableSkeletonHeader {
    /**
     * Specify header label
     */
    header: React.ReactNode;
    /**
     * Optionally specify header key
     */
    key?: string;
}
export interface DataTableSkeletonProps extends TableHTMLAttributes<HTMLTableElement> {
    /**
     * Specify the number of columns that you want to render in the skeleton state
     */
    columnCount?: number;
    /**
     * Optionally specify the displayed headers
     */
    headers?: DataTableSkeletonHeader[];
    /**
     * Specify the number of rows that you want to render in the skeleton state
     */
    rowCount?: number;
    /**
     * Specify if the table header should be rendered as part of the skeleton.
     */
    showHeader?: boolean;
    /**
     * Specify if the table toolbar should be rendered as part of the skeleton.
     */
    showToolbar?: boolean;
    /**
     * Specify a label to be read by screen readers on the toolbar region.
     */
    toolbarLabel?: string;
    /**
     * Changes the row height of table.
     */
    size?: DataTableSize;
    /**
     * Optionally specify whether you want the DataTable to be zebra striped
     */
    zebra?: boolean;
    /**
     * Optionally specify whether you want the DataTable to be styled
     */
    className?: string;
}
declare const DataTableSkeleton: {
    ({ headers, rowCount, columnCount, zebra, className, showHeader, showToolbar, toolbarLabel, size, ...rest }: DataTableSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the number of columns that you want to render in the skeleton state
         */
        columnCount: PropTypes.Requireable<number>;
        /**
         * Optionally specify the displayed headers
         */
        headers: PropTypes.Requireable<NonNullable<PropTypes.InferProps<{
            header: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        }>>[]>;
        /**
         * Specify the number of rows that you want to render in the skeleton state
         */
        rowCount: PropTypes.Requireable<number>;
        /**
         * Specify if the table header should be rendered as part of the skeleton.
         */
        showHeader: PropTypes.Requireable<boolean>;
        /**
         * Specify if the table toolbar should be rendered as part of the skeleton.
         */
        showToolbar: PropTypes.Requireable<boolean>;
        /**
         * Specify a label to be read by screen readers on the toolbar region.
         */
        toolbarLabel: PropTypes.Requireable<string>;
        /**
         * Changes the row height of table.
         */
        size: PropTypes.Requireable<string>;
        /**
         * Optionally specify whether you want the DataTable to be zebra striped
         */
        zebra: PropTypes.Requireable<boolean>;
    };
};
export default DataTableSkeleton;
