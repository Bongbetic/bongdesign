/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type HTMLAttributes } from 'react';
export interface FileUploaderItemProps extends HTMLAttributes<HTMLSpanElement> {
    /**
     * Specify whether file uploader item is disabled
     */
    disabled?: boolean;
    /**
     * Error message body for an invalid file upload
     */
    errorBody?: string;
    /**
     * Error message subject for an invalid file upload
     */
    errorSubject?: string;
    /**
     * Description of status icon (displayed in native tooltip)
     */
    iconDescription?: string;
    /**
     * Specify if the currently uploaded file is invalid
     */
    invalid?: boolean;
    /**
     * Name of the uploaded file
     */
    name?: string;
    /**
     * Event handler that is called after files are added to the uploader
     */
    onAddFiles?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    /**
     * Event handler that is called after removing a file from the file uploader
     * The event handler signature looks like `onDelete(evt, { uuid })`
     */
    onDelete?: (event: React.SyntheticEvent<HTMLElement>, opts: {
        uuid: string;
    }) => void;
    /**
     * Specify the size of the FileUploaderButton, from a list of available
     * sizes.
     */
    size?: 'sm' | 'md' | 'lg';
    /**
     * Status of the file upload
     */
    status?: 'uploading' | 'edit' | 'complete';
    /**
     * Unique identifier for the file object
     */
    uuid?: string;
}
declare function FileUploaderItem({ uuid, name, status, iconDescription, onDelete, invalid, errorSubject, errorBody, size, className, disabled, ...other }: FileUploaderItemProps): import("react/jsx-runtime").JSX.Element;
declare namespace FileUploaderItem {
    var propTypes: {
        /**
         * Error message body for an invalid file upload
         */
        errorBody: PropTypes.Requireable<string>;
        /**
         * Error message subject for an invalid file upload
         */
        errorSubject: PropTypes.Requireable<string>;
        /**
         * Description of status icon (displayed in native tooltip)
         */
        iconDescription: PropTypes.Requireable<string>;
        /**
         * Specify if the currently uploaded file is invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Name of the uploaded file
         */
        name: PropTypes.Requireable<string>;
        /**
         * Event handler that is called after removing a file from the file uploader
         * The event handler signature looks like `onDelete(evt, { uuid })`
         */
        onDelete: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Specify the size of the FileUploaderButton, from a list of available
         * sizes.
         */
        size: PropTypes.Requireable<string>;
        /**
         * Status of the file upload
         */
        status: PropTypes.Requireable<string>;
        /**
         * Unique identifier for the file object
         */
        uuid: PropTypes.Requireable<string>;
    };
}
export default FileUploaderItem;
