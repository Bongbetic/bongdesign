/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type HTMLAttributes } from 'react';
export type FilenameStatus = 'edit' | 'complete' | 'uploading';
type SVGAttr = React.SVGAttributes<SVGSVGElement>;
export interface FilenameProps extends Omit<HTMLAttributes<HTMLElement> & SVGAttr, 'tabIndex' | 'type'> {
    /**
     * Specify an id that describes the error to be read by screen readers when the filename is invalid
     */
    ['aria-describedby']?: string;
    /**
     * Provide a description of the SVG icon to denote file upload status
     */
    iconDescription?: string;
    /**
     * Specify whether the file uploader item is disabled
     */
    disabled?: boolean;
    /**
     * Specify if the file is invalid
     */
    invalid?: boolean;
    /**
     * Name of the uploaded file
     */
    name?: string;
    /**
     * Status of the file upload
     */
    status?: FilenameStatus;
    /**
     * Provide a custom tabIndex value for the `<Filename>`
     */
    tabIndex?: number;
}
declare function Filename({ iconDescription, status, invalid, disabled, name, tabIndex, ['aria-describedby']: ariaDescribedBy, ...rest }: FilenameProps): import("react/jsx-runtime").JSX.Element | null;
declare namespace Filename {
    var propTypes: {
        /**
         * Specify an id that describes the error to be read by screen readers when the filename is invalid
         */
        "aria-describedby": PropTypes.Requireable<string>;
        /**
         * Provide a description of the SVG icon to denote file upload status
         */
        iconDescription: PropTypes.Requireable<string>;
        /**
         * Specify if the file is invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Name of the uploaded file
         */
        name: PropTypes.Requireable<string>;
        /**
         * Status of the file upload
         */
        status: PropTypes.Requireable<string>;
        /**
         * Provide a custom tabIndex value for the `<Filename>`
         */
        tabIndex: PropTypes.Requireable<number>;
    };
}
export default Filename;
