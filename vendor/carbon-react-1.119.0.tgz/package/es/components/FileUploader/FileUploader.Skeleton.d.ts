/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type HTMLAttributes } from 'react';
export interface FileUploaderSkeletonProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Specify an optional className to add.
     */
    className?: string;
}
declare function FileUploaderSkeleton({ className, ...rest }: FileUploaderSkeletonProps): import("react/jsx-runtime").JSX.Element;
declare namespace FileUploaderSkeleton {
    var propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
    };
}
export default FileUploaderSkeleton;
export { FileUploaderSkeleton };
