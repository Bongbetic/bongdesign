/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type HTMLAttributes } from 'react';
import PropTypes from 'prop-types';
export interface FileUploaderDropContainerProps extends Omit<HTMLAttributes<HTMLButtonElement>, 'tabIndex'> {
    /**
     * Specify the types of files that this input should be able to receive
     */
    accept?: string[];
    /**
     * Provide a custom className to be applied to the container node
     */
    className?: string;
    /**
     * Specify whether file input is disabled
     */
    disabled?: boolean;
    /**
     * Provide a unique id for the underlying `<input>` node
     */
    id?: string;
    /**
     * Provide the label text to be read by screen readers when interacting with
     * this control
     */
    labelText?: string;
    /**
     * Maximum file size allowed in bytes. Files larger than this will be marked invalid
     */
    maxFileSize?: number;
    /**
     * Specify if the component should accept multiple files to upload
     */
    multiple?: boolean;
    /**
     * Provide a name for the underlying `<input>` node
     */
    name?: string;
    /**
     * Event handler that is called after files are added to the uploader
     */
    onAddFiles?: (event: React.SyntheticEvent<HTMLElement>, content: {
        addedFiles: AddedFile[];
    }) => void;
    /**
     * Provide an optional function to be called when the button element
     * is clicked
     */
    onClick?: () => void;
    /**
     * Provide a custom regex pattern for the acceptedTypes
     */
    pattern?: string;
    /**
     * Specify if the file input is required
     */
    required?: boolean;
    /**
     * Ref to pass to the inner button element
     */
    innerRef?: React.Ref<HTMLButtonElement>;
    /**
     * @deprecated The `role` prop for `FileUploaderButton` has been deprecated since it now renders a button element by default, and has an implicit role of button.
     */
    role?: string;
    /**
     * @deprecated The `tabIndex` prop for `FileUploaderButton` has been deprecated since it now renders a button element by default.
     */
    tabIndex?: number | string;
}
interface AddedFile extends File {
    invalidFileType?: boolean;
}
declare function FileUploaderDropContainer({ accept, className, id, disabled, labelText, maxFileSize, multiple, name, onAddFiles, onClick, pattern, required, innerRef, ...rest }: FileUploaderDropContainerProps): import("react/jsx-runtime").JSX.Element;
declare namespace FileUploaderDropContainer {
    var propTypes: {
        /**
         * Specify the types of files that this input should be able to receive
         */
        accept: PropTypes.Requireable<(string | null | undefined)[]>;
        /**
         * Provide a custom className to be applied to the container node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether file input is disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Provide a unique id for the underlying `<input>` node
         */
        id: PropTypes.Requireable<string>;
        /**
         * Provide the label text to be read by screen readers when interacting with
         * this control
         */
        labelText: PropTypes.Validator<string>;
        /**
         * Maximum file size allowed in bytes. Files larger than this will be marked invalid
         */
        maxFileSize: PropTypes.Requireable<number>;
        /**
         * Specify if the component should accept multiple files to upload
         */
        multiple: PropTypes.Requireable<boolean>;
        /**
         * Provide a name for the underlying `<input>` node
         */
        name: PropTypes.Requireable<string>;
        /**
         * Event handler that is called after files are added to the uploader
         * The event handler signature looks like `onAddFiles(evt, { addedFiles })`
         */
        onAddFiles: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Provide an optional function to be called when the button element
         * is clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Provide a custom regex pattern for the acceptedTypes
         */
        pattern: PropTypes.Requireable<string>;
        /**
         * Specify if the file input is required
         */
        required: PropTypes.Requireable<boolean>;
        /**
         * Provide an accessibility role for the `<FileUploaderButton>`
         */
        role: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
        /**
         * Provide a custom tabIndex value for the `<FileUploaderButton>`
         */
        tabIndex: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
    };
}
export default FileUploaderDropContainer;
