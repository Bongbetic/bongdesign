/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React, { type HTMLAttributes } from 'react';
export interface FileUploaderButtonProps extends Omit<HTMLAttributes<HTMLButtonElement>, 'onChange' | 'tabIndex'> {
    /**
     * Specify the types of files that this input should be able to receive
     */
    accept?: string[];
    /**
     * Specify the type of underlying button
     */
    buttonKind?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'danger--primary' | 'danger--ghost' | 'danger--tertiary' | 'tertiary';
    /**
     * Provide a custom className to be applied to the container node
     */
    className?: string;
    /**
     * Specify whether you want to disable any updates to the FileUploaderButton
     * label
     */
    disableLabelChanges?: boolean;
    /**
     * Specify whether file input is disabled
     */
    disabled?: boolean;
    /**
     * Provide a unique id for the underlying `<input>` node
     */
    id?: string;
    /**
     * Provide the label text to be read by screen readers when interacting with
     * this control
     */
    labelText?: React.ReactNode;
    /**
     * Specify if the component should accept multiple files to upload
     */
    multiple?: boolean;
    /**
     * Provide a name for the underlying `<input>` node
     */
    name?: string;
    /**
     * Provide an optional `onChange` hook that is called each time the `<input>`
     * value changes
     */
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    /**
     * Provide an optional `onClick` hook that is called each time the button is
     * clicked
     */
    onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * Provide an accessibility role for the `<FileUploaderButton>`
     */
    role?: string;
    /**
     * Specify the size of the FileUploaderButton, from a list of available
     * sizes.
     */
    size?: 'sm' | 'small' | 'field' | 'md' | 'lg';
    /**
     * @deprecated The `tabIndex` prop for `FileUploaderButton` has been deprecated since it now renders a button element by default.
     */
    tabIndex?: number | string;
    innerRef?: React.RefObject<HTMLLabelElement | null>;
}
declare function FileUploaderButton({ accept, buttonKind, className, disabled, disableLabelChanges, id, labelText: ownerLabelText, multiple, onChange, name, size, innerRef, ...other }: FileUploaderButtonProps): import("react/jsx-runtime").JSX.Element;
declare namespace FileUploaderButton {
    var propTypes: {
        /**
         * Specify the types of files that this input should be able to receive
         */
        accept: PropTypes.Requireable<(string | null | undefined)[]>;
        /**
         * Specify the type of underlying button
         */
        buttonKind: PropTypes.Requireable<"primary" | "secondary" | "danger" | "ghost" | "danger--primary" | "danger--ghost" | "danger--tertiary" | "tertiary">;
        /**
         * Provide a custom className to be applied to the container node
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify whether you want to disable any updates to the FileUploaderButton
         * label
         */
        disableLabelChanges: PropTypes.Requireable<boolean>;
        /**
         * Specify whether file input is disabled
         */
        disabled: PropTypes.Requireable<boolean>;
        /**
         * Provide a unique id for the underlying `<input>` node
         */
        id: PropTypes.Requireable<string>;
        /**
         * Provide the label text to be read by screen readers when interacting with
         * this control
         */
        labelText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify if the component should accept multiple files to upload
         */
        multiple: PropTypes.Requireable<boolean>;
        /**
         * Provide a name for the underlying `<input>` node
         */
        name: PropTypes.Requireable<string>;
        /**
         * Provide an optional `onChange` hook that is called each time the `<input>`
         * value changes
         */
        onChange: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Provide an optional `onClick` hook that is called each time the button is
         * clicked
         */
        onClick: PropTypes.Requireable<(...args: any[]) => any>;
        /**
         * Provide an accessibility role for the `<FileUploaderButton>`
         */
        role: PropTypes.Requireable<string>;
        /**
         * Specify the size of the FileUploaderButton, from a list of available
         * sizes.
         */
        size: PropTypes.Requireable<string>;
        /**
         * Provide a custom tabIndex value for the `<FileUploaderButton>`
         */
        tabIndex: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
    };
}
export default FileUploaderButton;
