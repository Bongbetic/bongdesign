/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { HTMLAttributes } from 'react';
declare const CheckboxSkeleton: {
    ({ className, ...rest }: HTMLAttributes<HTMLDivElement>): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
    };
};
export default CheckboxSkeleton;
export { CheckboxSkeleton };
