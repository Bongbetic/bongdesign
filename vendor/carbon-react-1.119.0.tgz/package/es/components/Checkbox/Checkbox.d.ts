/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ReactNode } from 'react';
type ExcludedAttributes = 'id' | 'onChange' | 'onClick' | 'type';
export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, ExcludedAttributes> {
    /**
     * Provide an `id` to uniquely identify the Checkbox input
     */
    id: string;
    /**
     * Provide a label to provide a description of the Checkbox input that you are
     * exposing to the user
     */
    labelText: NonNullable<ReactNode>;
    /**
     * **Experimental**: Provide a `decorator` component to be rendered inside the `Checkbox` component
     */
    decorator?: ReactNode;
    /**
     * Specify whether the underlying input should be checked by default
     */
    defaultChecked?: boolean;
    /**
     * Specify whether the Checkbox should be disabled
     */
    disabled?: boolean;
    /**
     * Provide text for the form group for additional help
     */
    helperText?: ReactNode;
    /**
     * Specify whether the label should be hidden, or not
     */
    hideLabel?: boolean;
    /**
     * Specify whether the Checkbox is in an indeterminate state
     */
    indeterminate?: boolean;
    /**
     * Specify whether the Checkbox is currently invalid
     */
    invalid?: boolean;
    /**
     * Provide the text that is displayed when the Checkbox is in an invalid state
     */
    invalidText?: ReactNode;
    /**
     * @deprecated please use decorator instead.
     * **Experimental**: Provide a `Slug` component to be rendered inside the `Checkbox` component
     */
    slug?: ReactNode;
    /**
     * Specify whether the Checkbox is currently invalid
     */
    warn?: boolean;
    /**
     * Provide the text that is displayed when the Checkbox is in an invalid state
     */
    warnText?: ReactNode;
    /**
     * Provide an optional handler that is called when the internal state of
     * Checkbox changes. This handler is called with event and state info.
     * `(event, { checked, id }) => void`
     */
    onChange?: (evt: React.ChangeEvent<HTMLInputElement>, data: {
        checked: boolean;
        id: string;
    }) => void;
    /**
     * Provide an optional onClick handler that is called on click
     */
    onClick?: (evt: React.MouseEvent<HTMLInputElement>) => void;
}
declare const Checkbox: React.ForwardRefExoticComponent<CheckboxProps & React.RefAttributes<unknown>>;
export default Checkbox;
