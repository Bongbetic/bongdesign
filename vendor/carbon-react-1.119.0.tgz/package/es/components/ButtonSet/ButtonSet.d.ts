/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
export interface ButtonSetProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * fluid: button set resize to the size of the container up to a maximum dependent on the
     * number of buttons. Overrides `stacked` property.
     */
    fluid?: boolean;
    /**
     * Specify the button arrangement of the set (vertically stacked or
     * horizontal)
     */
    stacked?: boolean;
}
declare const ButtonSet: React.ForwardRefExoticComponent<ButtonSetProps & React.RefAttributes<HTMLDivElement>>;
export default ButtonSet;
