/**
 * Copyright IBM Corp. 2024, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ComponentProps } from 'react';
import Button from '../Button';
export type ChatButtonKind = 'primary' | 'secondary' | 'danger' | 'ghost' | 'tertiary';
export type ChatButtonSize = 'sm' | 'md' | 'lg';
export interface ChatButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    /**
     * Provide the contents of your Select
     */
    children?: React.ReactNode;
    /**
     * Specify an optional className to be applied to the node containing the label and the select box
     */
    className?: string;
    /**
     * Specify whether the `ChatButton` should be disabled
     */
    disabled?: boolean;
    /**
     * Specify whether the `ChatButton` should be rendered as a quick action button
     */
    isQuickAction?: boolean;
    /**
     * Specify whether the quick action `ChatButton` should be rendered as selected. This disables the input
     */
    isSelected?: boolean;
    /**
     * Specify the kind of `ChatButton` you want to create
     */
    kind?: ChatButtonKind;
    /**
     * A component used to render an icon.
     */
    renderIcon?: ComponentProps<typeof Button>['renderIcon'];
    /**
     * Specify the size of the `ChatButton`, from the following list of sizes:
     */
    size?: ChatButtonSize;
}
declare const ChatButton: React.ForwardRefExoticComponent<ChatButtonProps & React.RefAttributes<HTMLButtonElement>>;
export default ChatButton;
