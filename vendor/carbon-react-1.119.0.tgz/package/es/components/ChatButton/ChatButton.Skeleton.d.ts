/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface ChatButtonSkeletonProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * Specify the size of the `ChatButtonSkeleton`, from the following list of sizes:
     */
    size?: 'sm' | 'md' | 'lg';
}
declare const ChatButtonSkeleton: {
    ({ className, size, ...rest }: ChatButtonSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * Specify the size of the `ChatButtonSkeleton`, from the following list of sizes:
         */
        size: PropTypes.Requireable<string>;
    };
};
export default ChatButtonSkeleton;
