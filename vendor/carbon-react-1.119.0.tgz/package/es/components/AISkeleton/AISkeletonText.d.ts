/**
 * Copyright IBM Corp. 2016, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface AISkeletonTextProps {
    /**
     * Specify an optional className to be applied to the container node.
     */
    className?: string;
    /**
     * Generates skeleton text at a larger size.
     */
    heading?: boolean;
    /**
     * The number of lines shown if paragraph is true.
     */
    lineCount?: number;
    /**
     * Set this to true to generate multiple lines of text.
     */
    paragraph?: boolean;
    /**
     * Width (in px or %) of single line of text or max-width of paragraph lines.
     */
    width?: string;
}
declare const AISkeletonText: {
    ({ className, ...rest }: AISkeletonTextProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to be applied to the container node
         */
        className: PropTypes.Requireable<string>;
        /**
         * generates skeleton text at a larger size
         */
        heading: PropTypes.Requireable<boolean>;
        /**
         * the number of lines shown if paragraph is true
         */
        lineCount: PropTypes.Requireable<number>;
        /**
         * will generate multiple lines of text
         */
        paragraph: PropTypes.Requireable<boolean>;
        /**
         * width (in px or %) of single line of text or max-width of paragraph lines
         */
        width: PropTypes.Requireable<string>;
    };
};
export default AISkeletonText;
