/**
 * Copyright IBM Corp. 2016, 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import React from 'react';
export interface AISkeletonIconProps {
    /**
     * Specify an optional className to add.
     */
    className?: string;
    /**
     * The CSS styles.
     */
    style?: React.CSSProperties;
}
declare const AISkeletonIcon: {
    ({ className, ...rest }: AISkeletonIconProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to add.
         */
        className: PropTypes.Requireable<string>;
        /**
         * The CSS styles.
         */
        style: PropTypes.Requireable<object>;
    };
};
export default AISkeletonIcon;
