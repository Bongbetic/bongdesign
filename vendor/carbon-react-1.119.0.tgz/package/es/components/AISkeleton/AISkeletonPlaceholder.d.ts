/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface AISkeletonPlaceholderProps {
    /**
     * Add a custom class to the component to set the height and width
     */
    className?: string;
}
declare const AISkeletonPlaceholder: {
    ({ className, ...other }: AISkeletonPlaceholderProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Add a custom class to the component
         * to set the height and width
         */
        className: PropTypes.Requireable<string>;
    };
};
export default AISkeletonPlaceholder;
