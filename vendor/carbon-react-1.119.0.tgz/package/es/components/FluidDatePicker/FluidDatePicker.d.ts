/**
 * Copyright IBM Corp. 2022, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React from 'react';
export interface FluidDatePickerProps {
    /**
     * The child node(s)
     */
    children?: React.ReactNode;
    /**
     * Specify an optional className to be applied to the outer FluidForm wrapper
     */
    className?: string;
    /**
     * Specify whether or not the control is invalid
     */
    invalid?: boolean;
    /**
     * Provide the text that is displayed when the control is in error state
     */
    invalidText?: React.ReactNode;
    /**
     * Whether the input should be read-only
     */
    readOnly?: boolean;
    /**
     * Specify whether the control is currently in warning state
     */
    warn?: boolean;
    /**
     * Provide the text that is displayed when the control is in warning state
     */
    warnText?: React.ReactNode;
}
declare const FluidDatePicker: React.ForwardRefExoticComponent<FluidDatePickerProps & React.RefAttributes<HTMLInputElement>>;
export default FluidDatePicker;
