/**
 * Copyright IBM Corp. 2016, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
import { type ReactNode } from 'react';
export interface CheckboxGroupProps {
    children?: ReactNode;
    className?: string;
    decorator?: ReactNode;
    helperText?: ReactNode;
    invalid?: boolean;
    invalidText?: ReactNode;
    legendId?: ReactNode;
    orientation?: 'horizontal' | 'vertical';
    legendText: ReactNode;
    readOnly?: boolean;
    disabled?: boolean;
    /**
     * * @deprecated please use decorator instead.
     * **Experimental**: Provide a `Slug` component to be rendered inside the `Checkbox` component
     */
    slug?: ReactNode;
    warn?: boolean;
    warnText?: ReactNode;
}
export interface CustomType {
    size: string;
    kind: string;
}
declare const CheckboxGroup: {
    ({ children, className, decorator, helperText, invalid, invalidText, legendId, legendText, readOnly, disabled, warn, warnText, slug, orientation, ...rest }: CheckboxGroupProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Provide the children form elements to be rendered inside of the <fieldset>
         */
        children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide a custom className to be applied to the containing <fieldset> node
         */
        className: PropTypes.Requireable<string>;
        /**
         * **Experimental**: Provide a decorator component to be rendered inside the `CheckboxGroup` component
         */
        decorator: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide text for the form group for additional help
         */
        helperText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Specify whether the form group is currently invalid
         */
        invalid: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the form group is in an invalid state
         */
        invalidText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide id for the fieldset <legend> which corresponds to the fieldset
         * `aria-labelledby`
         */
        legendId: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        /**
         * Provide the text to be rendered inside of the fieldset <legend>
         */
        legendText: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
        /**
         * Provide the orientation for how the checkbox should be displayed
         */
        orientation: PropTypes.Requireable<string>;
        /**
         * Whether the CheckboxGroup should be read-only
         */
        readOnly: PropTypes.Requireable<boolean>;
        /**
         * **Experimental**: Provide a `Slug` component to be rendered inside the `CheckboxGroup` component
         */
        slug: (props: Record<string, any>, propName: string, componentName: string, ...rest: any[]) => any;
        /**
         * Specify whether the form group is currently in warning state
         */
        warn: PropTypes.Requireable<boolean>;
        /**
         * Provide the text that is displayed when the form group is in warning state
         */
        warnText: PropTypes.Requireable<PropTypes.ReactNodeLike>;
    };
};
export default CheckboxGroup;
