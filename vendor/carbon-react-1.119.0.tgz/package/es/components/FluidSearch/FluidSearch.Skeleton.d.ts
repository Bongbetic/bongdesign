/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import PropTypes from 'prop-types';
export interface FluidSearchSkeletonProps {
    /**
     * Specify an optional className to be applied to the outer FluidForm wrapper
     */
    className?: string;
}
declare const FluidSearchSkeleton: {
    ({ className, ...other }: FluidSearchSkeletonProps): import("react/jsx-runtime").JSX.Element;
    propTypes: {
        /**
         * Specify an optional className to be applied to the outer FluidForm wrapper
         */
        className: PropTypes.Requireable<string>;
    };
};
export default FluidSearchSkeleton;
