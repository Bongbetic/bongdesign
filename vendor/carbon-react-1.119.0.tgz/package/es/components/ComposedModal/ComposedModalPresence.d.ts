/**
 * Copyright IBM Corp. 2016, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import React, { type ComponentType, type PropsWithChildren } from 'react';
import { type PresenceContext } from '../../internal/usePresenceContext';
import { useComposedModalState } from './useComposedModalState';
export interface ComposedModalPresenceProps {
    /**
     * Specify whether the Modal is currently open
     */
    open: boolean;
    /**
     * Internal property for backwards compatibility. Specify whether the Modal should opt in to presence mode.
     */
    _autoEnablePresence?: boolean;
    /**
     * Internal property to predefine the presence context's id for exclusivity.
     */
    _presenceId?: string;
}
export declare const ComposedModalPresence: ({ open, _presenceId: presenceId, _autoEnablePresence: autoEnablePresence, children, }: PropsWithChildren<ComposedModalPresenceProps>) => import("react/jsx-runtime").JSX.Element | null;
interface ComposedModalPresenceContextProps extends PresenceContext {
    modalState: ReturnType<typeof useComposedModalState>;
    autoEnablePresence: boolean;
}
export declare const ComposedModalPresenceContext: React.Context<ComposedModalPresenceContextProps | undefined>;
/**
 * Handles occurrences where only a single composed modal must consume a context.
 */
export declare const useExclusiveComposedModalPresenceContext: (id: string) => ComposedModalPresenceContextProps | undefined;
type WithComposedModalPresenceProps = Pick<ComposedModalPresenceProps, 'open'>;
/**
 * Higher-order function that wraps a component with ComposedModalPresence
 */
export declare const withComposedModalPresence: <TProps extends object>(Component: ComponentType<TProps>) => {
    ({ open, ...componentProps }: TProps & WithComposedModalPresenceProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export {};
