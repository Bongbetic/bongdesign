/**
 * Copyright IBM Corp. 2016, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import ComposedModal from './ComposedModal';
export { default as ComposedModal, type ComposedModalProps, ModalBody, type ModalBodyProps, } from './ComposedModal';
export { ComposedModalPresence, withComposedModalPresence, type ComposedModalPresenceProps, } from './ComposedModalPresence';
export { ModalHeader, type ModalHeaderProps } from './ModalHeader';
export { ModalFooter, type ModalFooterProps } from './ModalFooter';
export default ComposedModal;
