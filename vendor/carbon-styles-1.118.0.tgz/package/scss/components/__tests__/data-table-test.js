/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @jest-environment node
 */

'use strict';

const postcss = require('postcss');
const { SassRenderer } = require('@carbon/test-utils/scss');

const { render } = SassRenderer.create(__dirname);

describe('scss/components/data-table', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
       @use 'sass:map';
       @use 'sass:meta';
       @use '../data-table';

       $_: get('mixin', meta.mixin-exists('data-table', 'data-table'));
       $_: get('variables', map.keys(meta.module-variables('data-table')));
     `);
    expect(unwrap('mixin')).toBe(true);
    expect(unwrap('variables')).toMatchInlineSnapshot(`
      [
        "data-table-column-hover",
      ]
    `);
  });

  test('row hover styles are only applied on devices that support hover', async () => {
    const { result } = await render(`
      @use '../data-table';
      @use '../data-table/expandable';
      @use '../data-table/skeleton';
    `);
    const hoverRules = [];

    postcss.parse(result.css.toString()).walkRules((rule) => {
      if (
        /(?:^|[\s>+~,])tr(?=[.\[:\s])/.test(rule.selector) &&
        rule.selector.includes(':hover')
      ) {
        hoverRules.push(rule);
      }
    });

    expect(hoverRules.length).toBeGreaterThan(0);
    expect(
      hoverRules
        .filter((rule) => {
          let parent = rule.parent;

          while (parent) {
            if (
              parent.type === 'atrule' &&
              parent.name === 'media' &&
              parent.params.includes('(any-hover: hover)')
            ) {
              return false;
            }

            parent = parent.parent;
          }

          return true;
        })
        .map((rule) => rule.selector)
    ).toEqual([]);
  });
});

describe('scss/components/data-table/action', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
         @use 'sass:map';
         @use 'sass:meta';
         @use '../data-table/action';

         $_: get('mixin', meta.mixin-exists('data-table-action', 'action'));
       `);
    expect(unwrap('mixin')).toBe(true);
  });

  test('toolbar hover styles are only applied on devices that support hover', async () => {
    const { result } = await render(`
      @use '../data-table/action';
    `);
    const hoverRules = [];
    const toolbarSelectors = [
      '.cds--toolbar',
      '.cds--action-list',
      '.cds--batch-summary',
    ];

    postcss.parse(result.css.toString()).walkRules((rule) => {
      if (
        rule.selector.includes(':hover') &&
        toolbarSelectors.some((selector) => rule.selector.includes(selector))
      ) {
        hoverRules.push(rule);
      }
    });

    expect(hoverRules.length).toBeGreaterThan(0);
    expect(
      hoverRules.some((rule) =>
        rule.selector.includes('.cds--toolbar-action:hover')
      )
    ).toBe(true);
    expect(
      hoverRules
        .filter((rule) => {
          let parent = rule.parent;

          while (parent) {
            if (
              parent.type === 'atrule' &&
              parent.name === 'media' &&
              parent.params.includes('(any-hover: hover)')
            ) {
              return false;
            }

            parent = parent.parent;
          }

          return true;
        })
        .map((rule) => rule.selector)
    ).toEqual([]);
  });
});

describe('scss/components/data-table/expandable', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
         @use 'sass:map';
         @use 'sass:meta';
         @use '../data-table/expandable';

         $_: get('mixin', meta.mixin-exists('data-table-expandable', 'expandable'));
       `);
    expect(unwrap('mixin')).toBe(true);
  });
});

describe('scss/components/data-table/skeleton', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
         @use 'sass:map';
         @use 'sass:meta';
         @use '../data-table/skeleton';

         $_: get('mixin', meta.mixin-exists('data-table-skeleton', 'skeleton'));
       `);
    expect(unwrap('mixin')).toBe(true);
  });
});

describe('scss/components/data-table/sort', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
         @use 'sass:map';
         @use 'sass:meta';
         @use '../data-table/sort';

         $_: get('mixin', meta.mixin-exists('data-table-sort', 'sort'));
       `);
    expect(unwrap('mixin')).toBe(true);
  });
});
