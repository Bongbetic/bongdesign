/**
 * Copyright IBM Corp. 2018, 2023
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @jest-environment node
 */

'use strict';

const { SassRenderer } = require('@carbon/test-utils/scss');

const { render } = SassRenderer.create(__dirname);

describe('scss/components/list', () => {
  test('Public API', async () => {
    const { unwrap } = await render(`
      @use 'sass:meta';
      @use '../list';

      $_: get('mixin', meta.mixin-exists('list', 'list'));
    `);
    expect(unwrap('mixin')).toBe(true);
  });

  test('ordered list markers are indented within the list container', async () => {
    const { unwrap } = await render(`
      @use '../list';
      @use '../../spacing' as *;

      $_: get('ordered-padding', $spacing-06);
    `);

    expect(unwrap('ordered-padding')).toBe('1.5rem');
  });
});
