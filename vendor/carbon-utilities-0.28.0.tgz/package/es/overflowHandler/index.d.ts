//#region src/overflowHandler/overflowHandler.d.ts
/**
 * Copyright IBM Corp. 2025, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Calculates the size (width or height) of a given HTML element.
 *
 * Temporarily sets `display` if the element is not currently visible so hidden
 * items can still be measured. Adds margin and an optional `gap`.
 *
 * @param el - The HTML element whose size is to be calculated. Returns 0 if
 *   `null` or `undefined` is passed.
 * @param dimension - The dimension to measure ('width' or 'height').
 * @param gap - Optional gap (in px) to add to each item's size, representing the `column-gap` (width) or `row-gap` (height) of the parent container.
 * @returns The size of the element in pixels, or 0 if no element is provided.
 */
export declare function getSize(el: HTMLElement | null | undefined, dimension: 'width' | 'height', gap?: number): number;
/**
 * Options for updating the overflow handler.
 * Determines which items should be visible and which should be hidden
 * based on the container size, item sizes, and other constraints.
 */
export interface UpdateOverflowHandlerOptions {
  /** The container element that holds the items. */
  container: HTMLElement;
  /** An array of item elements to be managed for overflow. */
  items: HTMLElement[];
  /** An element that represents the offset, which can be shown or hidden based on overflow. Identified by `data-offset` attribute. */
  offset: HTMLElement | undefined;
  /** An array of sizes corresponding to each item in the `items` array. */
  sizes: number[];
  /** An array of sizes corresponding to each item in the fixed items array. */
  fixedSizes: number[];
  /** The size of the offset element. */
  offsetSize: number;
  /** The maximum number of items that can be visible at once. If undefined, all items can be visible. */
  maxVisibleItems?: number;
  /** The dimension to consider for overflow, either 'width' or 'height'. */
  dimension: 'width' | 'height';
  /** A callback function that is called when the visible or hidden items change. */
  onChange: (visibleItems: HTMLElement[], hiddenItems: HTMLElement[]) => void;
  /** An array of previously hidden items to compare against the new hidden items. */
  previousHiddenItems?: HTMLElement[];
  /** Pixels to reserve from the container's available space, causing overflow to trigger earlier. */
  offsetValue?: number;
  /** The gap (in px) between items, representing `column-gap` (width) or `row-gap` (height) of the container. */
  gap?: number;
}
/**
 * Updates the overflow handler by determining which items should be visible and which should be hidden.
 *
 * @param options - Configuration options for updating the overflow handler.
 * @returns An array of hidden items after the update.
 */
export declare function updateOverflowHandler({ container, items, offset, sizes, fixedSizes, offsetSize, maxVisibleItems, dimension, onChange, previousHiddenItems, offsetValue, gap }: UpdateOverflowHandlerOptions): HTMLElement[];
/**
 * Options for initializing an overflow handler.
 */
export interface OverflowHandlerOptions {
  /**
   * The container element that holds the items. along with offset item
   */
  container: HTMLElement;
  /**
   * Maximum number of visible items. If provided, only this number of items will be shown.
   */
  maxVisibleItems?: number;
  /**
   * Callback function invoked when the visible and hidden items change.
   * @param visibleItems - The array of items that are currently visible.
   * @param hiddenItems - The array of items that are currently hidden.
   */
  onChange: (visibleItems: HTMLElement[], hiddenItems: HTMLElement[]) => void;
  /**
   * The dimension to consider for overflow calculations. Defaults to 'width'.
   */
  dimension?: 'width' | 'height';
  /**
   * Pixels to reserve from the container's available space, causing overflow to
   * trigger earlier. Useful when an element within the container (e.g. a "show
   * more" button) needs guaranteed room.
   */
  offsetValue?: number;
  /**
   * The gap (in px) between items in the container's flex/grid layout.
   */
  gap?: number;
}
/**
 * Represents an instance of an overflow handler.
 */
export interface OverflowHandler {
  /**
   * Disconnects the overflow handler, cleaning up any event listeners or resources.
   */
  disconnect: () => void;
}
export declare function createOverflowHandler({ container, maxVisibleItems, onChange, dimension, offsetValue, gap }: OverflowHandlerOptions): OverflowHandler;
//#endregion