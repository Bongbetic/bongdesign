//#region src/makeDraggable/makeDraggable.d.ts
/**
 * Copyright IBM Corp. 2025, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
interface DraggableProps {
  /**
   * HTML element to move.
   */
  el: HTMLElement;
  /**
   * HTML element to initiate the drag (e.g., header).
   */
  dragHandle?: HTMLElement;
  /**
   * HTML element to focus on drag for keyboard interaction (e.g., Drag Icon).
   */
  focusableDragHandle?: HTMLElement;
  /**
   * Pixel value that defines the distance to move when dragging with arrow
   * keys.
   */
  dragStep?: number;
  /**
   * Pixel value that defines the distance to move when dragging with
   * shift+arrow keys.
   */
  shiftDragStep?: number;
}
/**
 * Makes a given element draggable using a handle element.
 * @param {object} draggable - Configuration object for draggable behavior
 * @param {HTMLElement} draggable.el - The element to make draggable
 * @param {HTMLElement} [draggable.dragHandle] - Optional handle element for dragging
 * @param {boolean} [draggable.focusableDragHandle] - Whether the drag handle should be focusable
 * @param {number} [draggable.dragStep] - Step size for keyboard dragging (default: 10)
 * @param {number} [draggable.shiftDragStep] - Step size for keyboard dragging with Shift key (default: 50)
 */
export declare const makeDraggable: ({ el, dragHandle, focusableDragHandle, dragStep, shiftDragStep }: DraggableProps) => {
  cleanup: () => void;
  init: () => void;
};
//#endregion