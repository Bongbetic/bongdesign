//#region src/documentLang/documentLang.d.ts
/**
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
type Subscriber = (lang: string) => void;
/**
 * Retrieves the current document language. Falls back to the browser's
 * `navigator.language` if the `<html>` lang attribute is empty.
 *
 * @returns {string} The current document language code.
 */
export declare function getDocumentLang(): string;
/**
 * Subscribes to changes on the `<html>` element's `lang` attribute.
 * Uses a shared MutationObserver under the hood to watch for attribute
 * mutations.
 *
 * @param {Subscriber} callback - Invoked with the new language code whenever
 * it changes.
 * @returns {() => void} A function that, when called, removes this subscription
 */
export declare function subscribeDocumentLangChange(callback: Subscriber): () => void;
//#endregion