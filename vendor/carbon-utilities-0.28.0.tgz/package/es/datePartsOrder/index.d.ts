//#region src/datePartsOrder/datePartsOrder.d.ts
/**
 * Copyright IBM Corp. 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
type Order = 'month-year' | 'year-month';
declare function getMonthYearOrder(locale: string): Order;
export declare const datePartsOrder: {
  getMonthYearOrder: typeof getMonthYearOrder;
  isMonthFirst: (locale: string) => boolean;
};
//#endregion