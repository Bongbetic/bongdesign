//#region src/addSelect/addSelectData.d.ts
/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Status types for items in the hierarchical data structure.
 */
type ItemStatus = 'checked' | 'unchecked' | 'indeterminate';
/**
 * A single labelled detail entry for display in item panels and selection
 * summary items.
 */
interface ItemDetailEntry {
  /** User-visible label shown as the row heading. */
  label: string;
  /** Value displayed beneath the label. */
  value: string | number;
}
/**
 * Item details metadata.
 *
 * **Preferred form** — labelled array consumed by default content renderers:
 * ```ts
 * itemDetails: [
 *   { label: 'Category', value: 'Analytics' },
 *   { label: 'Owner',    value: 'Marketing Team' },
 * ]
 * ```
 *
 * **Legacy form** — arbitrary record for custom renderers that access
 * named keys directly. Not rendered by default content renderers.
 */
type ItemDetails = ItemDetailEntry[] | Record<string, unknown>;
/**
 * Interface for hierarchical data items used by AddSelect components.
 */
interface AddSelectItem {
  /** Unique identifier for the item. */
  id: string;
  /** Display title for the item. */
  title?: string;
  /** Value associated with the item. */
  value?: string;
  /** Subtitle or secondary text. */
  subtitle?: string;
  /** Whether the item is currently selected. */
  selected?: boolean;
  /** Selection status (checked, unchecked, or indeterminate for parent nodes). */
  status?: ItemStatus;
  /** Whether the item is disabled and cannot be selected. */
  disabled?: boolean;
  /** Icon or visual element to display with the item. */
  icon?: unknown;
  /** Nested children items. */
  children?: {
    entries: AddSelectItem[];
  };
  /** Additional metadata and details about the item. */
  itemDetails?: ItemDetails;
  [key: string]: unknown;
}
/**
 * Options for search functionality.
 */
interface SearchOptions {
  caseSensitive?: boolean;
  /** Fields to search in (default: ['title', 'value']). */
  searchFields?: string[];
  /** Maximum number of results to return. */
  maxResults?: number;
}
/**
 * AddSelectData — a lightweight, framework-agnostic utility for managing
 * hierarchical data structures.
 *
 * Provides standard APIs for selection, traversal, search, and sorting of
 * hierarchical item data. Designed to work with AddSelect components but can
 * also be used independently.
 *
 * @example
 * ```ts
 * import { AddSelectData } from '@carbon/utilities';
 *
 * const dataManager = new AddSelectData();
 * dataManager.setItems(items);
 * dataManager.setSelectedItems(['item-1', 'item-2']);
 * const selected = dataManager.getSelectedItems();
 * ```
 */
declare class AddSelectData {
  private items;
  private itemMap;
  private parentMap;
  private selectedIds;
  private depthCache;
  private selectedItemsCache;
  /**
   * Initialize or replace the hierarchical data.
   */
  setItems(items: AddSelectItem[]): void;
  /**
   * Get the full list of items.
   */
  getItems(): AddSelectItem[];
  /**
   * Retrieve a single item by its id.
   */
  getItem(id: string): AddSelectItem | undefined;
  /**
   * Update a given item with new properties.
   * Returns true if the item was found and updated, false otherwise.
   */
  setItem(id: string, newProperties: Partial<AddSelectItem>): boolean;
  /**
   * Returns an array of items marked as selected (memoized).
   */
  getSelectedItems(): AddSelectItem[];
  /**
   * Mark one or more items (by id) as selected.
   * @param ids - Single id or array of ids to select.
   * @param exclusive - If true, deselect all other items first.
   */
  setSelectedItems(ids: string | string[], exclusive?: boolean): void;
  /**
   * Get direct children of a node.
   */
  getItemChildren(id: string): AddSelectItem[];
  /**
   * Get the parent of a node.
   * Returns undefined for root-level items.
   */
  getItemParent(id: string): AddSelectItem | undefined;
  /**
   * Get all ancestors (from immediate parent to root) of a node.
   */
  getItemParents(id: string): AddSelectItem[];
  /**
   * Get the selection status of an item.
   */
  getItemStatus(id: string): ItemStatus | undefined;
  /**
   * Set or update the status of an item.
   * Returns true if the item was found and updated.
   */
  setItemStatus(id: string, status: ItemStatus): boolean;
  /**
   * Check whether an item is selected (O(1) lookup).
   */
  isSelected(id: string): boolean;
  /**
   * Search items based on a query and return matching items.
   */
  search(query: string, options?: SearchOptions): AddSelectItem[];
  /**
   * Sort items based on a comparator function.
   * @param recursive - If true, also sort children recursively.
   */
  sort(compareFn: (a: AddSelectItem, b: AddSelectItem) => number, recursive?: boolean): void;
  /**
   * Clear all selections.
   */
  clearSelections(): void;
  /**
   * Get the depth of an item in the hierarchy (cached).
   * Returns -1 if the item is not found.
   */
  getItemDepth(id: string): number;
  /**
   * Check if an item has children.
   */
  hasChildren(id: string): boolean;
  /**
   * Get all descendant items of a node.
   */
  getItemDescendants(id: string): AddSelectItem[];
  /**
   * Check if an item has any selected descendants.
   */
  hasSelectedDescendants(id: string, selectedIds?: Set<string>): boolean;
  /**
   * Check if all descendants of an item are selected.
   */
  allDescendantsSelected(id: string, selectedIds?: Set<string>): boolean;
  /**
   * Get all descendant IDs including the item itself.
   */
  getAllDescendantIds(id: string): string[];
  /**
   * Get only top-level selected items (items without selected ancestors).
   */
  getTopLevelSelectedItems(selectedIds?: Set<string>): AddSelectItem[];
  private _invalidateCaches;
  private _invalidateSelectionCache;
  private _buildMaps;
  private _traverseItems;
  private _sortRecursive;
}
//#endregion
export { ItemStatus as a, ItemDetails as i, AddSelectItem as n, SearchOptions as o, ItemDetailEntry as r, AddSelectData as t };