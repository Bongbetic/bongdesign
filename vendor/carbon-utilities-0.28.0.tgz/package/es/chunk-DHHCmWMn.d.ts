//#region src/carousel/defs.d.ts
/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare const translationIds: {
  readonly 'carbon.carousel.item': "carbon.carousel.item";
  readonly 'carbon.carousel.of': "carbon.carousel.of";
};
//#endregion
//#region src/carousel/types.d.ts
type TranslationKey = keyof typeof translationIds;
interface CarouselStackHistory {
  id: number;
  elem: HTMLElement;
}
type CarouselResponse = {
  currentIndex: number;
  lastIndex: number;
  totalViews: number;
  historyStack: CarouselStackHistory[];
};
type ActiveItem = {
  index: number;
  item: HTMLElement | null;
};
type Config = {
  onViewChangeStart?: (args: CarouselResponse) => void;
  onViewChangeEnd?: (args: CarouselResponse) => void;
  excludeSwipeSupport?: boolean;
  useMaxHeight?: boolean;
  translateWithId?: (messageId: TranslationKey) => string;
};
interface InitCarousel {
  next: () => void;
  prev: () => void;
  reset: () => void;
  goToIndex: (index: number) => void;
  getActiveItem: () => ActiveItem;
  destroyEvents: (() => void) | null;
  allViews: Record<number, HTMLElement | null>;
}
//#endregion
//#region src/carousel/carousel.d.ts
/**
 * Initializes a carousel with the given configuration.
 * @param carouselContainer - The HTMLElement representing the carousel container.
 * @param config - Optional configuration object.
 * @returns An object containing methods to control the carousel.
 */
declare const initCarousel: (carouselContainer: HTMLElement, config?: Config) => InitCarousel;
//#endregion
export { InitCarousel as a, Config as i, CarouselResponse as n, TranslationKey as o, CarouselStackHistory as r, initCarousel as t };