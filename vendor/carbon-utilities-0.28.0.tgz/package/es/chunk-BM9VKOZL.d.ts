declare namespace relative_d_exports {
  export { format$2 as format };
}
/**
 * Copyright IBM Corp. 2024
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare function format$2(date: Date | number, options?: Partial<{
  locale: string;
  style: Intl.RelativeTimeFormatStyle;
}>): string;
declare namespace absolute_d_exports {
  export { format$1 as format, formatDate, formatRange, formatTime };
}
/**
 * Copyright IBM Corp. 2024, 2025
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare function formatTime(date: Date | number, options?: Partial<{
  locale: string;
  style: Intl.DateTimeFormatOptions['timeStyle'];
  timeZone: Intl.DateTimeFormatOptions['timeZone'];
}>): string;
declare function formatDate(date: Date | number, options?: Partial<{
  locale: string;
  style: Intl.DateTimeFormatOptions['dateStyle'];
  timeZone: Intl.DateTimeFormatOptions['timeZone'];
}>): string;
declare function format$1(date: Date | number, options?: Partial<{
  locale: string;
  style: Intl.DateTimeFormatOptions['timeStyle'] | 'tooltip';
  timeStyle: Intl.DateTimeFormatOptions['timeStyle'];
  dateStyle: Intl.DateTimeFormatOptions['dateStyle'];
  timeZone: Intl.DateTimeFormatOptions['timeZone'];
}>): string;
declare function formatRange(startDate: Date | number, endDate: Date | number, options?: Partial<{
  locale: string;
  style: Intl.DateTimeFormatOptions['timeStyle'];
  timeStyle: Intl.DateTimeFormatOptions['timeStyle'] | null;
  dateStyle: Intl.DateTimeFormatOptions['dateStyle'] | null;
  timeZone: Intl.DateTimeFormatOptions['timeZone'];
}>): string;
declare namespace duration_d_exports {
  export { format };
}
/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare function format(duration: Partial<Record<Intl.DurationFormatUnit, number>>, options?: Partial<{
  locale: string;
  style: Intl.DurationFormatOptions['style'];
}>): string;
//#endregion
//#region src/dateTimeFormat/index.d.ts
declare const dateTimeFormat: {
  relative: typeof relative_d_exports;
  absolute: typeof absolute_d_exports;
  duration: typeof duration_d_exports;
};
//#endregion
export { dateTimeFormat as t };