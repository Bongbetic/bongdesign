/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/js/utils/collapsible-controller.ts
var CollapsibleController = class {
	constructor(host, options) {
		this.startY = null;
		this.isDragging = false;
		this.onPointerDown = (e) => {
			if (this.options.disable?.()) return;
			this.startY = e.clientY;
			this.isDragging = true;
		};
		this.onPointerMove = (e) => {
			if (!this.isDragging || this.startY === null) return;
			if (this.options.disable?.()) return;
			const diffY = this.startY - e.clientY;
			if (diffY > 5) this.options.triggerCollapse(true);
			else if (diffY < -5) this.options.triggerCollapse(false);
		};
		this.onPointerUp = () => {
			this.isDragging = false;
			this.startY = null;
			document.body.style.cursor = "default";
		};
		this.onWheel = (e) => {
			if (this.options.disable?.()) return;
			if (e.deltaY > 0) this.options.triggerCollapse(true);
			else if (e.deltaY < 0) this.options.triggerCollapse(false);
		};
		this.options = options;
		host.addController(this);
	}
	hostConnected() {
		const container = this.options.container();
		if (!container) return;
		container.addEventListener("pointerdown", this.onPointerDown);
		container.addEventListener("pointermove", this.onPointerMove);
		container.addEventListener("pointerup", this.onPointerUp);
		container.addEventListener("wheel", this.onWheel);
	}
	hostDisconnected() {
		const container = this.options.container();
		if (!container) return;
		container.removeEventListener("pointerdown", this.onPointerDown);
		container.removeEventListener("pointermove", this.onPointerMove);
		container.removeEventListener("pointerup", this.onPointerUp);
		container.removeEventListener("wheel", this.onWheel);
	}
};
//#endregion
export { CollapsibleController };

//# sourceMappingURL=collapsible-controller.js.map