/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/js/utils/match-media-controller.ts
var MatchMediaController = class {
	constructor(host, mediaQuery, defaultState = false) {
		this.host = host;
		this.listener = (e) => {
			this.matches = e.matches;
			this.host.requestUpdate();
		};
		this.mql = window.matchMedia(mediaQuery);
		this.matches = defaultState;
		host.addController(this);
	}
	hostConnected() {
		this.matches = this.mql.matches;
		this.mql.addEventListener("change", this.listener);
	}
	hostDisconnected() {
		this.mql.removeEventListener("change", this.listener);
	}
};
//#endregion
export { MatchMediaController };

//# sourceMappingURL=match-media-controller.js.map