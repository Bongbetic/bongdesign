/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { isFeatureFlagEnabled } from "../../components/feature-flags/index.js";
//#region src/globals/mixins/auto-align.ts
const attribute = "autoalign";
/**
* @param Base The base class.
* @param property The name of the element's auto-align property.
* @returns A mix-in that resolves the default value of the auto-align property and lets the `autoalign` attribute opt out of it.
*/
const AutoAlignMixin = (Base, property = "autoalign") => {
	/**
	* A mix-in class that resolves the default value of the auto-align property and lets the `autoalign` attribute opt out of it.
	*/
	class AutoAlignMixinImpl extends Base {
		connectedCallback() {
			super.connectedCallback();
			const host = this;
			host[property] ??= isFeatureFlagEnabled("enable-v12-autoalign", this);
		}
		attributeChangedCallback(name, old, value) {
			if (name === attribute && value === "false") {
				this.removeAttribute(attribute);
				return;
			}
			super.attributeChangedCallback(name, old, value);
		}
	}
	return AutoAlignMixinImpl;
};
//#endregion
export { AutoAlignMixin as default };

//# sourceMappingURL=auto-align.js.map