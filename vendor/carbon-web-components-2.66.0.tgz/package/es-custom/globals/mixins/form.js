/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import on from "./on.js";
//#region src/globals/mixins/form.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param Base The base class.
* @returns A mix-in to handle `formdata` event on the containing form.
*
* @deprecated `FormMixin` is deprecated and will be removed in v3. It is a
*   stop-gap from a time when form-associated custom elements were not yet
*   available in every browser we support, and it can only emulate one part of
*   being a form control — contributing a value on submit. It cannot make an
*   element labelable, put it in `form.elements`, respond to `form.reset()`, or
*   honor an ancestor `<fieldset disabled>`.
*
*   v3 replaces it with native form association through `ElementInternals`
*   (`FormAssociatedMixin`). You can try that today on the `cds-custom-preview-*`
*   form components, which behave identically apart from participating in
*   forms natively. See the v3 migration guide:
*   https://github.com/carbon-design-system/carbon/blob/main/docs/guides/cwc-v3-migration.md#form-participation-moves-to-elementinternals
*/
const FormMixin = (Base) => {
	/**
	* A mix-in class to handle `formdata` event on the containing form.
	*/
	class FormMixinImpl extends Base {
		constructor(..._args) {
			super(..._args);
			this._hFormdata = null;
		}
		connectedCallback() {
			super.connectedCallback();
			const form = this.closest("form");
			if (form) this._hFormdata = on(form, "formdata", this._handleFormdata.bind(this));
		}
		disconnectedCallback() {
			if (this._hFormdata) this._hFormdata = this._hFormdata.release();
			super.disconnectedCallback();
		}
	}
	return FormMixinImpl;
};
//#endregion
export { FormMixin as default };

//# sourceMappingURL=form.js.map