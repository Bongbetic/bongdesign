/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { unsafeCSS } from "lit";
//#region src/globals/mixins/form-associated.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param Base The base class.
* @returns A mixin turning the element into a form-associated custom element
*
* Delegate to `ElementInternals` as much as possible
*
* A component using this implements {@link _getFormValue} and lists the
* properties that change it in `formValueProperties`.
*
* - Form value is pushed from `requestUpdate()`, which Lit calls
*   synchronously from every property setter. Syncing in an async lifecycle
*   instead (`updated()`) leaves a stale value readable by a
*   `new FormData(form)` in the same task, which a native control never does.
* - The rendered control is disabled while an ancestor `<fieldset>` is, which
*   the platform does not do for shadow content on its own.
* - `_handleFormdata` is neutralized, so the deprecated `formdata` path
*   inherited from `FormMixin` cannot double-submit alongside `setFormValue()`.
*   This override disappears in v3 when `FormMixin` is removed.
*/
const FormAssociatedMixin = (Base) => {
	class FormAssociatedImpl extends Base {
		constructor(..._args) {
			super(..._args);
			this._internals = super.attachInternals();
			this._attachInternalsClaimed = false;
			this._fieldsetDisabled = false;
			this._fieldsetDisabledControls = /* @__PURE__ */ new Set();
		}
		/**
		* support v12 preview tag names
		*/
		static finalize() {
			const finalized = super.finalize();
			const self = this;
			const tag = self.is;
			if (!tag?.includes("-preview-") || !Array.isArray(self.elementStyles)) return finalized;
			const base = tag.replace("-preview-", "-");
			self.elementStyles = self.elementStyles.map((style) => {
				const css = String(style.cssText);
				const rewritten = css.replace(/:host\(([^)]*)\)/g, (whole, arg) => arg.includes(base) ? `:host(${arg.split(base).join(tag)})` : whole);
				return rewritten === css ? style : unsafeCSS(rewritten);
			});
			return finalized;
		}
		static {
			this.formAssociated = true;
		}
		static {
			this.formValueProperties = [
				"value",
				"checked",
				"disabled",
				"name"
			];
		}
		/**
		* Hands a subclass the internals this element already attached.
		*
		* A subclass that calls `attachInternals()` itself — the workaround people
		* wrote while waiting for form association — would otherwise throw inside
		* its own constructor. That failure does not propagate to `createElement()`
		* or the parser: it surfaces as an uncaught error and leaves a silently
		* dead element. Returning the existing internals keeps that code working.
		* A second claim still provokes the native error.
		*
		* This mirrors the approach in `@lit-labs/forms`.
		*/
		attachInternals() {
			if (this._attachInternalsClaimed) super.attachInternals();
			this._attachInternalsClaimed = true;
			return this._internals;
		}
		/**
		* The value this element contributes to its form.
		*
		* The default reproduces what every v2 `_handleFormdata` did — submit
		* `value` unless disabled — so most components need no override. Controls
		* whose value is not a plain `value` property (a checkbox, say) override
		* this. Returning `null` submits no entry.
		*
		* @protected
		*/
		_getFormValue() {
			const { disabled, value } = this;
			if (disabled || value === void 0 || value === null) return null;
			return String(value);
		}
		/**
		* The state this element restores from, when it differs from the value.
		*
		* `setFormValue()` takes both. The state is what the browser hands back to
		* `formStateRestoreCallback` — for a checkbox the value is `"on"` but the
		* state is its checkedness, which is what makes session restore correct.
		*
		* @protected
		*/
		_getFormState() {
			return this._getFormValue();
		}
		/**
		* Pushes the current value and validity into the form.
		*
		* @protected
		*/
		_syncFormValue() {
			this._internals.setFormValue(this._getFormValue(), this._getFormState());
			this._syncValidity();
		}
		/**
		* Mirrors the rendered control's constraints onto the host.
		*
		* The inner `<input>` already carries `pattern`, `min`, `minlength`, `type`
		* and the rest, so its `validity` is copied up rather than reimplemented.
		* `required` is checked against the host's own form value first, for
		* controls whose value is not an inner input's value.
		*
		* `invalid` stays presentational — it styles the control without blocking
		* submission, as it always has.
		*
		* @protected
		*/
		_syncValidity() {
			const anchor = this._validationAnchor();
			const { required, requiredValidityMessage } = this;
			if (required && !this._getFormValue()) {
				this._internals.setValidity({ valueMissing: true }, requiredValidityMessage || "Please fill out this field.", anchor);
				return;
			}
			const native = anchor?.validity;
			if (native && !native.valid) {
				const flags = {};
				for (const flag in native) if (flag !== "valid" && native[flag]) flags[flag] = true;
				this._internals.setValidity(flags, anchor.validationMessage, anchor);
				return;
			}
			this._internals.setValidity({});
		}
		/**
		* The element the browser points its validation bubble at.
		*
		* @protected
		*/
		_validationAnchor() {
			return this.shadowRoot?.querySelector("input, select, textarea") ?? void 0;
		}
		/**
		* Neutralizes the deprecated `formdata` path inherited from `FormMixin`.
		*
		* Without this the element submits twice — once from the legacy listener
		* and once from `setFormValue()`.
		*/
		_handleFormdata() {}
		/**
		* Applies the effective disabled state to the rendered control.
		*
		* `disabled` deliberately reports only this element's own attribute, the
		* way `HTMLInputElement.disabled` does — an element inside a disabled
		* `<fieldset>` reports `false` and matches `:disabled` instead. Use
		* `el.matches(':disabled')` for the effective state.
		*
		* A native UA still makes such a control non-interactive. That does not
		* reach shadow content on its own — a shadow `<input>` inside a disabled
		* `<fieldset>` stays focusable and editable — so the rendered control is
		* disabled here to match what the platform does for a built-in.
		*/
		updated(changed) {
			super.updated(changed);
			const controls = this.shadowRoot?.querySelectorAll("input, select, textarea, button");
			if (this._fieldsetDisabled) {
				controls?.forEach((control) => {
					if (!control.disabled) {
						control.disabled = true;
						this._fieldsetDisabledControls.add(control);
					}
				});
				return;
			}
			if (this._fieldsetDisabledControls.size === 0) return;
			this._fieldsetDisabledControls.forEach((control) => {
				control.disabled = false;
			});
			this._fieldsetDisabledControls.clear();
		}
		/**
		* The containing form, or `null`.
		*/
		get form() {
			return this._internals.form;
		}
		/**
		* The `<label>` elements associated with this control.
		*/
		get labels() {
			return this._internals.labels;
		}
		get validity() {
			return this._internals.validity;
		}
		get validationMessage() {
			return this._internals.validationMessage;
		}
		get willValidate() {
			return this._internals.willValidate;
		}
		checkValidity() {
			return this._internals.checkValidity();
		}
		reportValidity() {
			return this._internals.reportValidity();
		}
		/**
		* Restores the element to its default state on `form.reset()`.
		*
		* Components override this. The native default comes from content
		* attributes, not from the current property values.
		*/
		formResetCallback() {
			if ("value" in this) this.value = this._formDefaults?.value ?? "";
			this._syncFormValue();
		}
		/**
		* Called when an ancestor `<fieldset>` is enabled or disabled.
		*/
		formDisabledCallback(disabled) {
			this._fieldsetDisabled = disabled;
			this.requestUpdate();
		}
		/**
		* Called when the browser restores state, e.g. on session restore.
		*/
		formStateRestoreCallback() {}
		/**
		* Pushes the form value on every relevant property change.
		*
		* Lit calls this synchronously from its generated setters, which is what
		* keeps the submitted value in step with the property the way a native
		* control does.
		*/
		requestUpdate(name, oldValue, options) {
			super.requestUpdate(name, oldValue, options);
			if (!this._internals) return;
			if (name === void 0 || name === "name") {
				const current = String(this.name ?? "");
				if (current && this.getAttribute("name") !== current) this.setAttribute("name", current);
			}
			const { formValueProperties } = this.constructor;
			if (name === void 0 || formValueProperties.includes(String(name))) this._syncFormValue();
		}
		connectedCallback() {
			super.connectedCallback();
			this._formDefaults ??= {
				value: this.getAttribute("value"),
				checked: this.hasAttribute("checked") || this.hasAttribute("default-checked"),
				indeterminate: this.hasAttribute("indeterminate")
			};
			this._syncFormValue();
		}
	}
	return FormAssociatedImpl;
};
//#endregion
export { FormAssociatedMixin as default };

//# sourceMappingURL=form-associated.js.map