/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/internal/getSupportedLocale.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Returns `locale` if it is supported by `Intl.NumberFormat`, otherwise
* returns `defaultLocale`.
*/
function getSupportedLocale(locale, defaultLocale) {
	try {
		return Intl.NumberFormat.supportedLocalesOf(locale).length > 0 ? locale : defaultLocale;
	} catch {
		return defaultLocale;
	}
}
//#endregion
export { getSupportedLocale };

//# sourceMappingURL=getSupportedLocale.js.map