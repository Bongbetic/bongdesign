/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/decorators/carbon-element.ts
const legacyCustomElement = (tagName, clazz) => {
	try {
		customElements.define(tagName, clazz);
	} catch {
		console.warn(`Attempting to re-define ${tagName}`);
	}
	return clazz;
};
const standardCustomElement = (tagName, descriptor) => {
	const { kind, elements } = descriptor;
	return {
		kind,
		elements,
		finisher(clazz) {
			try {
				customElements.define(tagName, clazz);
			} catch {
				console.warn(`Attempting to re-define ${tagName}`);
			}
		}
	};
};
/**
* Class decorator factory that defines the decorated class as a custom element.
*
* ```js
* @customElement('my-element')
* class MyElement extends LitElement {
*   render() {
*     return html``;
*   }
* }
* ```
*
* @deprecated The `carbonElement` decorator is deprecated and will be removed in
*   v3. In v3, `@carbon/web-components` moves to pure component
*   classes (`static is = '${prefix}-name'`) with opt-in registration via
*   `defineCustomElement`, and this self-registering decorator is removed. If you
*   author your own custom elements with it, migrate to Lit's `customElement`
*   (`import { customElement } from 'lit/decorators.js'`). See the v3 migration
*   guide:
*   https://github.com/carbon-design-system/carbon/blob/main/docs/guides/cwc-v3-migration.md#the-carbonelement-decorator-is-removed
* @category Decorator
* @param tagName The tag name of the custom element to define.
*/
const carbonElement = (tagName) => (classOrDescriptor) => typeof classOrDescriptor === "function" ? legacyCustomElement(tagName, classOrDescriptor) : standardCustomElement(tagName, classOrDescriptor);
//#endregion
export { carbonElement };

//# sourceMappingURL=carbon-element.js.map
// @deprecated The `es-custom` build is deprecated and will be removed in v3.0.0.
if (typeof console !== "undefined" && !globalThis.__CDS_ES_CUSTOM_DEPRECATED__) {
  globalThis.__CDS_ES_CUSTOM_DEPRECATED__ = true;
  console.warn(
    "[@carbon/web-components] The \"es-custom\" build (cds-custom-* elements) is deprecated and will be removed in v3.0.0. " +
    "See the v3 migration guide: " +
    "https://github.com/carbon-design-system/carbon/blob/main/docs/guides/cwc-v3-migration.md#the-es-custom-build-is-removed"
  );
}
