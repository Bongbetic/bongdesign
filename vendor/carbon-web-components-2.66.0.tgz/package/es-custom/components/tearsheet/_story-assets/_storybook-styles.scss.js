/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/tearsheet/_story-assets/_storybook-styles.scss?lit
var _storybook_styles_default = css(["cds-custom-tearsheet-influencer,cds-custom-tearsheet-summary-content,div[slot=main-content]{padding-block:2rem}.summaryPanelTrigger{position:absolute;inset-block-start:0;inset-inline-end:0}.influencerPanelTrigger{position:absolute;inset-block-start:0;inset-inline-start:0}@media (min-width:66rem) and (max-width:82rem){cds-custom-tearsheet:not([variant=narrow]) .influencerPanelTrigger,cds-custom-tearsheet:not([variant=narrow]) .summaryPanelTrigger{display:none}}@media (min-width:42rem) and (max-width:66rem){cds-custom-tearsheet:not([variant=narrow]) .influencerPanelTrigger,cds-custom-tearsheet:not([variant=narrow]) .summaryPanelTrigger{display:none}}@media (min-width:82rem) and (max-width:99rem){cds-custom-tearsheet:not([variant=narrow]) .influencerPanelTrigger,cds-custom-tearsheet:not([variant=narrow]) .summaryPanelTrigger{display:none}}@media (min-width:99rem){cds-custom-tearsheet:not([variant=narrow]) .influencerPanelTrigger,cds-custom-tearsheet:not([variant=narrow]) .summaryPanelTrigger{display:none}}.summaryPanelHeading{font-size:var(--cds-heading-03-font-size,1.25rem);font-weight:var(--cds-heading-03-font-weight,400);line-height:var(--cds-heading-03-line-height,1.4);letter-spacing:var(--cds-heading-03-letter-spacing,0)}@media (min-width:20rem) and (max-width:42rem){.stackButtons{display:none}}@media (min-width:66rem) and (max-width:82rem){.smallScreenButton{display:none}}@media (min-width:42rem) and (max-width:66rem){.smallScreenButton{display:none}}@media (min-width:82rem) and (max-width:99rem){.smallScreenButton{display:none}}@media (min-width:99rem){.smallScreenButton{display:none}}.default__action-buttons{display:grid;grid-auto-rows:minmax(auto,auto);grid-template-columns:repeat(6,1fr)}.default__action-buttons>cds-custom-button{inline-size:100%;max-inline-size:none}.default__action-buttons>cds-custom-button:first-child{grid-column:span 4}"]);
//#endregion
export { _storybook_styles_default as default };

//# sourceMappingURL=_storybook-styles.scss.js.map