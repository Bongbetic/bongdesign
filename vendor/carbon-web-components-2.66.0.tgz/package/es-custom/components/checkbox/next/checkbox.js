/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import checkbox_default$1 from "../checkbox.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/checkbox/next/checkbox.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated v3 preview of `cds-custom-checkbox`.
*
* Identical to `cds-custom-checkbox` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* @element cds-custom-preview-checkbox
* @fires cds-custom-checkbox-changed - The custom event fired after this checkbox changes its checked state
* @csspart input The checkbox
* @csspart label The label
*/
let CDSPreviewCheckbox = class CDSPreviewCheckbox extends FormAssociatedMixin(checkbox_default$1) {
	/**
	* A checkbox contributes its `value` only while checked, defaulting to `on`
	* the way a native checkbox does.
	*/
	_getFormValue() {
		if (this.disabled || !this.checked) return null;
		return this.value ?? "on";
	}
	/**
	* The restorable state is the check, not the value — an unchecked
	* checkbox submits nothing, so the value alone cannot describe it.
	*/
	_getFormState() {
		return String(this.checked);
	}
	/**
	* Restores the default checked state, which the content attributes define.
	*/
	formResetCallback() {
		this.checked = this._formDefaults?.checked ?? false;
		this.indeterminate = this._formDefaults?.indeterminate ?? false;
		this._syncFormValue();
	}
	/**
	* Restores checkedness the browser preserved across a session restore.
	*/
	formStateRestoreCallback(state) {
		this.checked = state === "true";
	}
	static get is() {
		return `cds-custom-preview-checkbox`;
	}
};
CDSPreviewCheckbox = __decorate([carbonElement(`cds-custom-preview-checkbox`)], CDSPreviewCheckbox);
var checkbox_default = CDSPreviewCheckbox;
//#endregion
export { checkbox_default as default };

//# sourceMappingURL=checkbox.js.map