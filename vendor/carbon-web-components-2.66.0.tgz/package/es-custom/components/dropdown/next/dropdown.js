/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dropdown_default$1 from "../dropdown.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/dropdown/next/dropdown.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated v3 preview of `cds-custom-dropdown`.
*
* Identical to `cds-custom-dropdown` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* v2 `cds-custom-dropdown-item` children work unchanged — only the container
* participates in the form.
*
* @element cds-custom-preview-dropdown
*/
let CDSPreviewDropdown = class CDSPreviewDropdown extends FormAssociatedMixin(dropdown_default$1) {
	static get is() {
		return `cds-custom-preview-dropdown`;
	}
};
CDSPreviewDropdown = __decorate([carbonElement(`cds-custom-preview-dropdown`)], CDSPreviewDropdown);
var dropdown_default = CDSPreviewDropdown;
//#endregion
export { dropdown_default as default };

//# sourceMappingURL=dropdown.js.map