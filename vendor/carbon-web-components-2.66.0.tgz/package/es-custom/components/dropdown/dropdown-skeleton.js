/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "./defs.js";
import dropdown_default from "./dropdown.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/dropdown/dropdown-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton version of dropdown.
*/
let CDSDropdownSkeleton = class CDSDropdownSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
		this.size = "md";
	}
	render() {
		const { hideLabel, size } = this;
		const classes = classMap({
			[`cds-custom--skeleton`]: true,
			[`cds-custom--dropdown`]: true,
			[`cds-custom--list-box--${size}`]: Boolean(size)
		});
		return html`
      ${!hideLabel ? html`<span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span>` : null}
      <div class=${classes}></div>
    `;
	}
	static {
		this.styles = dropdown_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSDropdownSkeleton.prototype, "hideLabel", void 0);
__decorate([property({ reflect: true })], CDSDropdownSkeleton.prototype, "size", void 0);
CDSDropdownSkeleton = __decorate([carbonElement(`cds-custom-dropdown-skeleton`)], CDSDropdownSkeleton);
var dropdown_skeleton_default = CDSDropdownSkeleton;
//#endregion
export { dropdown_skeleton_default as default };

//# sourceMappingURL=dropdown-skeleton.js.map