/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dropdown_default from "../dropdown/dropdown.js";
import fluid_dropdown_default$1 from "./fluid-dropdown.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/fluid-dropdown/fluid-dropdown.ts
/**
* Copyright IBM Corp.2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid dropdown.
*
* @element cds-custom-fluid-dropdown
*/
let CDSFluidDropdown = class CDSFluidDropdown extends dropdown_default {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readOnly") || changedProperties.has("warn")) this.requestUpdate();
	}
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [dropdown_default.styles, fluid_dropdown_default$1];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidDropdown.prototype, "isCondensed", void 0);
CDSFluidDropdown = __decorate([carbonElement(`cds-custom-fluid-dropdown`)], CDSFluidDropdown);
var fluid_dropdown_default = CDSFluidDropdown;
//#endregion
export { fluid_dropdown_default as default };

//# sourceMappingURL=fluid-dropdown.js.map