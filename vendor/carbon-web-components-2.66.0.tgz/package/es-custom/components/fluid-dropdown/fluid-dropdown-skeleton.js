/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dropdown_skeleton_default from "../dropdown/dropdown-skeleton.js";
import fluid_dropdown_default from "./fluid-dropdown.scss.js";
import { html } from "lit";
//#region src/components/fluid-dropdown/fluid-dropdown-skeleton.ts
/**
* Copyright IBM Corp.2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid dropdown skeleton.
*
* @element cds-custom-fluid-dropdown-skeleton
*/
let CDSFluidDropdownSkeleton = class CDSFluidDropdownSkeleton extends dropdown_skeleton_default {
	render() {
		return html`
      <div class="${"cds-custom"}--list-box__wrapper--fluid">
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--list-box">
          <span class="${"cds-custom"}--list-box__label"></span>
          <div class="${"cds-custom"}--list-box__field" />
        </div>
      </div>
    `;
	}
	static {
		this.styles = fluid_dropdown_default;
	}
};
CDSFluidDropdownSkeleton = __decorate([carbonElement(`cds-custom-fluid-dropdown-skeleton`)], CDSFluidDropdownSkeleton);
var fluid_dropdown_skeleton_default = CDSFluidDropdownSkeleton;
//#endregion
export { fluid_dropdown_skeleton_default as default };

//# sourceMappingURL=fluid-dropdown-skeleton.js.map