/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/resizer/defs.ts
const DOUBLE_TAP = {
	MAX_TIME_MS: 300,
	MAX_DISTANCE_PX: 24,
	VIBRATION_MS: 8
};
const KEYBOARD = {
	DEFAULT_STEP_PX: 5,
	LARGE_STEP_PX: 25
};
const ARIA = {
	ROLE_SEPARATOR: "separator",
	LIVE_ASSERTIVE: "assertive",
	VALUE_MIN: "0",
	VALUE_MAX: "100",
	VALUE_DEFAULT: "50"
};
const SELECTORS = {
	GRID: "cds-custom-resizer-grid",
	PANEL: "cds-custom-resizer-panel",
	HANDLE: "cds-custom-resizer-handle",
	PIVOT: "cds-custom-resizer-handle-pivot"
};
const SLOTS = {
	LEFT: "left",
	RIGHT: "right",
	TOP: "top",
	BOTTOM: "bottom",
	HANDLE_HORIZONTAL: "handle-horizontal",
	HANDLE_VERTICAL: "handle-vertical",
	PIVOT: "pivot",
	ICON: "icon"
};
const EVENTS = {
	RESIZE_START: "resize-start",
	RESIZE_DRAG: "resize-drag",
	RESIZE_END: "resize-end",
	RESIZE_RESET: "resize-reset"
};
function calculateFlexRatio(value, total) {
	if (total <= 0) return 0;
	return Math.max(0, Math.min(1, value / total));
}
function formatSplitRatio(percentage) {
	const start = Math.round(Math.max(0, Math.min(100, percentage)));
	return `${start}% / ${100 - start}%`;
}
function determineAxis(slot, cursor) {
	if (slot === SLOTS.HANDLE_VERTICAL) return "y";
	if (slot === SLOTS.HANDLE_HORIZONTAL) return "x";
	if (cursor?.includes("ew")) return "x";
	return "y";
}
function isWithinDistance(pos1, pos2, threshold) {
	return Math.abs(pos1.x - pos2.x) < threshold && Math.abs(pos1.y - pos2.y) < threshold;
}
function triggerHapticFeedback(duration) {
	if ("vibrate" in navigator) try {
		navigator.vibrate(duration);
	} catch {}
}
function createCustomEvent(eventName, detail, options) {
	return new CustomEvent(eventName, {
		bubbles: true,
		composed: true,
		detail,
		...options
	});
}
function getOrientationFromAxis(axis) {
	return axis === "x" ? "vertical" : "horizontal";
}
function safeClosest(element, selector) {
	try {
		return element.closest(selector);
	} catch {
		return null;
	}
}
function safeQuerySelectorAll(root, selector) {
	try {
		return Array.from(root.querySelectorAll(selector));
	} catch {
		return [];
	}
}
//#endregion
export { ARIA, DOUBLE_TAP, EVENTS, KEYBOARD, SELECTORS, SLOTS, calculateFlexRatio, createCustomEvent, determineAxis, formatSplitRatio, getOrientationFromAxis, isWithinDistance, safeClosest, safeQuerySelectorAll, triggerHapticFeedback };

//# sourceMappingURL=defs.js.map