/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/icon-indicator/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
let ICON_INDICATOR_KIND = /* @__PURE__ */ function(ICON_INDICATOR_KIND) {
	/**
	* Failed
	*/
	ICON_INDICATOR_KIND["FAILED"] = "failed";
	/**
	* Caution major.
	*/
	ICON_INDICATOR_KIND["CAUTION-MAJOR"] = "caution-major";
	/**
	* Caution minor.
	*/
	ICON_INDICATOR_KIND["CAUTION-MINOR"] = "caution-minor";
	/**
	* Undefined.
	*/
	ICON_INDICATOR_KIND["UNDEFINED"] = "undefined";
	/**
	* Succeeded.
	*/
	ICON_INDICATOR_KIND["SUCCEEDED"] = "succeeded";
	/**
	* Normal.
	*/
	ICON_INDICATOR_KIND["NORMAL"] = "normal";
	/**
	* In-progress.
	*/
	ICON_INDICATOR_KIND["IN-PROGRESS"] = "in-progress";
	/**
	* Incomplete.
	*/
	ICON_INDICATOR_KIND["INCOMPLETE"] = "incomplete";
	/**
	* Not started.
	*/
	ICON_INDICATOR_KIND["NOT-STARTED"] = "not-started";
	/**
	* Pending.
	*/
	ICON_INDICATOR_KIND["PENDING"] = "pending";
	/**
	* Unknown.
	*/
	ICON_INDICATOR_KIND["UNKNOWN"] = "unknown";
	/**
	* Informative.
	*/
	ICON_INDICATOR_KIND["INFORMATIVE"] = "informative";
	return ICON_INDICATOR_KIND;
}({});
//#endregion
export { ICON_INDICATOR_KIND };

//# sourceMappingURL=defs.js.map