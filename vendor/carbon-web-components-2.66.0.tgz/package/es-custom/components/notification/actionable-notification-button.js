/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../button/defs.js";
import button_default from "../button/button.scss.js";
import button_default$1 from "../button/button.js";
import actionable_notification_default from "./actionable-notification.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/notification/actionable-notification-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Actionable notification action button.
*
* @element cds-custom-actionable-notification-button
*/
let CDSActionableNotificationButton = class CDSActionableNotificationButton extends button_default$1 {
	constructor(..._args) {
		super(..._args);
		this.size = "sm";
	}
	firstUpdated(changedProperties) {
		super.firstUpdated(changedProperties);
		this.shadowRoot?.getElementById("button")?.classList.add(`cds-custom--actionable-notification__action-button`);
	}
	static {
		this.styles = [button_default, actionable_notification_default];
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSActionableNotificationButton.prototype, "size", void 0);
CDSActionableNotificationButton = __decorate([carbonElement(`cds-custom-actionable-notification-button`)], CDSActionableNotificationButton);
var actionable_notification_button_default = CDSActionableNotificationButton;
//#endregion
export { actionable_notification_button_default as default };

//# sourceMappingURL=actionable-notification-button.js.map