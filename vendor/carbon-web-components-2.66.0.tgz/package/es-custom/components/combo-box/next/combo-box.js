/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import combo_box_default$1 from "../combo-box.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/combo-box/next/combo-box.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated preview of `cds-custom-combo-box`.
*
* Identical to `cds-custom-combo-box` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* v2 `cds-custom-combo-box-item` children work unchanged — only the container
* participates in the form.
*
* @element cds-custom-preview-combo-box
*/
let CDSPreviewComboBox = class CDSPreviewComboBox extends FormAssociatedMixin(combo_box_default$1) {
	static get is() {
		return `cds-custom-preview-combo-box`;
	}
};
CDSPreviewComboBox = __decorate([carbonElement(`cds-custom-preview-combo-box`)], CDSPreviewComboBox);
var combo_box_default = CDSPreviewComboBox;
//#endregion
export { combo_box_default as default };

//# sourceMappingURL=combo-box.js.map