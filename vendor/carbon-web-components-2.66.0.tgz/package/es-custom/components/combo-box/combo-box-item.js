/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import combo_box_default from "./combo-box.scss.js";
import dropdown_item_default from "../dropdown/dropdown-item.js";
//#region src/components/combo-box/combo-box-item.ts
/**
* Combo box item.
*
* @element cds-custom-combo-box-item
*/
let CDSComboBoxItem = class CDSComboBoxItem extends dropdown_item_default {
	constructor(..._args) {
		super(..._args);
		this._nextSiblingRefs = {
			"hovered-next-sibling": null,
			"highlighted-next-sibling": null,
			"selected-next-sibling": null
		};
	}
	connectedCallback() {
		super.connectedCallback();
		this.classList.add(`cds-custom--list-box__menu-item`);
	}
	disconnectedCallback() {
		this._syncNextSibling("highlighted-next-sibling", false);
		this._syncNextSibling("selected-next-sibling", false);
		super.disconnectedCallback();
	}
	_getNextItem() {
		let next = this.nextElementSibling;
		while (next) {
			if (next instanceof HTMLElement && next.tagName.toLowerCase() === `cds-custom-combo-box-item`) return next;
			next = next.nextElementSibling;
		}
		return null;
	}
	_syncNextSibling(attribute, shouldSet) {
		this._nextSiblingRefs[attribute]?.removeAttribute(attribute);
		if (shouldSet) {
			const next = this._getNextItem();
			if (next) {
				next.setAttribute(attribute, "");
				this._nextSiblingRefs[attribute] = next;
				return;
			}
		}
		this._nextSiblingRefs[attribute] = null;
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("highlighted")) this._syncNextSibling("highlighted-next-sibling", this.highlighted);
		if (changedProperties.has("selected")) this._syncNextSibling("selected-next-sibling", this.selected);
	}
	static {
		this.styles = combo_box_default;
	}
};
CDSComboBoxItem = __decorate([carbonElement(`cds-custom-combo-box-item`)], CDSComboBoxItem);
var combo_box_item_default = CDSComboBoxItem;
//#endregion
export { combo_box_item_default as default };

//# sourceMappingURL=combo-box-item.js.map