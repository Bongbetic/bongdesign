/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import ai_label_default from "./ai-label.scss.js";
import button_default from "../button/button.scss.js";
import button_default$1 from "../button/button.js";
import { property } from "lit/decorators.js";
//#region src/components/ai-label/ai-label-action-button.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI Label action button.
*
* @element cds-custom-ai-label-action-button
*/
let CDSAILabelActionButton = class CDSAILabelActionButton extends button_default$1 {
	constructor(..._args) {
		super(..._args);
		this.slot = "actions";
	}
	static {
		this.styles = [button_default, ai_label_default];
	}
};
__decorate([property({ reflect: true })], CDSAILabelActionButton.prototype, "slot", void 0);
CDSAILabelActionButton = __decorate([carbonElement(`cds-custom-ai-label-action-button`)], CDSAILabelActionButton);
var ai_label_action_button_default = CDSAILabelActionButton;
//#endregion
export { ai_label_action_button_default as default };

//# sourceMappingURL=ai-label-action-button.js.map