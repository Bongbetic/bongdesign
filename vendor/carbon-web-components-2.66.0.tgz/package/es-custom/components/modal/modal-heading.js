/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/modal/modal-heading.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal heading.
*
* @element cds-custom-modal-heading
*/
let CDSModalHeading = class CDSModalHeading extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--modal-heading--id-${Math.random().toString(16).slice(2)}`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSModalHeading.prototype, "id", void 0);
CDSModalHeading = __decorate([carbonElement(`cds-custom-modal-heading`)], CDSModalHeading);
var modal_heading_default = CDSModalHeading;
//#endregion
export { modal_heading_default as default };

//# sourceMappingURL=modal-heading.js.map