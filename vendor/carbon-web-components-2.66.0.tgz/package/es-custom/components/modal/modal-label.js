/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/modal/modal-label.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal label.
*
* @element cds-custom-modal-label
*/
let CDSModalLabel = class CDSModalLabel extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--modal-label--id-${Math.random().toString(16).slice(2)}`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSModalLabel.prototype, "id", void 0);
CDSModalLabel = __decorate([carbonElement(`cds-custom-modal-label`)], CDSModalLabel);
var modal_label_default = CDSModalLabel;
//#endregion
export { modal_label_default as default };

//# sourceMappingURL=modal-label.js.map