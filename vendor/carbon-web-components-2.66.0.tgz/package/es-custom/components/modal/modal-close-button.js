/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import modal_default from "./modal.scss.js";
import "../icon-button/index.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
import Close20 from "@carbon/icons/es/close/20.js";
//#region src/components/modal/modal-close-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal close button.
*
* @element cds-custom-modal-close-button
* @csspart button The button.
* @csspart close-icon The close icon.
*/
let CDSModalCloseButton = class CDSModalCloseButton extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.closeButtonLabel = "Close";
	}
	updated() {
		this.parentElement?.setAttribute("close-button", "");
	}
	render() {
		const { closeButtonLabel } = this;
		return html`
      <cds-custom-icon-button
        part="button"
        align="left"
        enter-delay-ms=""
        aria-label="${ifDefined(closeButtonLabel)}"
        kind="ghost"
        size="lg"
        leave-delay-ms="">
        ${iconLoader(Close20, {
			slot: "icon",
			part: "close-icon",
			class: `cds-custom--modal-close__icon`
		})}
        <span slot="tooltip-content">${closeButtonLabel}</span>
      </cds-custom-icon-button>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({ attribute: "close-button-label" })], CDSModalCloseButton.prototype, "closeButtonLabel", void 0);
CDSModalCloseButton = __decorate([carbonElement(`cds-custom-modal-close-button`)], CDSModalCloseButton);
var modal_close_button_default = CDSModalCloseButton;
//#endregion
export { modal_close_button_default as default };

//# sourceMappingURL=modal-close-button.js.map