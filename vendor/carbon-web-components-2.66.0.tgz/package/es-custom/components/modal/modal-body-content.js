/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
//#region src/components/modal/modal-body-content.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal body content
*
* @element cds-custom-modal-body-content
*/
let CDSModalBodyContent = class CDSModalBodyContent extends LitElement {
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = modal_default;
	}
};
CDSModalBodyContent = __decorate([carbonElement(`cds-custom-modal-body-content`)], CDSModalBodyContent);
var modal_body_content_default = CDSModalBodyContent;
//#endregion
export { modal_body_content_default as default };

//# sourceMappingURL=modal-body-content.js.map