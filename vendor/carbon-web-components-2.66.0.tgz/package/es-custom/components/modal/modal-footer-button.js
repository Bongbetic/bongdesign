/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "../button/button.scss.js";
import button_default$1 from "../button/button.js";
import modal_default from "./modal.scss.js";
//#region src/components/modal/modal-footer-button.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal footer button.
*
* @element cds-custom-modal-footer-button
*/
let CDSModalFooterButton = class CDSModalFooterButton extends button_default$1 {
	static {
		this.styles = [button_default, modal_default];
	}
};
CDSModalFooterButton = __decorate([carbonElement(`cds-custom-modal-footer-button`)], CDSModalFooterButton);
var modal_footer_button_default = CDSModalFooterButton;
//#endregion
export { modal_footer_button_default as default };

//# sourceMappingURL=modal-footer-button.js.map