/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../tooltip/definition-tooltip.js";
import "./page-header.js";
import "./page-header-breadcrumb.js";
import "./page-header-content.js";
import "./page-header-content-text.js";
import "./page-header-hero-image.js";
import "./page-header-tabs.js";
