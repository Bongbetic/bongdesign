/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/big-number/constants.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
let BigNumberSize = /* @__PURE__ */ function(BigNumberSize) {
	BigNumberSize["Default"] = "default";
	BigNumberSize["Large"] = "lg";
	BigNumberSize["XLarge"] = "xl";
	return BigNumberSize;
}({});
let Characters = /* @__PURE__ */ function(Characters) {
	Characters["Dash"] = "–";
	Characters["Slash"] = "/";
	Characters["Percentage"] = "%";
	return Characters;
}({});
const DefaultLocale = "en-US";
const UNKNOWN = "Unknown";
//#endregion
export { BigNumberSize, Characters, DefaultLocale, UNKNOWN };

//# sourceMappingURL=constants.js.map