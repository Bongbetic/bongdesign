/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../skeleton-text/index.js";
import "../skeleton-placeholder/index.js";
import "./constants.js";
import big_number_skeleton_default$1 from "./big-number-skeleton.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/big-number/big-number-skeleton.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--big-number-skeleton`;
/**
* @element cds-custom-big-number-skeleton
* Note: This component is only used within cds-custom-big-number. It displays a skeleton version while content is loading (handled by the cds-custom-big-number prop `loading`).
*/
let CDSBigNumberSkeleton = class CDSBigNumberSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.size = "default";
	}
	render() {
		const { size } = this;
		const bigNumberSkeletonClasses = classMap({
			[`${blockClass}`]: true,
			[`${blockClass}--lg`]: size === "lg",
			[`${blockClass}--xl`]: size === "xl"
		});
		return html`
      <div class=${bigNumberSkeletonClasses}>
        <cds-custom-skeleton-text class="${blockClass}__label"></cds-custom-skeleton-text>
        <cds-custom-skeleton-placeholder
          class="${blockClass}__value"></cds-custom-skeleton-placeholder>
      </div>
    `;
	}
	static {
		this.styles = big_number_skeleton_default$1;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSBigNumberSkeleton.prototype, "size", void 0);
CDSBigNumberSkeleton = __decorate([carbonElement(`cds-custom-big-number-skeleton`)], CDSBigNumberSkeleton);
var big_number_skeleton_default = CDSBigNumberSkeleton;
//#endregion
export { big_number_skeleton_default as default };

//# sourceMappingURL=big-number-skeleton.js.map