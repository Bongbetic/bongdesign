/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import { DefaultLocale, UNKNOWN } from "./constants.js";
import "./big-number-skeleton.js";
import { getSupportedLocale } from "../../globals/internal/getSupportedLocale.js";
import big_number_default$1 from "./big-number.scss.js";
import { LitElement, html, nothing } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import ArrowUp16 from "@carbon/icons/es/arrow--up/16";
import ArrowUp20 from "@carbon/icons/es/arrow--up/20";
import ArrowUp24 from "@carbon/icons/es/arrow--up/24";
//#region src/components/big-number/big-number.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--big-number`;
/**
* @element cds-custom-big-number
* @slot label - Header area that displays the label above the value. This slot can be customized to include an info icon and a tooltip for additional context.
* @slot trending-icon - Displays an icon indicating trend direction. Can be customized to show a downward arrow when the trend is not upward.
* @slot icon-button - Displays an icon button next to `value`.
*/
let CDSBigNumber = class CDSBigNumber extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.fractionDigits = 1;
		this.loading = false;
		this.locale = DefaultLocale;
		this.percentage = false;
		this.size = "default";
		this.trending = false;
		this.truncate = true;
	}
	_formatValue(locale, value, fractionDigits, truncate) {
		if (value === null || value === void 0) return null;
		return truncate ? Intl.NumberFormat(locale, {
			notation: "compact",
			minimumFractionDigits: fractionDigits,
			maximumFractionDigits: Math.round(fractionDigits)
		}).format(value) : Intl.NumberFormat(locale).format(value);
	}
	_getTruncatedValue(value, placeholder) {
		const supportedLocale = getSupportedLocale(this.locale, DefaultLocale);
		return this._formatValue(supportedLocale, value, this.fractionDigits, this.truncate) ?? placeholder;
	}
	_shouldDisplayDenominator(truncatedValue, truncatedTotal) {
		return !this.percentage && this.total !== void 0 && this.value !== void 0 && this.total > this.value && truncatedValue !== truncatedTotal;
	}
	_getTrendingIcon() {
		switch (this.size) {
			case "lg": return ArrowUp20;
			case "xl": return ArrowUp24;
			default: return ArrowUp16;
		}
	}
	render() {
		const { loading, label, percentage, size, total, trending, value } = this;
		const bigNumberClasses = classMap({
			[blockClass]: true,
			[`${blockClass}--lg`]: size === "lg",
			[`${blockClass}--xl`]: size === "xl"
		});
		const truncatedValue = this._getTruncatedValue(value, "–");
		const truncatedTotal = this._getTruncatedValue(total, UNKNOWN);
		const shouldDisplayDenominator = this._shouldDisplayDenominator(truncatedValue, truncatedTotal);
		if (loading) return html`
        <cds-custom-big-number-skeleton .size=${size}></cds-custom-big-number-skeleton>
      `;
		return html`
      <figure class=${bigNumberClasses}>
        <!-- Label slot -->
        <span class="${blockClass}__row">
          <slot name="label">
            <figcaption class="${blockClass}__label">${label}</figcaption>
          </slot>
        </span>
        <span class="${blockClass}__row" role="math">
          <!-- Trending up arrow  -->
          ${trending ? html`<slot name="trending-icon"
                >${iconLoader(this._getTrendingIcon(), {
			slot: "icon",
			class: `${blockClass}__trend`
		})}
              </slot>` : nothing}

          <!-- Numerator  -->
          <span class="${blockClass}__value">
            ${percentage ? html`<div class="${blockClass}__percentage">
                  ${truncatedValue}<span class="${blockClass}__percentage-mark"
                    >${"%"}</span
                  >
                </div>` : truncatedValue}
          </span>

          <!-- Denominator -->
          ${shouldDisplayDenominator ? html`<span class="${blockClass}__total">
                <span>${`/${truncatedTotal}`}</span>
              </span>` : nothing}

          <!-- Icon button -->
          <span class="${blockClass}__icon-button">
            <slot name="icon-button"></slot>
          </span>
        </span>
      </figure>
    `;
	}
	static {
		this.styles = big_number_default$1;
	}
};
__decorate([property({
	type: Number,
	attribute: "fraction-digits",
	reflect: true
})], CDSBigNumber.prototype, "fractionDigits", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSBigNumber.prototype, "label", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSBigNumber.prototype, "loading", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSBigNumber.prototype, "locale", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSBigNumber.prototype, "percentage", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSBigNumber.prototype, "size", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSBigNumber.prototype, "total", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSBigNumber.prototype, "trending", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSBigNumber.prototype, "truncate", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSBigNumber.prototype, "value", void 0);
CDSBigNumber = __decorate([carbonElement(`cds-custom-big-number`)], CDSBigNumber);
var big_number_default = CDSBigNumber;
//#endregion
export { big_number_default as default };

//# sourceMappingURL=big-number.js.map