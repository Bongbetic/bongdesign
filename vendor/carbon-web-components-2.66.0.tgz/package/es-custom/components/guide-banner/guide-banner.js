/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../button/index.js";
import guide_banner_default$1 from "./guide-banner.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Close16 from "@carbon/icons/es/close/16";
import Idea20 from "@carbon/icons/es/idea/20";
//#region src/components/guide-banner/guide-banner.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--guidebanner`;
const blockEvent = `cds-custom-guidebanner`;
/**
* GuideBanner.
*
* @element cds-custom-guide-banner
* @csspart guide-banner
* @fires cds-custom-guide-banner-toggle Custom event fired when banner is opened
* @fires cds-custom-guide-banner-close Custom event fired when banner is closed
* */
let CDSGuideBanner = class CDSGuideBanner extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.open = false;
	}
	static get eventToggle() {
		return `${blockEvent}-toggle`;
	}
	static get eventOnClose() {
		return `${blockEvent}-close`;
	}
	_handleClose() {
		this.dispatchEvent(new CustomEvent(this.constructor.eventOnClose, {
			bubbles: true,
			composed: true,
			detail: {}
		}));
	}
	_handleToggle() {
		this.open = !this.open;
		const init = {
			bubbles: true,
			composed: true,
			detail: { open: this.open }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventToggle, init));
	}
	_getTitle() {
		return html`<div class="${blockClass}__title">${this.titleText}</div>`;
	}
	_getButton() {
		const buttonText = this.open ? this.collapseText : this.expandText;
		return html`<cds-custom-button
      kind="ghost"
      size="md"
      class="${blockClass}__toggle-button"
      @click=${this._handleToggle}>
      ${buttonText}
    </cds-custom-button>`;
	}
	render() {
		const classes = classMap({
			[`${blockClass}`]: true,
			[`${blockClass}__collapsible-collapsed`]: !this.open
		});
		return html`
      <div class="${classes}">
        <div class="${blockClass}__header">
          <div class="${blockClass}__icon-idea">
            <slot name="icon">
              ${iconLoader(Idea20, { slot: "icon" })}
            </slot>
          </div>
          ${this._getTitle()}
          <slot name="header"></slot>
          <cds-custom-button
            align="bottom-end"
            class="${blockClass}__close-button"
            kind="ghost"
            size="md"
            @click="${this._handleClose}">
            ${iconLoader(Close16, { slot: "icon" })}
          </cds-custom-button>
        </div>
        <slot name="body"></slot>
        <div class="${blockClass}__navigation">
          <slot name="footer">${this._getButton()}</slot>
        </div>
      </div>
    `;
	}
	static {
		this.styles = guide_banner_default$1;
	}
};
__decorate([property({
	type: String,
	reflect: true,
	attribute: "collapse-text"
})], CDSGuideBanner.prototype, "collapseText", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "expand-text"
})], CDSGuideBanner.prototype, "expandText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSGuideBanner.prototype, "open", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "title-text"
})], CDSGuideBanner.prototype, "titleText", void 0);
CDSGuideBanner = __decorate([carbonElement(`cds-custom-guide-banner`)], CDSGuideBanner);
var guide_banner_default = CDSGuideBanner;
//#endregion
export { blockClass, guide_banner_default as default };

//# sourceMappingURL=guide-banner.js.map