/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import guide_banner_element_default$1 from "./guide-banner-element.scss.js";
import { LitElement, html } from "lit";
//#region src/components/guide-banner/guide-banner-element.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--guidebanner__element`;
/**
* GuideBannerElement.
*
* @element cds-custom-guide-banner-element
* @csspart guide-banner-element
* */
let CDSGuideBannerElement = class CDSGuideBannerElement extends LitElement {
	render() {
		return html`
      <div class="${blockClass}">
        <div class="${blockClass}__title">
          <slot name="title"></slot>
        </div>
        <div class="${blockClass}__description">
          <slot name="description"></slot>
        </div>
        <slot></slot>
      </div>
    `;
	}
	static {
		this.styles = guide_banner_element_default$1;
	}
};
CDSGuideBannerElement = __decorate([carbonElement(`cds-custom-guide-banner-element`)], CDSGuideBannerElement);
var guide_banner_element_default = CDSGuideBannerElement;
//#endregion
export { blockClass, guide_banner_element_default as default };

//# sourceMappingURL=guide-banner-element.js.map