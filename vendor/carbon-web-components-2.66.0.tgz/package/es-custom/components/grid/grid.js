/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { GRID_ALIGNMENT } from "./defs.js";
import { gridContext } from "./grid-context.js";
import grid_default$1 from "./grid.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { consume, provide } from "@lit/context";
//#region src/components/grid/grid.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The grid component.
*
* @element cds-custom-grid
*/ let CDSGrid = class CDSGrid extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.condensed = false;
		this.narrow = false;
		this.fullWidth = false;
		this.withRowGap = false;
		this.gridContext = { subgrid: false };
	}
	render() {
		this.gridContext = { subgrid: true };
		if (this.gridContextIn?.subgrid) {
			let subMode = "wide";
			if (this.narrow) subMode = "narrow";
			else if (this.condensed) subMode = "condensed";
			return html`<div
        subgrid
        mode=${subMode}
        ?with-row-gap=${this.withRowGap}
        part="grid">
        <slot></slot>
      </div> `;
		} else return html`<div grid part="grid">
        <slot></slot>
      </div> `;
	}
	static {
		this.styles = grid_default$1;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSGrid.prototype, "align", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSGrid.prototype, "condensed", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSGrid.prototype, "narrow", void 0);
__decorate([property({
	reflect: true,
	attribute: "full-width",
	type: Boolean
})], CDSGrid.prototype, "fullWidth", void 0);
__decorate([property({
	reflect: true,
	attribute: "with-row-gap",
	type: Boolean
})], CDSGrid.prototype, "withRowGap", void 0);
__decorate([consume({
	context: gridContext,
	subscribe: true
}), property({ attribute: false })], CDSGrid.prototype, "gridContextIn", void 0);
__decorate([provide({ context: gridContext }), property({ attribute: false })], CDSGrid.prototype, "gridContext", void 0);
CDSGrid = __decorate([carbonElement(`cds-custom-grid`)], CDSGrid);
var grid_default = CDSGrid;
//#endregion
export { GRID_ALIGNMENT, grid_default as default };

//# sourceMappingURL=grid.js.map