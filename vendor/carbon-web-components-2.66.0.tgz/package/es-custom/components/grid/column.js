/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { LitElement } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/grid/column.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The column component.
*
* @element cds-custom-column
*/
let CDSColumn = class CDSColumn extends LitElement {
	createRenderRoot() {
		return this;
	}
};
__decorate([property({ reflect: true })], CDSColumn.prototype, "sm", void 0);
__decorate([property({ reflect: true })], CDSColumn.prototype, "md", void 0);
__decorate([property({ reflect: true })], CDSColumn.prototype, "lg", void 0);
__decorate([property({ reflect: true })], CDSColumn.prototype, "xlg", void 0);
__decorate([property({ reflect: true })], CDSColumn.prototype, "max", void 0);
__decorate([property({ reflect: true })], CDSColumn.prototype, "span", void 0);
CDSColumn = __decorate([carbonElement(`cds-custom-column`)], CDSColumn);
var column_default = CDSColumn;
//#endregion
export { column_default as default };

//# sourceMappingURL=column.js.map