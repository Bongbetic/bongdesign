/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import column_hang_default$1 from "./column-hang.scss.js";
import { LitElement, html } from "lit";
//#region src/components/grid/column-hang.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The column component.
*
* @element cds-custom-column-hang
*/
let CDSColumnHang = class CDSColumnHang extends LitElement {
	render() {
		return html`<div part="column-hang">
      <slot></slot>
    </div>`;
	}
	static {
		this.styles = column_hang_default$1;
	}
};
CDSColumnHang = __decorate([carbonElement(`cds-custom-column-hang`)], CDSColumnHang);
var column_hang_default = CDSColumnHang;
//#endregion
export { column_hang_default as default };

//# sourceMappingURL=column-hang.js.map