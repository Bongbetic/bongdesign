/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/grid/defs.ts
/**
* Button size.
*/
let GRID_ALIGNMENT = /* @__PURE__ */ function(GRID_ALIGNMENT) {
	/**
	* Align to start.
	*/
	GRID_ALIGNMENT["START"] = "start";
	/**
	* Align in center
	*/
	GRID_ALIGNMENT["CENTER"] = "center";
	/**
	* Align to end
	*/
	GRID_ALIGNMENT["END"] = "end";
	return GRID_ALIGNMENT;
}({});
/**
* Button type.
*/
let SUB_GRID_MODE = /* @__PURE__ */ function(SUB_GRID_MODE) {
	/**
	* Default sug-grid mode.
	*/
	SUB_GRID_MODE["WIDE"] = "wide";
	/**
	* Condensed sub-grid (should match hosting grid).
	*/
	SUB_GRID_MODE["CONDENSED"] = "condensed";
	/**
	* Narrow sub-grid (should match hosting grid).
	*/
	SUB_GRID_MODE["NARROW"] = "narrow";
	return SUB_GRID_MODE;
}({});
//#endregion
export { GRID_ALIGNMENT, SUB_GRID_MODE };

//# sourceMappingURL=defs.js.map