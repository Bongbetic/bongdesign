/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "./tag.js";
import "./dismissible-tag.js";
import "./tag-skeleton.js";
import "./selectable-tag.js";
import "./operational-tag.js";
