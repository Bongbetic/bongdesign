/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "./defs.js";
import date_picker_default from "./date-picker.scss.js";
import "./date-picker-input.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/date-picker/date-picker-input-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton version of the input box for date picker.
*/
let CDSDatePickerInputSkeleton = class CDSDatePickerInputSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
		this.kind = "simple";
		this.range = false;
	}
	render() {
		const { hideLabel, range } = this;
		return html`
      <div class="${"cds-custom"}--date-picker-input-skeleton-container">
        ${!hideLabel ? html`<span class="${"cds-custom"}--label"></span>` : null}
        <div class="${"cds-custom"}--date-picker__input ${"cds-custom"}--skeleton"></div>
      </div>
      ${range ? html`
            <div class="${"cds-custom"}--date-picker-input-skeleton-container">
              ${!hideLabel ? html`<span class="${"cds-custom"}--label"></span>` : null}
              <div
                class="${"cds-custom"}--date-picker__input ${"cds-custom"}--skeleton"></div>
            </div>
          ` : null}
    `;
	}
	static {
		this.styles = date_picker_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSDatePickerInputSkeleton.prototype, "hideLabel", void 0);
__decorate([property({ reflect: true })], CDSDatePickerInputSkeleton.prototype, "kind", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "range"
})], CDSDatePickerInputSkeleton.prototype, "range", void 0);
CDSDatePickerInputSkeleton = __decorate([carbonElement(`cds-custom-date-picker-input-skeleton`)], CDSDatePickerInputSkeleton);
var date_picker_input_skeleton_default = CDSDatePickerInputSkeleton;
//#endregion
export { date_picker_input_skeleton_default as default };

//# sourceMappingURL=date-picker-input-skeleton.js.map