/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import on from "../../globals/mixins/on.js";
import date_picker_input_default from "./date-picker-input.js";
//#region src/components/date-picker/focus-plugin.ts
/**
* @param config Plugin configuration.
* @returns A Flatpickr plugin to manage focus to align with the UX pattern in our design system.
*/
var focus_plugin_default = (config) => (fp) => {
	/**
	* Focuses on calendar dropdown.
	*/
	const focusCalendar = () => {
		const { calendarContainer, selectedDateElem, todayDateElem } = fp;
		(selectedDateElem || todayDateElem || calendarContainer).focus();
	};
	/**
	* Handles `keydown` event for date picker input field
	*/
	const handleInputKeydown = (event) => {
		if (!(event.target instanceof date_picker_input_default)) return;
		const { key } = event;
		if (key === "Escape") fp.close();
		if (key === "Tab") {
			if (!event.shiftKey) {
				event.preventDefault();
				fp.open();
				focusCalendar();
			} else if (fp.isOpen && event.target === config.inputFrom) fp.close();
		}
	};
	/**
	* Handles `keydown` event for calendar dropdown
	*/
	const handleCalendarKeydown = (event) => {
		const endInput = config.inputTo ? config.inputTo : config.inputFrom;
		const { key } = event;
		if (key === "Tab") {
			if (!event.shiftKey) {
				if (fp._lastFocusInput === endInput) {
					endInput.focus();
					fp.close();
				} else {
					event.preventDefault();
					endInput.focus();
				}
			} else if (fp._lastFocusInput === endInput) {
				event.preventDefault();
				setTimeout(() => endInput.focus(), 0);
			}
		}
	};
	/**
	* Handles `focus` event on `<input>` for starting/end date to track the lastly focused one.
	*/
	const handleInputFocus = ({ target }) => {
		fp._lastFocusInput = target;
	};
	/**
	* Releases event listeners used in this Flatpickr plugin.
	*/
	const release = () => {
		if (fp._hCDSCEDatePickerFocusPluginBlur) fp._hCDSCEDatePickerFocusPluginBlur = fp._hCDSCEDatePickerFocusPluginBlur.release();
		if (fp._hCDSCEDatePickerFocusPluginFocusTo) fp._hCDSCEDatePickerFocusPluginFocusTo = fp._hCDSCEDatePickerFocusPluginFocusTo.release();
		if (fp._hCDSCEDatePickerFocusPluginFocusFrom) fp._hCDSCEDatePickerFocusPluginFocusFrom = fp._hCDSCEDatePickerFocusPluginFocusFrom.release();
		if (fp._hCDSCEDatePickerFocusPluginKeydownTo) fp._hCDSCEDatePickerFocusPluginKeydownTo = fp._hCDSCEDatePickerFocusPluginKeydownTo.release();
		if (fp._hCDSCEDatePickerFocusPluginKeydownFrom) fp._hCDSCEDatePickerFocusPluginKeydownFrom = fp._hCDSCEDatePickerFocusPluginKeydownFrom.release();
	};
	/**
	* Sets up event listeners used for this Flatpickr plugin.
	*/
	const init = () => {
		release();
		const { inputFrom, inputTo } = config;
		fp._hCDSCEDatePickerFocusPluginBlur = on(fp.calendarContainer, "keydown", handleCalendarKeydown, true);
		fp._hCDSCEDatePickerFocusPluginKeydownFrom = on(inputFrom, "keydown", handleInputKeydown);
		if (inputTo) fp._hCDSCEDatePickerFocusPluginKeydownTo = on(inputTo, "keydown", handleInputKeydown);
		fp._hCDSCEDatePickerFocusPluginFocusFrom = on(inputFrom, "focus", handleInputFocus);
		if (inputTo) fp._hCDSCEDatePickerFocusPluginFocusTo = on(inputTo, "focus", handleInputFocus);
	};
	/**
	* Registers this Flatpickr plugin.
	*
	*/
	const register = () => {
		fp.loadedPlugins.push("carbonFlatpickrFocusPlugin");
	};
	return {
		onReady: [register, init],
		onDestroy: release
	};
};
//#endregion
export { focus_plugin_default as default };

//# sourceMappingURL=focus-plugin.js.map