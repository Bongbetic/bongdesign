/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/date-picker/defs.ts
/**
* Input sizes.
*/
let INPUT_SIZE = /* @__PURE__ */ function(INPUT_SIZE) {
	/**
	* Small size.
	*/
	INPUT_SIZE["SMALL"] = "sm";
	/**
	* Medium size (default).
	*/
	INPUT_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	INPUT_SIZE["LARGE"] = "lg";
	return INPUT_SIZE;
}({});
/**
* Date picker input kinds.
*/
let DATE_PICKER_INPUT_KIND = /* @__PURE__ */ function(DATE_PICKER_INPUT_KIND) {
	/**
	* One for simple variant of date picker, comes without the calendar dropdown.
	*/
	DATE_PICKER_INPUT_KIND["SIMPLE"] = "simple";
	/**
	* One for single variant of date picker.
	*/
	DATE_PICKER_INPUT_KIND["SINGLE"] = "single";
	/**
	* One for the start date for the range variant.
	*/
	DATE_PICKER_INPUT_KIND["FROM"] = "from";
	/**
	* One for the end date for the range variant.
	*/
	DATE_PICKER_INPUT_KIND["TO"] = "to";
	return DATE_PICKER_INPUT_KIND;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as DATE_PICKER_INPUT_COLOR_SCHEME, DATE_PICKER_INPUT_KIND, INPUT_SIZE };

//# sourceMappingURL=defs.js.map