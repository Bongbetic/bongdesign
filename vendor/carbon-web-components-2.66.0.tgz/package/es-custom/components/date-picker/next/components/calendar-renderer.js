/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../../globals/settings.js";
import { carbonElement } from "../../../../globals/decorators/carbon-element.js";
import __decorate from "../../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../../../globals/internal/icon-loader.js";
import date_picker_default from "./date-picker.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import ChevronRight16 from "@carbon/icons/es/chevron--right/16.js";
import { ifDefined } from "lit/directives/if-defined.js";
import ChevronLeft16 from "@carbon/icons/es/chevron--left/16.js";
import { generateCalendarGrid, getFullDateLabel, getMonthYearLabel, getWeekdayLabels } from "@carbon/utilities/date-picker";
//#region src/components/date-picker/next/components/calendar-renderer.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Calendar renderer for date picker.
* Replaces Flatpickr's calendar UI with a lightweight, framework-agnostic implementation.
*
* @element cds-custom-preview-date-picker-calendar
* @fires cds-custom-preview-date-picker-calendar-date-select - Fired when a date is selected
* @fires cds-custom-preview-date-picker-calendar-month-change - Fired when the month changes
*/
let CDSDatePickerCalendar = class CDSDatePickerCalendar extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._currentMonth = Temporal.Now.plainDateISO().toPlainYearMonth();
		this.selectedDates = [];
		this.rangeMode = false;
		this.dateFormat = "m/d/Y";
		this.locale = "en-US";
	}
	/**
	* Navigate to previous month
	*/
	_handlePrevMonth() {
		this._currentMonth = this._currentMonth.subtract({ months: 1 });
		this._dispatchMonthChange();
	}
	/**
	* Navigate to next month
	*/
	_handleNextMonth() {
		this._currentMonth = this._currentMonth.add({ months: 1 });
		this._dispatchMonthChange();
	}
	/**
	* Handle date selection
	* @param {Temporal.PlainDate} date - The date to select
	*/
	_handleDateSelect(date) {
		if (this._isDateDisabled(date)) return;
		this.dispatchEvent(new CustomEvent(`cds-custom-preview-date-picker-calendar-date-select`, {
			bubbles: true,
			composed: true,
			detail: { date }
		}));
	}
	/**
	* Dispatch month change event
	*/
	_dispatchMonthChange() {
		this.dispatchEvent(new CustomEvent(`cds-custom-preview-date-picker-calendar-month-change`, {
			bubbles: true,
			composed: true,
			detail: { month: this._currentMonth }
		}));
	}
	/**
	* Check if a date is disabled
	* @param {Temporal.PlainDate} date - The date to check
	*/
	_isDateDisabled(date) {
		if (this.minDate && Temporal.PlainDate.compare(date, this.minDate) < 0) return true;
		if (this.maxDate && Temporal.PlainDate.compare(date, this.maxDate) > 0) return true;
		return false;
	}
	/**
	* Check if previous month navigation should be disabled
	*/
	_isPrevMonthDisabled() {
		if (!this.minDate) return false;
		const prevMonth = this._currentMonth.subtract({ months: 1 });
		const prevMonthLastDay = prevMonth.toPlainDate({ day: prevMonth.daysInMonth });
		return Temporal.PlainDate.compare(prevMonthLastDay, this.minDate) < 0;
	}
	/**
	* Check if next month navigation should be disabled
	*/
	_isNextMonthDisabled() {
		if (!this.maxDate) return false;
		const nextMonthFirstDay = this._currentMonth.add({ months: 1 }).toPlainDate({ day: 1 });
		return Temporal.PlainDate.compare(nextMonthFirstDay, this.maxDate) > 0;
	}
	/**
	* Check if a date is selected
	* @param {Temporal.PlainDate} date - The date to check
	*/
	_isDateSelected(date) {
		return this.selectedDates.some((selected) => {
			if (!selected || typeof selected !== "object" || !("year" in selected)) return false;
			return Temporal.PlainDate.compare(selected, date) === 0;
		});
	}
	/**
	* Check if a date is in range (for range mode)
	* @param {Temporal.PlainDate} date - The date to check
	*/
	_isDateInRange(date) {
		if (!this.rangeMode) return false;
		if (this.selectedDates.length === 2) {
			const [start, end] = this.selectedDates.sort((a, b) => Temporal.PlainDate.compare(a, b));
			return Temporal.PlainDate.compare(date, start) >= 0 && Temporal.PlainDate.compare(date, end) <= 0;
		}
		const previewDate = this._hoveredDate || this.focusedDate;
		if (this.selectedDates.length === 1 && previewDate) {
			if (this.minDate && Temporal.PlainDate.compare(previewDate, this.minDate) < 0 || this.maxDate && Temporal.PlainDate.compare(previewDate, this.maxDate) > 0) return false;
			const [rangeStart, rangeEnd] = [this.selectedDates[0], previewDate].sort((a, b) => Temporal.PlainDate.compare(a, b));
			return Temporal.PlainDate.compare(date, rangeStart) >= 0 && Temporal.PlainDate.compare(date, rangeEnd) <= 0;
		}
		return false;
	}
	/**
	* Check if a date is focused (for keyboard navigation)
	* @param {Temporal.PlainDate} date - The date to check
	*/
	_isDateFocused(date) {
		if (!this.focusedDate) return false;
		return Temporal.PlainDate.compare(date, this.focusedDate) === 0;
	}
	/**
	* Handle mouse enter on a date
	* @param {Temporal.PlainDate} date - The date being hovered
	*/
	_handleDateMouseEnter(date) {
		if (this.rangeMode && this.selectedDates.length === 1) this._hoveredDate = date;
	}
	/**
	* Handle mouse leave on a date
	*/
	_handleDateMouseLeave() {
		this._hoveredDate = void 0;
	}
	/**
	* Render the calendar header with month/year and navigation
	*/
	_renderHeader() {
		const monthName = getMonthYearLabel(this._currentMonth.toPlainDate({ day: 1 }), this.locale);
		const isPrevDisabled = this._isPrevMonthDisabled();
		const isNextDisabled = this._isNextMonthDisabled();
		return html`
      <div class="${"cds-custom"}--date-picker__month">
        <button
          type="button"
          class="${"cds-custom"}--date-picker__month-nav ${"cds-custom"}--date-picker__month-nav--prev"
          tabindex="-1"
          ?disabled="${isPrevDisabled}"
          @click="${this._handlePrevMonth}"
          aria-label="Previous month">
          ${iconLoader(ChevronLeft16)}
        </button>
        <div class="${"cds-custom"}--date-picker__current-month">
          <span class="cur-month">${monthName}</span>
        </div>
        <button
          type="button"
          class="${"cds-custom"}--date-picker__month-nav ${"cds-custom"}--date-picker__month-nav--next"
          tabindex="-1"
          ?disabled="${isNextDisabled}"
          @click="${this._handleNextMonth}"
          aria-label="Next month">
          ${iconLoader(ChevronRight16)}
        </button>
      </div>
    `;
	}
	/**
	* Render the weekday headers
	*/
	_renderWeekdays() {
		const weekdays = getWeekdayLabels(this.locale);
		return html`
      <div class="${"cds-custom"}--date-picker__weekdays">
        ${weekdays.map((day) => html`
            <span class="${"cds-custom"}--date-picker__weekday">${day}</span>
          `)}
      </div>
    `;
	}
	/**
	* Render the calendar days grid
	*/
	_renderDays() {
		const currentMonthValue = this._currentMonth.month;
		const days = generateCalendarGrid(this._currentMonth.toPlainDate({ day: 1 }), this.minDate ?? null, this.maxDate ?? null).flat();
		return html`
      <div class="${"cds-custom"}--date-picker__days" role="grid">
        ${days.map(({ date, isCurrentMonth, isDisabled, isToday }) => {
			const isSelected = this._isDateSelected(date);
			const isInRange = this._isDateInRange(date);
			const isFocused = this._isDateFocused(date);
			const dayClasses = classMap({
				[`cds-custom--date-picker__day`]: true,
				prevMonthDay: !isCurrentMonth && date.month < currentMonthValue,
				nextMonthDay: !isCurrentMonth && date.month > currentMonthValue,
				disabled: isDisabled,
				selected: isSelected,
				inRange: isInRange,
				today: isToday && !isSelected,
				"no-border": isToday && isSelected,
				focused: isFocused
			});
			return html`
            <button
              type="button"
              class="${dayClasses}"
              tabindex="-1"
              ?disabled="${isDisabled}"
              @click="${() => this._handleDateSelect(date)}"
              @mouseenter="${() => this._handleDateMouseEnter(date)}"
              @mouseleave="${() => this._handleDateMouseLeave()}"
              aria-label="${getFullDateLabel(date, this.locale)}"
              aria-current="${ifDefined(isToday ? "date" : void 0)}">
              ${date.day}
            </button>
          `;
		})}
      </div>
    `;
	}
	/**
	* Lifecycle method called when properties change
	* @param {PropertyValues} changedProperties - Changed properties
	*/
	updated(changedProperties) {
		if (changedProperties.has("viewDate") && this.viewDate) this._currentMonth = Temporal.PlainYearMonth.from({
			year: this.viewDate.year,
			month: this.viewDate.month
		});
	}
	/**
	* Renders the calendar component
	*/
	render() {
		return html`
      <div class="${"cds-custom"}--date-picker__calendar" tabindex="0">
        ${this._renderHeader()} ${this._renderWeekdays()} ${this._renderDays()}
      </div>
    `;
	}
	static {
		this.styles = date_picker_default;
	}
};
__decorate([state()], CDSDatePickerCalendar.prototype, "_currentMonth", void 0);
__decorate([property({ type: Array })], CDSDatePickerCalendar.prototype, "selectedDates", void 0);
__decorate([property({ type: Object })], CDSDatePickerCalendar.prototype, "viewDate", void 0);
__decorate([property({ type: Object })], CDSDatePickerCalendar.prototype, "focusedDate", void 0);
__decorate([state()], CDSDatePickerCalendar.prototype, "_hoveredDate", void 0);
__decorate([property({ type: Object })], CDSDatePickerCalendar.prototype, "minDate", void 0);
__decorate([property({ type: Object })], CDSDatePickerCalendar.prototype, "maxDate", void 0);
__decorate([property({ type: Boolean })], CDSDatePickerCalendar.prototype, "rangeMode", void 0);
__decorate([property({ type: String })], CDSDatePickerCalendar.prototype, "dateFormat", void 0);
__decorate([property({ type: String })], CDSDatePickerCalendar.prototype, "locale", void 0);
CDSDatePickerCalendar = __decorate([carbonElement(`cds-custom-preview-date-picker-calendar`)], CDSDatePickerCalendar);
var calendar_renderer_default = CDSDatePickerCalendar;
//#endregion
export { calendar_renderer_default as default };

//# sourceMappingURL=calendar-renderer.js.map