/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import form_group_default$1 from "./form-group.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/form-group/form-group.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The shell UI for file uploader.
*
* @element cds-custom-form-group
*/
let CDSFormGroup = class CDSFormGroup extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.invalid = false;
		this.message = false;
	}
	render() {
		const { invalid, legendId, legendText, message, messageText } = this;
		return html`
      <fieldset
        class="${"cds-custom"}--fieldset"
        ?data-invalid=${invalid}
        aria-labelledby="${legendId}">
        <legend class="${"cds-custom"}--label" id=${legendId}>${legendText}</legend>
        <slot></slot>
        ${message ? html`<div class="${"cds-custom"}--form__requirements">
              ${messageText}
            </div>` : null}
      </fieldset>
    `;
	}
	static {
		this.styles = form_group_default$1;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFormGroup.prototype, "invalid", void 0);
__decorate([property({ attribute: "legend-id" })], CDSFormGroup.prototype, "legendId", void 0);
__decorate([property({ attribute: "legend-text" })], CDSFormGroup.prototype, "legendText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFormGroup.prototype, "message", void 0);
__decorate([property({
	type: String,
	attribute: "message-text",
	reflect: true
})], CDSFormGroup.prototype, "messageText", void 0);
CDSFormGroup = __decorate([carbonElement(`cds-custom-form-group`)], CDSFormGroup);
var form_group_default = CDSFormGroup;
//#endregion
export { form_group_default as default };

//# sourceMappingURL=form-group.js.map