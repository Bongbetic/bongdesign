/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import text_input_skeleton_default from "../text-input/text-input-skeleton.js";
import fluid_text_input_default from "./fluid-text-input.scss.js";
import { html } from "lit";
//#region src/components/fluid-text-input/fluid-text-input-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-text-input-skeleton
*/
let CDSFluidTextInputSkeleton = class CDSFluidTextInputSkeleton extends text_input_skeleton_default {
	render() {
		return html` ${super.render()} `;
	}
	static {
		this.styles = [text_input_skeleton_default.styles, fluid_text_input_default];
	}
};
CDSFluidTextInputSkeleton = __decorate([carbonElement(`cds-custom-fluid-text-input-skeleton`)], CDSFluidTextInputSkeleton);
var fluid_text_input_skeleton_default = CDSFluidTextInputSkeleton;
//#endregion
export { fluid_text_input_skeleton_default as default };

//# sourceMappingURL=fluid-text-input-skeleton.js.map