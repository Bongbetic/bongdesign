/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../modal/index.js";
import interstitial_screen_default$1 from "./interstitial-screen.scss.js";
import { defaultInterstitialState, interstitialContext } from "./interstitial-screen-context.js";
import { clearFocusableContainers, trapFocus } from "../../utilities/manageFocusTrap/manageFocusTrap.js";
import { LitElement, html, nothing } from "lit";
import { property, query, state } from "lit/decorators.js";
import { ContextProvider } from "@lit/context";
//#region src/components/interstitial-screen/interstitial-screen.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--interstitial-screen`;
/**
* interstitial-screen main component
* @element cds-custom-interstitial-screen
* @fires cds-custom-interstitial-opened -  The custom event triggered after loading the component.
* Its event.detail will provide you with carousal api methods for step navigation and method to disable any action button
* * @fires cds-custom-interstitial-beingclosed - The name of the custom event fired before interstitial is being closed upon a user gesture.
* Cancellation of this event stops the user-initiated action of closing the interstitial.
* @fires cds-custom-interstitial-closed - The name of the custom event fired after this tearsheet is closed upon a user gesture.

*/
let CDSInterstitialScreen = class CDSInterstitialScreen extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.isFullScreen = false;
		this.open = false;
		this.stepDetails = [];
		this._wasOpen = false;
		this._trapFocusAPI = null;
		this._contextProvider = new ContextProvider(this, {
			context: interstitialContext,
			initialValue: {
				state: { ...defaultInterstitialState },
				setState: (patch) => this._updateState(patch)
			}
		});
		this.dispatchInItializeEvent = () => {
			setTimeout(() => {
				const { carouselAPI } = this._contextProvider.value.state;
				this.dispatchEvent(new CustomEvent(this.constructor.eventOnInterstitialOpened, {
					bubbles: true,
					cancelable: true,
					composed: true,
					detail: {
						carouselAPI: carouselAPI ? {
							next: carouselAPI.next,
							prev: carouselAPI.prev,
							reset: carouselAPI.reset,
							goToStep: carouselAPI.goToIndex
						} : void 0,
						setDisableActionButtons: this.setDisableActionButtons
					}
				}));
			});
		};
		this._handleOutsideClick = (event) => {
			const modalContent = (this.shadowRoot?.querySelector(`cds-custom-modal`))?.shadowRoot?.querySelector(`.cds-custom--modal-container`);
			const path = event.composedPath();
			if (modalContent && !path.includes(modalContent)) this._handleClose(event);
		};
		this.setDisableActionButtons = (config) => {
			this._updateState({ disableActions: config });
		};
	}
	_updateState(patch) {
		this._contextProvider.setValue({
			...this._contextProvider.value,
			state: {
				...this._contextProvider.value.state,
				...patch
			}
		});
	}
	connectedCallback() {
		super.connectedCallback();
		this.addEventListener(`cds-custom-request-close`, this._handleClose);
	}
	disconnectedCallback() {
		super.disconnectedCallback();
		const { carouselAPI } = this._contextProvider.value.state;
		carouselAPI?.destroyEvents?.();
		this._trapFocusAPI?.cleanup();
		clearFocusableContainers();
	}
	firstUpdated() {
		this.requestUpdate();
		this._updateState({ isFullScreen: this.isFullScreen });
	}
	updated(changedProps) {
		if (changedProps.has("open")) {
			const wasOpen = this._wasOpen;
			const isOpen = this.open;
			this._updateState({ open: isOpen });
			if (!wasOpen && isOpen) {
				this.dispatchInItializeEvent();
				this._trapFocusAPI = trapFocus();
			}
			this._wasOpen = isOpen;
		}
	}
	_handleClose(e) {
		this.open = false;
		e.stopPropagation();
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { triggeredBy: e?.detail?.triggeredBy ?? e.target }
		};
		if (this.dispatchEvent(new CustomEvent(this.constructor.eventBeforeClose, init))) {
			this.dispatchEvent(new CustomEvent(this.constructor.eventClose, init));
			const { carouselAPI } = this._contextProvider.value.state;
			if (carouselAPI) carouselAPI.reset();
			this._updateState({ currentStep: 0 });
		}
	}
	renderFullScreen() {
		return html`
      <div class="${blockClass}--container">
        <slot name="header"></slot>
        <slot name="body"></slot>
        <slot name="footer"></slot>
      </div>
    `;
	}
	renderModal() {
		return html`<cds-custom-modal
      key=${this.open}
      ?prevent-close-on-click-outside="true"
      class=${blockClass}
      size="lg"
      ?open="${this.open}">
      <slot name="header"></slot>
      <cds-custom-modal-body class="${blockClass}__body-container">
        <slot name="body"></slot>
      </cds-custom-modal-body>
      <cds-custom-modal-footer>
        <slot name="footer"></slot>
      </cds-custom-modal-footer>
    </cds-custom-modal>`;
	}
	render() {
		return this.open ? this.isFullScreen ? html`${this.renderFullScreen()}` : html`${this.renderModal()}` : nothing;
	}
	static {
		this.styles = interstitial_screen_default$1;
	}
	/**
	* The name of the custom event fired after the interstitial is opened.
	*/
	static get eventOnInterstitialOpened() {
		return `cds-custom-interstitial-opened`;
	}
	/**
	
	* The name of the custom event fired before interstitial is being closed upon a user gesture.
	* Cancellation of this event stops the user-initiated action of closing the interstitial.
	*/
	static get eventBeforeClose() {
		return `cds-custom-interstitial-beingclosed`;
	}
	/**
	* The name of the custom event fired after this tearsheet is closed upon a user gesture.
	*/
	static get eventClose() {
		return `cds-custom-interstitial-closed`;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "fullscreen"
})], CDSInterstitialScreen.prototype, "isFullScreen", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSInterstitialScreen.prototype, "open", void 0);
__decorate([state()], CDSInterstitialScreen.prototype, "stepDetails", void 0);
__decorate([query("cds-custom-modal-body")], CDSInterstitialScreen.prototype, "modalBody", void 0);
__decorate([HostListener("click")], CDSInterstitialScreen.prototype, "_handleOutsideClick", void 0);
CDSInterstitialScreen = __decorate([carbonElement(`cds-custom-interstitial-screen`)], CDSInterstitialScreen);
var interstitial_screen_default = CDSInterstitialScreen;
//#endregion
export { blockClass, interstitial_screen_default as default };

//# sourceMappingURL=interstitial-screen.js.map