/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import { interstitialContext } from "./interstitial-screen-context.js";
import interstitial_screen_body_default$1 from "./interstitial-screen-body.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
import { consume } from "@lit/context";
import { initCarousel } from "@carbon/utilities";
import { createRef, ref } from "lit/directives/ref.js";
//#region src/components/interstitial-screen/interstitial-screen-body.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--interstitial-screen`;
/**
* interstitial-screen-body for body section
* @element cds-custom-interstitial-screen-body
* @fires cds-custom-on-before-step-change - The name of the custom event fired at the start of  the step change.
* @fires cds-custom-on-after-step-change -  The name of the custom event fired at the end of  the step change.
*/
let CDSInterstitialScreenBody = class CDSInterstitialScreenBody extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.slot = "body";
		this.stepType = "multi";
		this.carouselElement = createRef();
		this.onViewChangeStart = ({ currentIndex, lastIndex, totalViews }) => {
			this.dispatchEvent(new CustomEvent(this.constructor.eventOnViewChangeStart, {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: {
					currentStep: currentIndex,
					totalStepCount: totalViews,
					lastStep: lastIndex
				}
			}));
		};
		this.onViewChangeEnd = ({ currentIndex, lastIndex, totalViews }) => {
			this.updateAriaHiddenTabIndex(currentIndex);
			this._interstitialCtx?.setState({ currentStep: currentIndex });
			this.dispatchEvent(new CustomEvent(this.constructor.eventOnViewChangeEnd, {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: {
					currentStep: currentIndex,
					totalStepCount: totalViews,
					lastStep: lastIndex
				}
			}));
		};
		this.updateAriaHiddenTabIndex = (itemNumber) => {
			const allViews = this.carouselAPI?.allViews;
			if (allViews) Object.values(allViews).forEach((item, idx) => {
				const isActive = idx === itemNumber;
				if (item) {
					item.setAttribute("aria-hidden", String(!isActive));
					if (!isActive) item.setAttribute("inert", "");
					else item.removeAttribute("inert");
					item.removeAttribute("tabindex");
				}
			});
		};
	}
	firstUpdated() {
		const bodyItems = this.querySelectorAll(`cds-custom-interstitial-screen-body-item`);
		if (bodyItems.length === 1) this.stepType = "single";
		else if (bodyItems.length > 1) this.stepType = "multi";
	}
	updated(changedProps) {
		super.updated(changedProps);
		if ((this._interstitialCtx?.state?.open ?? false) && !this.carouselAPI && this.stepType === "multi" && this.carouselElement.value) this._initCarousel();
	}
	_initCarousel() {
		if (!this.carouselElement.value) return;
		this.carouselAPI = initCarousel(this.carouselElement.value, {
			onViewChangeEnd: this.onViewChangeEnd,
			onViewChangeStart: this.onViewChangeStart,
			excludeSwipeSupport: true,
			useMaxHeight: true
		});
		this._interstitialCtx?.setState({ carouselAPI: this.carouselAPI });
		this.updateAriaHiddenTabIndex(0);
	}
	render() {
		return html`
      <div class="${blockClass}--body">
        ${this.stepType === "multi" ? html`<div
              ${ref(this.carouselElement)}
              class="${blockClass}__carousel">
              <slot></slot>
            </div>` : html`<div class="${blockClass}__contentWrapper">
              <slot></slot>
            </div>`}
      </div>
    `;
	}
	static {
		this.styles = interstitial_screen_body_default$1;
	}
	/**
	* The name of the custom event fired at the start of  the step change.
	*/
	static get eventOnViewChangeStart() {
		return `cds-custom-on-before-step-change`;
	}
	/**
	* The name of the custom event fired at the end of  the step change.
	*/
	static get eventOnViewChangeEnd() {
		return `cds-custom-on-after-step-change`;
	}
};
__decorate([property({ reflect: true })], CDSInterstitialScreenBody.prototype, "slot", void 0);
__decorate([state()], CDSInterstitialScreenBody.prototype, "stepType", void 0);
__decorate([consume({
	context: interstitialContext,
	subscribe: true
}), state()], CDSInterstitialScreenBody.prototype, "_interstitialCtx", void 0);
CDSInterstitialScreenBody = __decorate([carbonElement(`cds-custom-interstitial-screen-body`)], CDSInterstitialScreenBody);
var interstitial_screen_body_default = CDSInterstitialScreenBody;
//#endregion
export { interstitial_screen_body_default as default };

//# sourceMappingURL=interstitial-screen-body.js.map