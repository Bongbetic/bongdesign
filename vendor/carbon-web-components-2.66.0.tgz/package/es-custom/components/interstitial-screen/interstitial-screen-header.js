/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import { interstitialContext } from "./interstitial-screen-context.js";
import { registerFocusableContainers } from "../../utilities/manageFocusTrap/manageFocusTrap.js";
import "../progress-indicator/index.js";
import interstitial_screen_header_default$1 from "./interstitial-screen-header.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { consume } from "@lit/context";
//#region src/components/interstitial-screen/interstitial-screen-header.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--interstitial-screen`;
const headerBlockClass = `${blockClass}--internal-header`;
/**
* interstitial-screen-header for header section
* @element cds-custom-interstitial-screen-header
*/
let CDSInterstitialScreenHeader = class CDSInterstitialScreenHeader extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.headerTitle = "";
		this.slot = "header";
		this.headerSubTitle = "";
		this.closeIconDescription = "Close";
		this.hideProgressIndicator = false;
		this.getStepState = (index) => {
			const currentStep = this._interstitialCtx?.state?.currentStep ?? 0;
			if (index === currentStep) return "current";
			if (index < currentStep) return "complete";
			if (index > currentStep) return "incomplete";
			return "invalid";
		};
		this.getElementForAriaLive = () => {
			const currentStep = this._interstitialCtx?.state?.currentStep ?? 0;
			const stepDetails = this._interstitialCtx?.state?.stepDetails ?? [];
			return html`<div
      aria-live="polite"
      aria-atomic="true"
      class="${"cds-custom"}--visually-hidden">
      Step ${currentStep + 1} of ${stepDetails.length}
    </div>`;
		};
	}
	firstUpdated(_changedProperties) {
		registerFocusableContainers(this.shadowRoot);
	}
	/**
	* Handles user-initiated close request of this tearsheet.
	*
	* @param triggeredBy The element that triggered this close request.
	*/
	_handleUserInitiatedClose(triggeredBy) {
		this.dispatchEvent(new CustomEvent(this.constructor.eventRequestClose, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { triggeredBy }
		}));
	}
	getProgressIndicatorContent(stepDetails) {
		return html`
      <div class="${blockClass}--progress">
        <cds-custom-progress-indicator>
          ${stepDetails.map((step, index) => html`<cds-custom-progress-step
                label="${step.stepTitle}"
                key="${step.id}"
                state="${this.getStepState(index)}"></cds-custom-progress-step>`)}
        </cds-custom-progress-indicator>
        ${this.getElementForAriaLive()}
      </div>
    `;
	}
	getTitleContent() {
		return html`<div class="${blockClass}--titleContainer">
      ${this.headerTitle && html`<h1>${this.headerTitle}</h1>`}
      ${this.headerSubTitle && html`<h2>${this.headerSubTitle}</h2>`}
    </div>`;
	}
	getHeaderContent() {
		const stepDetails = this._interstitialCtx?.state?.stepDetails ?? [];
		return html`
      ${this.headerTitle || this.headerSubTitle ? this.getTitleContent() : nothing}
      <slot></slot>
      ${!this.hideProgressIndicator && stepDetails?.length > 0 ? this.getProgressIndicatorContent(stepDetails) : nothing}
    `;
	}
	render() {
		const isFullScreen = this._interstitialCtx?.state?.isFullScreen ?? false;
		const classes = classMap({
			[`${headerBlockClass}`]: true,
			[`${headerBlockClass}--has-title`]: this.headerTitle || this.headerSubTitle
		});
		return isFullScreen ? html`<header class="${classes}">${this.getHeaderContent()}</header>` : html`<cds-custom-modal-header class="${classes}">
          <cds-custom-modal-close-button
            close-button-label=${this.closeIconDescription}
            @click="${(e) => this._handleUserInitiatedClose(e.target)}">
          </cds-custom-modal-close-button>
          ${this.getHeaderContent()}
        </cds-custom-modal-header>`;
	}
	static {
		this.styles = interstitial_screen_header_default$1;
	}
	static get eventRequestClose() {
		return `cds-custom-request-close`;
	}
};
__decorate([property({
	reflect: true,
	attribute: "header-title"
})], CDSInterstitialScreenHeader.prototype, "headerTitle", void 0);
__decorate([property({ reflect: true })], CDSInterstitialScreenHeader.prototype, "slot", void 0);
__decorate([property({
	reflect: true,
	attribute: "header-subtitle"
})], CDSInterstitialScreenHeader.prototype, "headerSubTitle", void 0);
__decorate([property({ reflect: true })], CDSInterstitialScreenHeader.prototype, "closeIconDescription", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSInterstitialScreenHeader.prototype, "hideProgressIndicator", void 0);
__decorate([consume({
	context: interstitialContext,
	subscribe: true
}), state()], CDSInterstitialScreenHeader.prototype, "_interstitialCtx", void 0);
CDSInterstitialScreenHeader = __decorate([carbonElement(`cds-custom-interstitial-screen-header`)], CDSInterstitialScreenHeader);
var interstitial_screen_header_default = CDSInterstitialScreenHeader;
//#endregion
export { interstitial_screen_header_default as default };

//# sourceMappingURL=interstitial-screen-header.js.map