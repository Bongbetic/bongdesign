/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/interstitial-screen/interstitial-screen-context.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const defaultInterstitialState = {
	isFullScreen: false,
	open: false,
	currentStep: 0,
	stepDetails: [],
	disableActions: {}
};
const interstitialContext = createContext(Symbol("interstitial-context"));
//#endregion
export { defaultInterstitialState, interstitialContext };

//# sourceMappingURL=interstitial-screen-context.js.map