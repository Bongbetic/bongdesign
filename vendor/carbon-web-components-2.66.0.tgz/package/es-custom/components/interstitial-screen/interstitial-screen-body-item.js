/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import { interstitialContext } from "./interstitial-screen-context.js";
import { registerFocusableContainers } from "../../utilities/manageFocusTrap/manageFocusTrap.js";
import interstitial_screen_body_item_default$1 from "./interstitial-screen-body-item.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
import { consume } from "@lit/context";
//#region src/components/interstitial-screen/interstitial-screen-body-item.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* interstitial-screen-body-item for body children
* @element cds-custom-interstitial-screen-body-item
*/
let CDSInterstitialScreenBodyItem = class CDSInterstitialScreenBodyItem extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.stepTitle = "";
	}
	firstUpdated(_changedProperties) {
		this.updateStepDetails();
		registerFocusableContainers(this);
	}
	updateStepDetails() {
		const randomId = crypto?.randomUUID();
		const stepKey = `${this.stepTitle?.replace(/\s+/g, "") || randomId}`;
		const newStep = {
			stepTitle: this.stepTitle,
			id: this.id || stepKey
		};
		const currentStepDetails = this._interstitialCtx?.state?.stepDetails ?? [];
		if (!currentStepDetails.some((step) => step.stepTitle === newStep.stepTitle) && newStep.stepTitle) this._interstitialCtx?.setState({ stepDetails: [...currentStepDetails, newStep] });
	}
	render() {
		return html`<slot @slotchange=${this.updateStepDetails}></slot>`;
	}
	static {
		this.styles = interstitial_screen_body_item_default$1;
	}
};
__decorate([property({ reflect: true })], CDSInterstitialScreenBodyItem.prototype, "stepTitle", void 0);
__decorate([consume({
	context: interstitialContext,
	subscribe: true
}), state()], CDSInterstitialScreenBodyItem.prototype, "_interstitialCtx", void 0);
CDSInterstitialScreenBodyItem = __decorate([carbonElement(`cds-custom-interstitial-screen-body-item`)], CDSInterstitialScreenBodyItem);
var interstitial_screen_body_item_default = CDSInterstitialScreenBodyItem;
//#endregion
export { interstitial_screen_body_item_default as default };

//# sourceMappingURL=interstitial-screen-body-item.js.map