/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "./interstitial-screen.js";
import "./interstitial-screen-header.js";
import "./interstitial-screen-body.js";
import "./interstitial-screen-body-item.js";
import "./interstitial-screen-footer.js";
