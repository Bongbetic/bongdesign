/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { isFeatureFlagEnabled } from "../feature-flags/index.js";
import dropdown_item_default from "../dropdown/dropdown-item.js";
import "../checkbox/index.js";
import multi_select_default from "./multi-select.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/multi-select/multi-select-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Multi select item.
*
* @element cds-custom-multi-select-item
*/
let CDSMultiSelectItem = class CDSMultiSelectItem extends dropdown_item_default {
	constructor(..._args) {
		super(..._args);
		this.isSelectAll = false;
		this.indeterminate = false;
		this.selectionName = "";
	}
	render() {
		const { disabled, selected, selectionName, value, indeterminate } = this;
		return html`
      <div class="${"cds-custom"}--list-box__menu-item__option">
        <cds-custom-checkbox
          tabindex="-1"
          class="${"cds-custom"}--form-item ${"cds-custom"}--checkbox-wrapper"
          .checked=${selected}
          .indeterminate=${indeterminate}
          ?disabled=${disabled}
          name=${ifDefined(selectionName || void 0)}
          value=${value}>
          <slot></slot>
        </cds-custom-checkbox>
      </div>
      ${this.isSelectAll && isFeatureFlagEnabled("enable-v12-release", this) ? html`<div
            class="${"cds-custom"}--list-box__menu-divider"
            aria-hidden="true"></div>` : null}
    `;
	}
	/**
	* A selector that will return multi select.
	*/
	static get selectorList() {
		return `cds-custom-multi-select`;
	}
	static {
		this.styles = multi_select_default;
	}
};
__decorate([property({ type: Boolean })], CDSMultiSelectItem.prototype, "filtered", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-select-all",
	reflect: true
})], CDSMultiSelectItem.prototype, "isSelectAll", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSMultiSelectItem.prototype, "indeterminate", void 0);
__decorate([property({ attribute: "selection-name" })], CDSMultiSelectItem.prototype, "selectionName", void 0);
CDSMultiSelectItem = __decorate([carbonElement(`cds-custom-multi-select-item`)], CDSMultiSelectItem);
var multi_select_item_default = CDSMultiSelectItem;
//#endregion
export { multi_select_item_default as default };

//# sourceMappingURL=multi-select-item.js.map