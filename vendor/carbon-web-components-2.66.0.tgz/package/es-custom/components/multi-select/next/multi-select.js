/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import multi_select_default$1 from "../multi-select.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/multi-select/next/multi-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated v3 preview of `cds-custom-multi-select`.
*
* Identical to `cds-custom-multi-select` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* Submits the same joined `value` string the v2 component does, so the
* wire format is unchanged. Emitting one entry per selection would be a
* deliberate API change and is tracked in the migration guide.
*
* @element cds-custom-preview-multi-select
*/
let CDSPreviewMultiSelect = class CDSPreviewMultiSelect extends FormAssociatedMixin(multi_select_default$1) {
	static get is() {
		return `cds-custom-preview-multi-select`;
	}
};
CDSPreviewMultiSelect = __decorate([carbonElement(`cds-custom-preview-multi-select`)], CDSPreviewMultiSelect);
var multi_select_default = CDSPreviewMultiSelect;
//#endregion
export { multi_select_default as default };

//# sourceMappingURL=multi-select.js.map