/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_form_default$1 from "./fluid-form.scss.js";
import { LitElement, html } from "lit";
//#region src/components/fluid-form/fluid-form.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for fluid form
*
* @element cds-custom-fluid-form
*/
let CDSFluidForm = class CDSFluidForm extends LitElement {
	connectedCallback() {
		super.connectedCallback();
		this.toggleAttribute("in-modal", !!this.closest(`cds-custom-modal-body`));
	}
	render() {
		return html`<form class="${"cds-custom"}--form ${"cds-custom"}--form--fluid">
      <slot></slot>
    </form>`;
	}
	static {
		this.styles = fluid_form_default$1;
	}
};
CDSFluidForm = __decorate([carbonElement(`cds-custom-fluid-form`)], CDSFluidForm);
var fluid_form_default = CDSFluidForm;
//#endregion
export { fluid_form_default as default };

//# sourceMappingURL=fluid-form.js.map