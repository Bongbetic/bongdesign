/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import header_nav_item_default from "./header-nav-item.js";
//#region src/components/ui-shell/header-menu-item.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header submenu item.
*
* @element cds-custom-header-menu-item
*/
let CDSHeaderMenuItem = class CDSHeaderMenuItem extends header_nav_item_default {};
CDSHeaderMenuItem = __decorate([carbonElement(`cds-custom-header-menu-item`)], CDSHeaderMenuItem);
var header_menu_item_default = CDSHeaderMenuItem;
//#endregion
export { header_menu_item_default as default };

//# sourceMappingURL=header-menu-item.js.map