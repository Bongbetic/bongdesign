/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import side_nav_default from "./side-nav.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ui-shell/header-side-nav-items.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header Side Nav Items section
*
* @element cds-custom-header-side-nav-items
*/
let CDSHeaderSideNavItems = class CDSHeaderSideNavItems extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hasDivider = false;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = side_nav_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "has-divider"
})], CDSHeaderSideNavItems.prototype, "hasDivider", void 0);
CDSHeaderSideNavItems = __decorate([carbonElement(`cds-custom-header-side-nav-items`)], CDSHeaderSideNavItems);
var header_side_nav_items_default = CDSHeaderSideNavItems;
//#endregion
export { header_side_nav_items_default as default };

//# sourceMappingURL=header-side-nav-items.js.map