/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "./header.js";
import "./header-global-action.js";
import "./header-menu.js";
import "./side-nav.js";
import "./header-menu-button.js";
import "./header-nav-item.js";
import "./header-menu-item.js";
import "./header-name.js";
import "./header-nav.js";
import "./header-side-nav-items.js";
import "./header-panel.js";
import "./side-nav-divider.js";
import "./side-nav-items.js";
import "./side-nav-link.js";
import "./side-nav-menu.js";
import "./side-nav-menu-item.js";
import "./switcher.js";
import "./switcher-item.js";
import "./switcher-divider.js";
