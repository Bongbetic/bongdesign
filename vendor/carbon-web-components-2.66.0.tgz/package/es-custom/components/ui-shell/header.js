/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import header_default$1 from "./header.scss.js";
import { LitElement, html } from "lit";
//#region src/components/ui-shell/header.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header.
*
* @element cds-custom-header
*/
let CDSHeader = class CDSHeader extends LitElement {
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "banner");
		super.connectedCallback();
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = header_default$1;
	}
};
CDSHeader = __decorate([carbonElement(`cds-custom-header`)], CDSHeader);
var header_default = CDSHeader;
//#endregion
export { header_default as default };

//# sourceMappingURL=header.js.map