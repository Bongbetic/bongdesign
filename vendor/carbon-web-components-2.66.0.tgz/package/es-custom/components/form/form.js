/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import form_default$1 from "./form.scss.js";
import { LitElement, html } from "lit";
//#region src/components/form/form.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for form
*
* @element cds-custom-form
*/
let CDSForm = class CDSForm extends LitElement {
	render() {
		return html`<form class="${"cds-custom"}--form">
      <slot></slot>
    </form>`;
	}
	static {
		this.styles = form_default$1;
	}
};
CDSForm = __decorate([carbonElement(`cds-custom-form`)], CDSForm);
var form_default = CDSForm;
//#endregion
export { form_default as default };

//# sourceMappingURL=form.js.map