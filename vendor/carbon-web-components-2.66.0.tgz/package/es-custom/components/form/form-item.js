/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import form_item_default$1 from "./form-item.scss.js";
import { LitElement, html } from "lit";
//#region src/components/form/form-item.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for form items
*
* @element cds-custom-form-item
*/
let CDSFormItem = class CDSFormItem extends LitElement {
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = form_item_default$1;
	}
};
CDSFormItem = __decorate([carbonElement(`cds-custom-form-item`)], CDSFormItem);
var form_item_default = CDSFormItem;
//#endregion
export { form_item_default as default };

//# sourceMappingURL=form-item.js.map