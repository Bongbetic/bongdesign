/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import "./defs.js";
//#region src/components/edit-in-place/edit-in-place-helpers.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = "cds-custom--edit-in-place";
const storyClass = "edit-in-place-example";
const sizes = {
	[`Small (sm)`]: "sm",
	[`Medium (md)`]: "md",
	[`Large (lg)`]: "lg"
};
const tooltipAlignments = {
	[`Top (top)`]: "top",
	[`Top left (top-left)`]: "top-left",
	[`Top right (top-right)`]: "top-right",
	[`Bottom (bottom)`]: "bottom",
	[`Bottom left (bottom-left)`]: "bottom-left",
	[`Bottom right (bottom-right)`]: "bottom-right",
	[`Left (left)`]: "left",
	[`Right (right)`]: "right"
};
const defaultArgs = {
	cancelLabel: "Cancel",
	containerWidth: 300,
	editAlwaysVisible: false,
	editLabel: "Edit",
	id: "story-id",
	inheritTypography: false,
	invalid: false,
	invalidText: "This field is required",
	labelText: "Label text",
	placeholder: "placeholder text",
	readOnly: false,
	readOnlyLabel: "Edit off",
	readOnlyToggleTipText: "This field is read-only and cannot be edited",
	saveLabel: "Save",
	size: "sm",
	toggleTipAlignment: "bottom",
	tooltipAlignment: "top",
	value: "default"
};
//#endregion
export { blockClass, defaultArgs, sizes, storyClass, tooltipAlignments };

//# sourceMappingURL=edit-in-place-helpers.js.map