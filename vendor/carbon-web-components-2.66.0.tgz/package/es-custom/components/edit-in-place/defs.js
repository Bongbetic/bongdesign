/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/edit-in-place/defs.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Edit in place size.
*/
let EDIT_IN_PLACE_SIZE = /* @__PURE__ */ function(EDIT_IN_PLACE_SIZE) {
	EDIT_IN_PLACE_SIZE["SMALL"] = "sm";
	EDIT_IN_PLACE_SIZE["MEDIUM"] = "md";
	EDIT_IN_PLACE_SIZE["LARGE"] = "lg";
	return EDIT_IN_PLACE_SIZE;
}({});
/**
* Tooltip alignment options.
*/
let TOOLTIP_ALIGNMENT = /* @__PURE__ */ function(TOOLTIP_ALIGNMENT) {
	TOOLTIP_ALIGNMENT["TOP"] = "top";
	TOOLTIP_ALIGNMENT["TOP_LEFT"] = "top-left";
	TOOLTIP_ALIGNMENT["TOP_RIGHT"] = "top-right";
	TOOLTIP_ALIGNMENT["BOTTOM"] = "bottom";
	TOOLTIP_ALIGNMENT["BOTTOM_LEFT"] = "bottom-left";
	TOOLTIP_ALIGNMENT["BOTTOM_RIGHT"] = "bottom-right";
	TOOLTIP_ALIGNMENT["LEFT"] = "left";
	TOOLTIP_ALIGNMENT["RIGHT"] = "right";
	return TOOLTIP_ALIGNMENT;
}({});
//#endregion
export { EDIT_IN_PLACE_SIZE, TOOLTIP_ALIGNMENT };

//# sourceMappingURL=defs.js.map