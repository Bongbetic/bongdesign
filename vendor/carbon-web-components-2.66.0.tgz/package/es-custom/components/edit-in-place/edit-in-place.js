/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../tooltip/index.js";
import "../icon-button/index.js";
import { EDIT_IN_PLACE_SIZE, TOOLTIP_ALIGNMENT } from "./defs.js";
import edit_in_place_default$1 from "./edit-in-place.scss.js";
import { LitElement, html } from "lit";
import { property, query, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Close16 from "@carbon/icons/es/close/16";
import Edit16 from "@carbon/icons/es/edit/16";
import EditOff16 from "@carbon/icons/es/edit--off/16";
import Checkmark16 from "@carbon/icons/es/checkmark/16";
import WarningFilled16 from "@carbon/icons/es/warning--filled/16";
//#region src/components/edit-in-place/edit-in-place.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--edit-in-place`;
/**
* EditInPlace component for inline text editing.
*
* @element cds-custom-edit-in-place
* @csspart input - The input element
* @csspart actions - The button container
* @csspart invalid-text - The error message container
* @fires cds-custom-edit-in-place-change - Fired when the input value changes
* @fires cds-custom-edit-in-place-save - Fired when the save button is clicked or Enter is pressed
* @fires cds-custom-edit-in-place-cancel - Fired when the cancel button is clicked or Escape is pressed
* @fires cds-custom-edit-in-place-blur - Fired when the input loses focus (if onBlur handler is used)
*/
let CDSEditInPlace = class CDSEditInPlace extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.cancelLabel = "Cancel";
		this.editAlwaysVisible = false;
		this.editLabel = "Edit";
		this.id = "";
		this.inheritTypography = false;
		this.invalid = false;
		this.invalidText = "";
		this.labelText = "";
		this.placeholder = "";
		this.readOnly = false;
		this.readOnlyLabel = "Edit off";
		this.readOnlyToggleTipText = "This field is read-only and cannot be edited";
		this.saveLabel = "Save";
		this.size = "sm";
		this.toggleTipAlignment = "bottom";
		this.tooltipAlignment = "top";
		this.value = "";
		this.defaultValue = "";
		this._focused = false;
		this._internalValue = "";
		this._initialValue = "";
		this._dirtyInput = false;
		this._escaping = false;
		this._clickingWithin = false;
		this._handleDocumentClick = (e) => {
			if (!this._focused) return;
			if (!e.composedPath().includes(this)) {
				if (this._canSave) this._handleSave(true);
				else this._handleCancel(true);
			}
		};
	}
	/**
	* Check if value has changed from initial
	*/
	get _hasValueChanged() {
		return this._internalValue.trim() !== this._initialValue.trim();
	}
	/**
	* Check if we can save (value changed and not invalid)
	*/
	get _canSave() {
		return this._hasValueChanged && !this.invalid;
	}
	/**
	* Check if we can cancel (value has changed)
	*/
	get _canCancel() {
		return this._hasValueChanged;
	}
	/**
	* Handle input change
	*/
	_handleChange(e) {
		const input = e.target;
		if (!this._dirtyInput) this._dirtyInput = true;
		this._internalValue = input.value;
		this._emitEvent("change", this._internalValue);
	}
	/**
	* Handle focus
	*/
	_handleFocus(e) {
		const relatedTarget = e?.relatedTarget;
		if (e?.target !== this._inputElement && !this.readOnly && !this._focused && !this.contains(relatedTarget ?? null)) requestAnimationFrame(() => {
			this._inputElement?.focus();
		});
		this._focused = true;
	}
	willUpdate(changedProperties) {
		if (changedProperties.has("value")) {
			const value = this.value || this.defaultValue;
			this._internalValue = value;
			this._initialValue = value;
			this._dirtyInput = false;
		}
	}
	_emitEvent(name, value) {
		this.dispatchEvent(new CustomEvent(`cds-custom-edit-in-place-${name}`, {
			bubbles: true,
			composed: true,
			detail: { value }
		}));
	}
	/**
	* Handle save
	*/
	_handleSave(exitEditMode = false) {
		this._initialValue = this._internalValue;
		this._dirtyInput = false;
		this._emitEvent("save", this._internalValue);
		if (exitEditMode) this._focused = false;
		else requestAnimationFrame(() => {
			this._inputElement?.focus();
		});
	}
	/**
	* Handle cancel
	*/
	_handleCancel(exitEditMode = false) {
		this._dirtyInput = false;
		this._internalValue = this._initialValue;
		this._emitEvent("cancel", this._initialValue);
		if (exitEditMode) this._focused = false;
		else requestAnimationFrame(() => {
			if (this._inputElement) {
				this._inputElement.focus();
				const length = this._inputElement.value.length;
				this._inputElement.setSelectionRange(length, length);
			}
		});
	}
	/**
	* Handle blur
	*/
	_handleBlur(e) {
		const relatedTarget = e.relatedTarget;
		const clickedWithin = this._clickingWithin;
		const targetingChild = relatedTarget ? this.contains(relatedTarget) : false;
		if (clickedWithin) {
			this._clickingWithin = false;
			if (targetingChild) return;
		}
		if (!clickedWithin && targetingChild) return;
		if (this._escaping) return;
		if (this._canSave) this._handleSave(true);
		else this._handleCancel(true);
		this._emitEvent("blur", this._initialValue);
	}
	/**
	* Handle keyboard events
	*/
	_handleKeyDown(e) {
		switch (e.key) {
			case "Escape":
				this._escaping = true;
				this._inputElement?.blur();
				this._handleCancel(false);
				this._escaping = false;
				break;
			case "Enter":
				this._escaping = true;
				this._inputElement?.blur();
				if (this._canSave) this._handleSave(false);
				this._escaping = false;
				break;
			case "Tab": if (!e.shiftKey && !this._hasValueChanged) this._handleCancel(true);
		}
	}
	/**
	* Handle toolbar mousedown to track button clicks
	* Uses composedPath() to properly handle Shadow DOM boundaries
	*/
	_handleToolbarMouseDown(e) {
		const foundButton = e.composedPath().find((el) => el instanceof HTMLElement && (el.tagName === "BUTTON" || el.tagName === "CDS-ICON-BUTTON"));
		if (foundButton) {
			this._clickingWithin = true;
			if (foundButton.hasAttribute("disabled") || foundButton.getAttribute("aria-disabled") === "true") e.preventDefault();
		}
	}
	/**
	* Handle keydown on save button to exit edit mode on Tab
	*/
	_handleSaveButtonKeyDown(e) {
		if (e.key === "Tab" && !e.shiftKey) {
			this._focused = false;
			this._inputElement?.blur();
		}
	}
	/**
	* Initialize component
	*/
	connectedCallback() {
		super.connectedCallback();
		const value = this.value || this.defaultValue;
		this._internalValue = value;
		this._initialValue = value;
	}
	/**
	* Cleanup component state when removed from DOM
	*/
	disconnectedCallback() {
		super.disconnectedCallback();
		this._escaping = false;
		this._clickingWithin = false;
		this._focused = false;
	}
	/**
	* Render the input element
	*/
	_renderInput() {
		const inputClasses = {
			[`${blockClass}__text-input`]: true,
			[`cds-custom--text-input`]: true,
			[`cds-custom--text-input--${this.size}`]: true
		};
		const inputElement = html`
      <input
        id=${this.id}
        class=${classMap(inputClasses)}
        type="text"
        part="input"
        placeholder=${this.placeholder}
        .value=${this._internalValue}
        @input=${this._handleChange}
        @focus=${this._handleFocus}
        @keydown=${this._handleKeyDown}
        aria-label=${this.labelText}
        aria-invalid=${this.invalid ? "true" : "false"}
        ?readonly=${this.readOnly} />
    `;
		if (this.readOnly) return html`
        <cds-custom-tooltip
          align=${this.toggleTipAlignment}
          class="${blockClass}__toggletip-wrapper">
          ${inputElement}
          <cds-custom-tooltip-content
            >${this.readOnlyToggleTipText}</cds-custom-tooltip-content
          >
        </cds-custom-tooltip>
      `;
		return inputElement;
	}
	/**
	* Render action buttons
	*/
	_renderActions() {
		if (this.readOnly) return html`
        <cds-custom-icon-button
          class="${blockClass}__btn-readonly"
          size=${this.size}
          align=${this.tooltipAlignment}
          kind="ghost"
          @click=${this._handleFocus}>
          ${iconLoader(EditOff16, { slot: "icon" })}
          <span slot="tooltip-content">${this.readOnlyLabel}</span>
        </cds-custom-icon-button>
      `;
		if (this._focused) return html`
        <cds-custom-icon-button
          class="${blockClass}__btn ${blockClass}__btn-cancel"
          size=${this.size}
          align=${this.tooltipAlignment}
          kind="ghost"
          ?disabled=${!this._canCancel}
          @click=${() => this._handleCancel(false)}>
          ${iconLoader(Close16, { slot: "icon" })}
          <span slot="tooltip-content">${this.cancelLabel}</span>
        </cds-custom-icon-button>
        <cds-custom-icon-button
          class="${blockClass}__btn ${blockClass}__btn-save"
          size=${this.size}
          align=${this.tooltipAlignment}
          kind="ghost"
          ?disabled=${!this._canSave}
          @click=${() => this._handleSave(false)}
          @keydown=${this._handleSaveButtonKeyDown}>
          ${iconLoader(Checkmark16, { slot: "icon" })}
          <span slot="tooltip-content">${this.saveLabel}</span>
        </cds-custom-icon-button>
      `;
		const editBtnClasses = {
			[`${blockClass}__btn`]: true,
			[`${blockClass}__btn-edit`]: true,
			[`${blockClass}__btn-edit--always-visible`]: this.editAlwaysVisible
		};
		return html`
      <cds-custom-icon-button
        class=${classMap(editBtnClasses)}
        size=${this.size}
        align=${this.tooltipAlignment}
        kind="ghost"
        @click=${this._handleFocus}>
        ${iconLoader(Edit16, { slot: "icon" })}
        <span slot="tooltip-content">${this.editLabel}</span>
      </cds-custom-icon-button>
    `;
	}
	render() {
		const containerClasses = {
			[`${blockClass}__container`]: true,
			[`${blockClass}--${this.size}`]: true,
			[`${blockClass}--focused`]: this._focused,
			[`${blockClass}--invalid`]: this.invalid,
			[`${blockClass}--inherit-type`]: this.inheritTypography,
			[`${blockClass}--readonly`]: this.readOnly
		};
		return html`
      <div class=${classMap(containerClasses)} @blur=${this._handleBlur}>
        ${this._renderInput()}
        <div
          class="${blockClass}__toolbar"
          part="actions"
          @mousedown=${this._handleToolbarMouseDown}>
          ${this.invalid ? iconLoader(WarningFilled16, { class: `${blockClass}__warning-icon` }) : ""}
          ${this._renderActions()}
        </div>
      </div>
      ${this.invalid ? html`<p class="${blockClass}__warning-text" part="invalid-text">
            ${this.invalidText}
          </p>` : ""}
    `;
	}
	static {
		this.styles = edit_in_place_default$1;
	}
};
__decorate([property({
	type: String,
	attribute: "cancel-label",
	reflect: true
})], CDSEditInPlace.prototype, "cancelLabel", void 0);
__decorate([property({
	type: Boolean,
	attribute: "edit-always-visible",
	reflect: true
})], CDSEditInPlace.prototype, "editAlwaysVisible", void 0);
__decorate([property({
	type: String,
	attribute: "edit-label",
	reflect: true
})], CDSEditInPlace.prototype, "editLabel", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSEditInPlace.prototype, "id", void 0);
__decorate([property({
	type: Boolean,
	attribute: "inherit-typography",
	reflect: true
})], CDSEditInPlace.prototype, "inheritTypography", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSEditInPlace.prototype, "invalid", void 0);
__decorate([property({
	type: String,
	attribute: "invalid-text",
	reflect: true
})], CDSEditInPlace.prototype, "invalidText", void 0);
__decorate([property({
	type: String,
	attribute: "label-text",
	reflect: true
})], CDSEditInPlace.prototype, "labelText", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSEditInPlace.prototype, "placeholder", void 0);
__decorate([property({
	type: Boolean,
	attribute: "read-only",
	reflect: true
})], CDSEditInPlace.prototype, "readOnly", void 0);
__decorate([property({
	type: String,
	attribute: "read-only-label",
	reflect: true
})], CDSEditInPlace.prototype, "readOnlyLabel", void 0);
__decorate([property({
	type: String,
	attribute: "read-only-toggletip-text",
	reflect: true
})], CDSEditInPlace.prototype, "readOnlyToggleTipText", void 0);
__decorate([property({
	type: String,
	attribute: "save-label",
	reflect: true
})], CDSEditInPlace.prototype, "saveLabel", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSEditInPlace.prototype, "size", void 0);
__decorate([property({
	type: String,
	attribute: "toggletip-alignment",
	reflect: true
})], CDSEditInPlace.prototype, "toggleTipAlignment", void 0);
__decorate([property({
	type: String,
	attribute: "tooltip-alignment",
	reflect: true
})], CDSEditInPlace.prototype, "tooltipAlignment", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSEditInPlace.prototype, "value", void 0);
__decorate([property({
	type: String,
	attribute: "default-value",
	reflect: true
})], CDSEditInPlace.prototype, "defaultValue", void 0);
__decorate([state()], CDSEditInPlace.prototype, "_focused", void 0);
__decorate([state()], CDSEditInPlace.prototype, "_internalValue", void 0);
__decorate([state()], CDSEditInPlace.prototype, "_initialValue", void 0);
__decorate([state()], CDSEditInPlace.prototype, "_dirtyInput", void 0);
__decorate([query("input")], CDSEditInPlace.prototype, "_inputElement", void 0);
__decorate([HostListener("document:click")], CDSEditInPlace.prototype, "_handleDocumentClick", void 0);
CDSEditInPlace = __decorate([carbonElement(`cds-custom-edit-in-place`)], CDSEditInPlace);
var edit_in_place_default = CDSEditInPlace;
//#endregion
export { EDIT_IN_PLACE_SIZE, TOOLTIP_ALIGNMENT, edit_in_place_default as default };

//# sourceMappingURL=edit-in-place.js.map