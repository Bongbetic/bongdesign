/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "./defs.js";
import code_snippet_default from "./code-snippet.scss.js";
import "./code-snippet.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/code-snippet/code-snippet-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of code snippet.
*/
let CDSCodeSnippetSkeleton = class CDSCodeSnippetSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.type = "single";
	}
	render() {
		return html`
      <div class="${"cds-custom"}--snippet-container">
        ${this.type !== "multi" ? html` <span></span> ` : html` <span></span><span></span><span></span> `}
      </div>
    `;
	}
	static {
		this.styles = code_snippet_default;
	}
};
__decorate([property({ reflect: true })], CDSCodeSnippetSkeleton.prototype, "type", void 0);
CDSCodeSnippetSkeleton = __decorate([carbonElement(`cds-custom-code-snippet-skeleton`)], CDSCodeSnippetSkeleton);
var code_snippet_skeleton_default = CDSCodeSnippetSkeleton;
//#endregion
export { code_snippet_skeleton_default as default };

//# sourceMappingURL=code-snippet-skeleton.js.map