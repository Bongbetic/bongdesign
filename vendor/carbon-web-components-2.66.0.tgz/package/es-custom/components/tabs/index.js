/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../tooltip/index.js";
import "./tabs.js";
import "./tab.js";
import "./tabs-skeleton.js";
import "./tab-skeleton.js";
import "../badge-indicator/index.js";
import "./tabs-vertical.js";
