/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import fluid_date_picker_default from "./fluid-date-picker.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Calendar16 from "@carbon/icons/es/calendar/16.js";
//#region src/components/fluid-date-picker/fluid-date-picker-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid date picker skeleton.
*
* @element cds-custom-fluid-date-picker-skeleton
*/
let CDSFluidDatePickerSkeleton = class CDSFluidDatePickerSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.datePickerType = "single";
	}
	_renderContainer(showIcon) {
		return html`
      <div class="${"cds-custom"}--date-picker--fluid__skeleton--container">
        <span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span>
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--text-input"></div>
        ${showIcon ? iconLoader(Calendar16, {
			class: `cds-custom--date-picker__icon`,
			role: "img",
			"aria-hidden": "true"
		}) : null}
      </div>
    `;
	}
	render() {
		const { datePickerType } = this;
		const isRange = datePickerType === "range";
		const showIcon = datePickerType !== "simple";
		const wrapperClasses = classMap({
			[`cds-custom--date-picker--fluid__skeleton`]: true,
			[`cds-custom--date-picker--fluid__skeleton--range`]: isRange
		});
		return html`
      <div class="${wrapperClasses}">
        ${this._renderContainer(showIcon)}
        ${isRange ? this._renderContainer(true) : null}
      </div>
    `;
	}
	static {
		this.styles = [fluid_date_picker_default];
	}
};
__decorate([property({
	reflect: true,
	attribute: "date-picker-type"
})], CDSFluidDatePickerSkeleton.prototype, "datePickerType", void 0);
CDSFluidDatePickerSkeleton = __decorate([carbonElement(`cds-custom-fluid-date-picker-skeleton`)], CDSFluidDatePickerSkeleton);
var fluid_date_picker_skeleton_default = CDSFluidDatePickerSkeleton;
//#endregion
export { fluid_date_picker_skeleton_default as default };

//# sourceMappingURL=fluid-date-picker-skeleton.js.map