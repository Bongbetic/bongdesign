/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { isFeatureFlagEnabled } from "../feature-flags/index.js";
import date_picker_default from "../date-picker/date-picker.js";
import fluid_date_picker_default$1 from "./fluid-date-picker.scss.js";
import { html } from "lit";
//#region src/components/fluid-date-picker/fluid-date-picker.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid date picker.
*
* @element cds-custom-fluid-date-picker
* @fires cds-custom-date-picker-changed - The custom event fired on this element when Flatpickr updates its value.
* @fires cds-custom-date-picker-flatpickr-error
*   The name of the custom event when Flatpickr throws an error.
*/
let CDSFluidDatePicker = class CDSFluidDatePicker extends date_picker_default {
	constructor(..._args) {
		super(..._args);
		this._observer = new MutationObserver(() => this._syncInputState());
	}
	_syncInputState() {
		const input = this.querySelector(`cds-custom-fluid-date-picker-input[kind="simple"]`);
		this.toggleAttribute("data-input-disabled", input?.hasAttribute("disabled") ?? false);
		this.toggleAttribute("data-input-readonly", input?.hasAttribute("readonly") ?? false);
	}
	connectedCallback() {
		super.connectedCallback();
		if (isFeatureFlagEnabled("enable-v12-release", this)) {
			this._syncInputState();
			this._observer.observe(this, {
				attributes: true,
				childList: true,
				subtree: true,
				attributeFilter: ["disabled", "readonly"]
			});
		}
	}
	disconnectedCallback() {
		this._observer.disconnect();
		super.disconnectedCallback();
	}
	render() {
		return html`${super.render()}`;
	}
	static get selectorInputFrom() {
		return `cds-custom-fluid-date-picker-input,cds-custom-fluid-date-picker-input[kind="from"]`;
	}
	static get selectorInputTo() {
		return `cds-custom-fluid-date-picker-input[kind="to"]`;
	}
	static get selectorInputSingle() {
		return `cds-custom-fluid-date-picker-input[kind="single"]`;
	}
	static {
		this.styles = [date_picker_default.styles, fluid_date_picker_default$1];
	}
};
CDSFluidDatePicker = __decorate([carbonElement(`cds-custom-fluid-date-picker`)], CDSFluidDatePicker);
var fluid_date_picker_default = CDSFluidDatePicker;
//#endregion
export { fluid_date_picker_default as default };

//# sourceMappingURL=fluid-date-picker.js.map