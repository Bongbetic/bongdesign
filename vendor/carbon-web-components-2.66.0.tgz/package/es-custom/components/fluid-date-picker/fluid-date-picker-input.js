/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import date_picker_input_default from "../date-picker/date-picker-input.js";
import fluid_date_picker_default from "./fluid-date-picker.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/fluid-date-picker/fluid-date-picker-input.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid date picker input.
*
* @element cds-custom-fluid-date-picker-input
*/
let CDSFluidDatePickerInput = class CDSFluidDatePickerInput extends date_picker_input_default {
	constructor(..._args) {
		super(..._args);
		this.isFluid = true;
	}
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [date_picker_input_default.styles, fluid_date_picker_default];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFluidDatePickerInput.prototype, "warn", void 0);
__decorate([property({ attribute: "warn-text" })], CDSFluidDatePickerInput.prototype, "warnText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFluidDatePickerInput.prototype, "invalid", void 0);
__decorate([property({ attribute: "invalid-text" })], CDSFluidDatePickerInput.prototype, "invalidText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-fluid"
})], CDSFluidDatePickerInput.prototype, "isFluid", void 0);
CDSFluidDatePickerInput = __decorate([carbonElement(`cds-custom-fluid-date-picker-input`)], CDSFluidDatePickerInput);
var fluid_date_picker_input_default = CDSFluidDatePickerInput;
//#endregion
export { fluid_date_picker_input_default as default };

//# sourceMappingURL=fluid-date-picker-input.js.map