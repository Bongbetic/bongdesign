/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../../globals/mixins/host-listener.js";
import "../../button/button.js";
import coachmark_beacon_default$1 from "./coachmark-beacon.scss.js";
import "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/coachmark/coachmark-beacon/coachmark-beacon.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--coachmark-beacon`;
/**
* CoachmarkBeacon.
*
* @element cds-custom-coachmark-beacon
* @fires cds-custom-coachmark-beacon-clicked Custom event fired when beacon is clicked
* */
let CDSCoachmarkBeacon = class CDSCoachmarkBeacon extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.kind = "default";
		this.label = "Show information";
		this.id = crypto.randomUUID();
		this.expanded = false;
		this.handleOutsideClick = (event) => {
			if (!this.contains(event.target)) {
				this.expanded = false;
				document.removeEventListener("click", this.handleOutsideClick);
			}
		};
	}
	firstUpdated() {
		this.classList.add(blockClass);
		if (this.kind) this.classList.add(`${blockClass}-${this.kind}`);
	}
	connectedCallback() {
		super.connectedCallback();
		if (this.expanded) document.addEventListener("click", this.handleOutsideClick);
	}
	_handleClick() {
		this.expanded = !this.expanded;
		if (this.expanded) document.addEventListener("click", this.handleOutsideClick);
		else document.removeEventListener("click", this.handleOutsideClick);
		this.dispatchEvent(new CustomEvent(this.constructor.beaconClicked, {
			detail: { expanded: this.expanded },
			bubbles: true,
			composed: true
		}));
	}
	disconnectedCallback() {
		super.disconnectedCallback();
		document.removeEventListener("click", this.handleOutsideClick);
	}
	render() {
		return html`
      <cds-custom-button
        class="${blockClass}__target"
        type="button"
        id=${this.id}
        aria-expanded="${String(this.expanded)}"
        @click=${this._handleClick}>
        <slot name="icon">
          <svg
            class="${blockClass}__center"
            aria-label=${this.label}
            width="76"
            height="76"
            viewBox="0 0 76 76">
            <title>${this.label}</title>
            <circle r="1" cx="36" cy="36"></circle>
          </svg>
        </slot>
      </cds-custom-button>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static get beaconClicked() {
		return `cds-custom-coachmark-beacon-clicked`;
	}
	static {
		this.styles = coachmark_beacon_default$1;
	}
};
__decorate([property({ reflect: true })], CDSCoachmarkBeacon.prototype, "kind", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCoachmarkBeacon.prototype, "label", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCoachmarkBeacon.prototype, "id", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCoachmarkBeacon.prototype, "expanded", void 0);
CDSCoachmarkBeacon = __decorate([carbonElement(`cds-custom-coachmark-beacon`)], CDSCoachmarkBeacon);
var coachmark_beacon_default = CDSCoachmarkBeacon;
//#endregion
export { coachmark_beacon_default as default };

//# sourceMappingURL=coachmark-beacon.js.map