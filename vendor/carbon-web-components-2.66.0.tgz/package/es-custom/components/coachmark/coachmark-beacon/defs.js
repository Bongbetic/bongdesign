/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/coachmark/coachmark-beacon/defs.ts
/**
* Copyright IBM Corp. 2023, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Reserved for future expansion, i.e. "RING".
*/
let BEACON_KIND = /* @__PURE__ */ function(BEACON_KIND) {
	BEACON_KIND["DEFAULT"] = "default";
	return BEACON_KIND;
}({});
//#endregion
export { BEACON_KIND };

//# sourceMappingURL=defs.js.map