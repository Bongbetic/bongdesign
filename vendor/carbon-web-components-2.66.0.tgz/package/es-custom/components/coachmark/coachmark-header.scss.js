/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/coachmark/coachmark-header.scss?lit
var coachmark_header_default = css([":host(cds-custom-coachmark-header){display:flex;justify-content:flex-end}:host(cds-custom-coachmark-header) .cds-custom--coachmark-header-drag-handle{margin-inline-end:auto}:host(cds-custom-coachmark-header) .cds-custom--coachmark-header-drag-icon{fill:var(--cds-background,#fff)}:host(cds-custom-coachmark-header) .cds-custom--coachmark-header-close-icon{fill:var(--cds-background,#fff)}"]);
//#endregion
export { coachmark_header_default as default };

//# sourceMappingURL=coachmark-header.scss.js.map