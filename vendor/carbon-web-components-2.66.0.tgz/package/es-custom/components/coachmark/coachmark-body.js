/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import coachmark_body_default$1 from "./coachmark-body.scss.js";
import { LitElement, html } from "lit";
//#region src/components/coachmark/coachmark-body.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* coachmark-body for content body
* @element cds-custom-coachmark-body
*/
let CDSCoachmarkBody = class CDSCoachmarkBody extends HostListenerMixin(LitElement) {
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = coachmark_body_default$1;
	}
};
CDSCoachmarkBody = __decorate([carbonElement(`cds-custom-coachmark-body`)], CDSCoachmarkBody);
var coachmark_body_default = CDSCoachmarkBody;
//#endregion
export { coachmark_body_default as default };

//# sourceMappingURL=coachmark-body.js.map