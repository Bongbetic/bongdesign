/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/coachmark/coachmark-context.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const defaultCoachmarkState = { floating: false };
const coachmarkContext = createContext(Symbol("coachmark-context"));
//#endregion
export { coachmarkContext, defaultCoachmarkState };

//# sourceMappingURL=coachmark-context.js.map