/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../../globals/internal/icon-loader.js";
import HostListenerMixin from "../../../globals/mixins/host-listener.js";
import "../../button/button.js";
import coachmark_tagline_default$1 from "./coachmark-tagline.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import Close16 from "@carbon/icons/es/close/16.js";
import Idea16 from "@carbon/icons/es/idea/16.js";
//#region src/components/coachmark/coachmark-tagline/coachmark-tagline.ts
/**
* Copyright IBM Corp. 2026, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--coachmark-tagline`;
/**
* DO NOT USE. This component is for the exclusive use
* of other Onboarding components.
*
* Coachmark tagline component.
*
* @element cds-custom-coachmark-tagline
* @fires cds-custom-coachmark-tagline-close - Custom event fired when close button is clicked
* @fires cds-custom-coachmark-tagline-cta-click - Custom event fired when tagline CTA is clicked
*/
let CDSCoachmarkTagline = class CDSCoachmarkTagline extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.closeIconDescription = "Close";
		this.title = "";
		this.open = false;
	}
	firstUpdated() {
		this.classList.add(blockClass);
	}
	updated(changedProperties) {
		if (changedProperties.has("open")) {
			if (this.open) this.classList.add(`${blockClass}--open`);
			else this.classList.remove(`${blockClass}--open`);
		}
	}
	/**
	* Handles the close button click event.
	*/
	_handleClose() {
		const closeEvent = new CustomEvent(`cds-custom-coachmark-tagline-close`, {
			bubbles: true,
			composed: true,
			detail: {}
		});
		this.dispatchEvent(closeEvent);
	}
	/**
	* Handles the CTA button click event.
	*/
	_handleCtaClick(event) {
		const ctaClickEvent = new CustomEvent(`cds-custom-coachmark-tagline-cta-click`, {
			bubbles: true,
			composed: true,
			detail: { originalEvent: event }
		});
		this.dispatchEvent(ctaClickEvent);
	}
	/**
	* Handles the CTA button double click event.
	*/
	_handleCtaDoubleClick(event) {
		const ctaDoubleClickEvent = new CustomEvent(`cds-custom-coachmark-tagline-cta-dblclick`, {
			bubbles: true,
			composed: true,
			detail: { originalEvent: event }
		});
		this.dispatchEvent(ctaDoubleClickEvent);
	}
	render() {
		return html`
      <button
        class="${blockClass}__cta"
        @click="${this._handleCtaClick}"
        @dblclick="${this._handleCtaDoubleClick}">
        ${iconLoader(Idea16, { slot: "icon" })} ${this.title}
      </button>
      <div class="${blockClass}--close-btn-container">
        <cds-custom-button
          kind="ghost"
          size="sm"
          tooltip-text="${this.closeIconDescription}"
          has-icon-only
          class="${blockClass}--close-btn"
          @click="${this._handleClose}">
          ${iconLoader(Close16, { slot: "icon" })}
        </cds-custom-button>
      </div>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = coachmark_tagline_default$1;
	}
};
__decorate([property({
	type: String,
	attribute: "close-icon-description"
})], CDSCoachmarkTagline.prototype, "closeIconDescription", void 0);
__decorate([property({ type: String })], CDSCoachmarkTagline.prototype, "title", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "open"
})], CDSCoachmarkTagline.prototype, "open", void 0);
CDSCoachmarkTagline = __decorate([carbonElement(`cds-custom-coachmark-tagline`)], CDSCoachmarkTagline);
var coachmark_tagline_default = CDSCoachmarkTagline;
//#endregion
export { coachmark_tagline_default as default };

//# sourceMappingURL=coachmark-tagline.js.map