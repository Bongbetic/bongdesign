/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/coachmark/coachmark-body.scss?lit
var coachmark_body_default = css([":host(cds-custom-coachmark-body){display:block;padding:0 1rem 1rem}"]);
//#endregion
export { coachmark_body_default as default };

//# sourceMappingURL=coachmark-body.scss.js.map