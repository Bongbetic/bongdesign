/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
//#region src/components/coachmark/coachmark-helpers.ts
/**
* Copyright IBM Corp. 2026, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const handleClick = () => {
	document.querySelector(`cds-custom-coachmark`)?.toggleAttribute("open");
};
const handleDone = () => {
	document.querySelector(`cds-custom-coachmark`)?.removeAttribute("open");
};
const handleCoachmarkOpened = () => {
	const isFloating = document.querySelector(`cds-custom-coachmark`)?.hasAttribute("floating") ?? false;
	setTimeout(() => {
		if (isFloating) (document.querySelector(`cds-custom-coachmark-header`)?.shadowRoot?.querySelector(`.cds-custom--coachmark-header-drag-handle`))?.focus();
		else document.querySelector(".coachmark-body cds-custom-button")?.focus();
	}, 100);
};
//#endregion
export { handleClick, handleCoachmarkOpened, handleDone };

//# sourceMappingURL=coachmark-helpers.js.map