/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/coachmark/coachmark.scss?lit
var coachmark_default = css([":host{display:inline-block}.cds-custom--visually-hidden{position:absolute;overflow:hidden;padding:0;border:0;margin:-1px;block-size:1px;clip:rect(0,0,0,0);inline-size:1px;visibility:inherit;white-space:nowrap}.cds-custom--coachmark--popover{position:fixed}.cds-custom--coachmark--popover cds-custom-popover-content.cds-custom--coachmark--is-dragging::part(content){border-radius:0;box-shadow:0 0 0 .125rem var(--cds-icon-inverse,#fff),0 0 0 .25rem var(--cds-background-inverse,#393939)}"]);
//#endregion
export { coachmark_default as default };

//# sourceMappingURL=coachmark.scss.js.map