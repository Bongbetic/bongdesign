/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../button/index.js";
import { coachmarkContext } from "./coachmark-context.js";
import coachmark_header_default$1 from "./coachmark-header.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { consume } from "@lit/context";
import Close16 from "@carbon/icons/es/close/16";
import Draggable from "@carbon/icons/es/draggable/16";
//#region src/components/coachmark/coachmark-header.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* coachmark-header for content header section
* @element cds-custom-coachmark-header
*/
let CDSCoachmarkHeader = class CDSCoachmarkHeader extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.closeIconDescription = "";
		this.dragIconDescription = "";
		this._handleClick = (event) => {
			event.stopPropagation();
			const coachmark = this.closest(`cds-custom-coachmark`);
			if (coachmark) {
				coachmark.dispatchEvent(new CustomEvent(`cds-custom-coachmark-request-close`, {
					bubbles: true,
					composed: true,
					cancelable: true,
					detail: { source: "header-close-button" }
				}));
				coachmark.open = false;
			}
		};
	}
	render() {
		const floating = this._coachmarkCtx?.state?.floating ?? false;
		return html`
      ${floating ? html`
            <cds-custom-button
              kind="ghost"
              size="sm"
              class="${"cds-custom"}--coachmark-header-drag-handle"
              tooltip-text="${this.dragIconDescription}">
              ${iconLoader(Draggable, {
			slot: "icon",
			class: `cds-custom--coachmark-header-drag-icon`
		})}
            </cds-custom-button>
          ` : nothing}
      <slot name="header"></slot>
      <cds-custom-button
        kind="ghost"
        size="sm"
        class="${"cds-custom"}--coachmark-header-close-button"
        tooltip-text="${this.closeIconDescription}"
        @click=${this._handleClick}>
        ${iconLoader(Close16, {
			slot: "icon",
			class: `cds-custom--coachmark-header-close-icon`
		})}
      </cds-custom-button>
    `;
	}
	static {
		this.styles = coachmark_header_default$1;
	}
};
__decorate([property({ reflect: true })], CDSCoachmarkHeader.prototype, "closeIconDescription", void 0);
__decorate([property({ reflect: true })], CDSCoachmarkHeader.prototype, "dragIconDescription", void 0);
__decorate([consume({
	context: coachmarkContext,
	subscribe: true
}), state()], CDSCoachmarkHeader.prototype, "_coachmarkCtx", void 0);
CDSCoachmarkHeader = __decorate([carbonElement(`cds-custom-coachmark-header`)], CDSCoachmarkHeader);
var coachmark_header_default = CDSCoachmarkHeader;
//#endregion
export { coachmark_header_default as default };

//# sourceMappingURL=coachmark-header.js.map