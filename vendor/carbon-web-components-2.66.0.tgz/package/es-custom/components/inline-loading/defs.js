/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/inline-loading/defs.ts
/**
* Copyright IBM Corp. 2020, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Loading state for inline loading spinner.
*/
let INLINE_LOADING_STATE = /* @__PURE__ */ function(INLINE_LOADING_STATE) {
	/**
	* Inactive state.
	*/
	INLINE_LOADING_STATE["INACTIVE"] = "inactive";
	/**
	* State for loading in progress.
	*/
	INLINE_LOADING_STATE["ACTIVE"] = "active";
	/**
	* State for loading successful.
	*/
	INLINE_LOADING_STATE["FINISHED"] = "finished";
	/**
	* State for loading failure.
	*/
	INLINE_LOADING_STATE["ERROR"] = "error";
	return INLINE_LOADING_STATE;
}({});
//#endregion
export { INLINE_LOADING_STATE };

//# sourceMappingURL=defs.js.map