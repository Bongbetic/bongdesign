/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import overflow_menu_default from "../overflow-menu/overflow-menu.scss.js";
import overflow_menu_default$1 from "../overflow-menu/overflow-menu.js";
import { adoptStyles, html } from "lit";
import OverflowMenuHorizontal16 from "@carbon/icons/es/overflow-menu--horizontal/16.js";
//#region src/components/breadcrumb/breadcrumb-overflow-menu.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Overflow menu in breadcrumb.
*
* @deprecated use `cds-custom-overflow-menu` instead with the `breadcrumb` property
*
* @element cds-custom-breadcrumb-overflow-menu
*/
let CDSBreadcrumbOverflowMenu = class CDSBreadcrumbOverflowMenu extends overflow_menu_default$1 {
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [overflow_menu_default, breadcrumb_default]);
	}
	render() {
		return html`
      <slot name="icon">
        ${iconLoader(OverflowMenuHorizontal16, {
			class: `cds-custom--overflow-menu__icon`,
			slot: "icon"
		})}
      </slot>
    `;
	}
};
CDSBreadcrumbOverflowMenu = __decorate([carbonElement(`cds-custom-breadcrumb-overflow-menu`)], CDSBreadcrumbOverflowMenu);
var breadcrumb_overflow_menu_default = CDSBreadcrumbOverflowMenu;
//#endregion
export { breadcrumb_overflow_menu_default as default };

//# sourceMappingURL=breadcrumb-overflow-menu.js.map