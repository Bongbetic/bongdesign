/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import { LitElement, html } from "lit";
//#region src/components/breadcrumb/breadcrumb-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breadcrumb item.
*
* @element cds-custom-breadcrumb-item
*/
let CDSBreadcrumbItem = class CDSBreadcrumbItem extends LitElement {
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		target.assignedNodes().filter((node) => node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() === `cds-custom-overflow-menu`).forEach((item) => {
			const size = this.getAttribute("size");
			if (size) item.setAttribute("breadcrumb-size", size);
			const overflowMenuBody = item.querySelector(`cds-custom-overflow-menu-body`);
			if (overflowMenuBody) overflowMenuBody.menuOffset = {
				top: 10,
				left: 59
			};
		});
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		super.connectedCallback();
	}
	render() {
		return html` <slot @slotchange=${this._handleSlotChange}></slot> `;
	}
	static {
		this.styles = breadcrumb_default;
	}
};
CDSBreadcrumbItem = __decorate([carbonElement(`cds-custom-breadcrumb-item`)], CDSBreadcrumbItem);
var breadcrumb_item_default = CDSBreadcrumbItem;
//#endregion
export { breadcrumb_item_default as default };

//# sourceMappingURL=breadcrumb-item.js.map