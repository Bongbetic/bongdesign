/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import link_default from "../link/link.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/breadcrumb/breadcrumb-link.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Link in breadcrumb.
*
* @element cds-custom-breadcrumb-link
*/
let CDSBreadcrumbLink = class CDSBreadcrumbLink extends link_default {
	constructor(..._args) {
		super(..._args);
		this.isCurrentPage = false;
	}
	render() {
		const { ariaCurrent, isCurrentPage } = this;
		const linkClass = classMap({
			[`cds-custom--link`]: true,
			[`cds-custom--breadcrumb-item--current`]: isCurrentPage && ariaCurrent !== "page"
		});
		return html`
      ${this.href ? super.render() : html`<span
            class="${linkClass}"
            aria-current="${ariaCurrent || isCurrentPage}"
            ><slot></slot
          ></span>`}
    `;
	}
	static {
		this.styles = breadcrumb_default;
	}
};
__decorate([property({
	type: String,
	attribute: "aria-current"
})], CDSBreadcrumbLink.prototype, "ariaCurrent", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-currentpage"
})], CDSBreadcrumbLink.prototype, "isCurrentPage", void 0);
CDSBreadcrumbLink = __decorate([carbonElement(`cds-custom-breadcrumb-link`)], CDSBreadcrumbLink);
var breadcrumb_link_default = CDSBreadcrumbLink;
//#endregion
export { breadcrumb_link_default as default };

//# sourceMappingURL=breadcrumb-link.js.map