/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../icon-button/index.js";
import add_select_item_panel_default$1 from "./add-select-item-panel.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Close16 from "@carbon/icons/es/close/16";
//#region src/components/add-select/add-select-item-panel.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select Item Panel — side panel displaying detailed information about an item.
* CSS modifier `${blockClass}__item-summary-panel--open` is added when `open` is true,
* enabling CSS-driven slide-in/out transitions.
* @element cds-custom-add-select-item-panel
* @slot default - Highest priority: replaces all body rendering when populated
* @slot render-item - Medium priority: receives item for custom rendering
* @fires cds-custom-add-select-item-panel-close - Fired when close icon is clicked
*/
let CDSAddSelectItemPanel = class CDSAddSelectItemPanel extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.title = "Item details";
		this.item = null;
		this.open = false;
		this.closeIconDescription = "Close";
		this.showCloseButton = true;
		this._hasDefaultSlot = false;
		this._hasRenderItemSlot = false;
	}
	_handleClose() {
		this.dispatchEvent(new CustomEvent(this.constructor.eventClose, {
			bubbles: true,
			cancelable: true,
			composed: true
		}));
	}
	_renderDefaultContent() {
		const { item } = this;
		if (!item) return nothing;
		const { itemDetails } = item;
		if (!itemDetails || !Array.isArray(itemDetails) || itemDetails.length === 0) return nothing;
		return html`
      ${itemDetails.map(({ label, value: val }) => html`
          <div class="${blockClass}__item-summary-panel-entry">
            <p class="${blockClass}__item-summary-panel-entry-title">
              ${label}
            </p>
            <p class="${blockClass}__item-summary-panel-entry-body">
              ${String(val)}
            </p>
          </div>
        `)}
    `;
	}
	_handleDefaultSlotChange(e) {
		const slot = e.target;
		this._hasDefaultSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleRenderItemSlotChange(e) {
		const slot = e.target;
		this._hasRenderItemSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	render() {
		const { title, open, closeIconDescription, showCloseButton } = this;
		const panelClasses = classMap({
			[`${blockClass}__item-summary-panel`]: true,
			[`${blockClass}__item-summary-panel--open`]: open
		});
		const showDefault = this._hasDefaultSlot;
		const showRenderItem = !showDefault && this._hasRenderItemSlot;
		const showItemDetails = !showDefault && !showRenderItem;
		return html`
      <div class=${panelClasses}>
        <!-- Header -->
        <div class="${blockClass}__item-summary-panel-header">
          <p class="${blockClass}__item-summary-panel-title">${title}</p>
          ${showCloseButton ? html`
                <cds-custom-icon-button
                  kind="ghost"
                  size="sm"
                  autoalign
                  class="${blockClass}__item-summary-panel-close"
                  @click=${this._handleClose}>
                  ${iconLoader(Close16, { slot: "icon" })}
                  <span slot="tooltip-content">${closeIconDescription}</span>
                </cds-custom-icon-button>
              ` : nothing}
        </div>

        <!-- Body: each slot exists once; wrappers hide/show via display:none -->
        <div class="${blockClass}__item-summary-panel-body">
          <!-- default slot — always in DOM -->
          <div style=${showDefault ? "" : "display:none"}>
            <slot @slotchange=${this._handleDefaultSlotChange}></slot>
          </div>
          <!-- render-item slot — always in DOM -->
          <div style=${showRenderItem ? "" : "display:none"}>
            <slot
              name="render-item"
              @slotchange=${this._handleRenderItemSlotChange}></slot>
          </div>
          <!-- default item details — shown when no slot content -->
          <div style=${showItemDetails ? "" : "display:none"}>
            ${this._renderDefaultContent()}
          </div>
        </div>
      </div>
    `;
	}
	/**
	* The name of the custom event fired when the close icon is clicked.
	*/
	static get eventClose() {
		return `cds-custom-add-select-item-panel-close`;
	}
	static {
		this.styles = add_select_item_panel_default$1;
	}
};
__decorate([property({ type: String })], CDSAddSelectItemPanel.prototype, "title", void 0);
__decorate([property({ attribute: false })], CDSAddSelectItemPanel.prototype, "item", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelectItemPanel.prototype, "open", void 0);
__decorate([property({
	type: String,
	attribute: "close-icon-description"
})], CDSAddSelectItemPanel.prototype, "closeIconDescription", void 0);
__decorate([property({
	type: Boolean,
	attribute: "show-close-button",
	reflect: true
})], CDSAddSelectItemPanel.prototype, "showCloseButton", void 0);
__decorate([state()], CDSAddSelectItemPanel.prototype, "_hasDefaultSlot", void 0);
__decorate([state()], CDSAddSelectItemPanel.prototype, "_hasRenderItemSlot", void 0);
CDSAddSelectItemPanel = __decorate([carbonElement(`cds-custom-add-select-item-panel`)], CDSAddSelectItemPanel);
var add_select_item_panel_default = CDSAddSelectItemPanel;
//#endregion
export { add_select_item_panel_default as default };

//# sourceMappingURL=add-select-item-panel.js.map