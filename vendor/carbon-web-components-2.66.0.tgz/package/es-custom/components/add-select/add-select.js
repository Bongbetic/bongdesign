/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import add_select_default$1 from "./add-select.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/add-select/add-select.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select wrapper component - provides context for child components
* @element cds-custom-add-select
* @slot default - The main content area containing cds-custom-add-select-body
*/
let CDSAddSelect = class CDSAddSelect extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.multi = false;
	}
	render() {
		return html`
      <div class="${blockClass}">
        <slot></slot>
      </div>
    `;
	}
	static {
		this.styles = add_select_default$1;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelect.prototype, "multi", void 0);
CDSAddSelect = __decorate([carbonElement(`cds-custom-add-select`)], CDSAddSelect);
var add_select_default = CDSAddSelect;
//#endregion
export { add_select_default as default };

//# sourceMappingURL=add-select.js.map