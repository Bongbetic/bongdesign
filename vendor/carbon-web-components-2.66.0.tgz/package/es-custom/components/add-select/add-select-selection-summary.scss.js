/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/add-select/add-select-selection-summary.scss?lit
var add_select_selection_summary_default = css([":host(cds-custom-add-select-selection-summary){display:block}:host(cds-custom-add-select-selection-summary) .cds-custom--add-select__next__selection-summary{display:flex;flex-direction:column;block-size:100%}:host(cds-custom-add-select-selection-summary) .cds-custom--add-select__next__selection-summary-header{display:flex;align-items:center;padding:.75rem 1rem;border-block-end:1px solid var(--cds-border-subtle-01,#c6c6c6);gap:.5rem}:host(cds-custom-add-select-selection-summary) .cds-custom--add-select__next__selection-summary-title{font-size:var(--cds-heading-compact-01-font-size,.875rem);font-weight:var(--cds-heading-compact-01-font-weight,600);line-height:var(--cds-heading-compact-01-line-height,1.28572);letter-spacing:var(--cds-heading-compact-01-letter-spacing,.16px);margin:0;color:var(--cds-text-primary,#161616);margin-inline-end:.5rem}:host(cds-custom-add-select-selection-summary) .cds-custom--add-select__next__selection-summary-header-actions{display:flex;align-items:center;gap:.25rem;margin-inline-start:auto}:host(cds-custom-add-select-selection-summary) .cds-custom--add-select__next__selection-summary-body{overflow:visible;flex:1;min-block-size:0}"]);
//#endregion
export { add_select_selection_summary_default as default };

//# sourceMappingURL=add-select-selection-summary.scss.js.map