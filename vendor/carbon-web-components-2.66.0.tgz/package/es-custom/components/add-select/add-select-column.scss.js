/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/add-select/add-select-column.scss?lit
var add_select_column_default = css([":host(cds-custom-add-select-column){display:block}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column{display:flex;flex-direction:column;block-size:100%;border-inline-end:1px solid var(--cds-border-subtle-01,#c6c6c6);min-inline-size:300px;padding-block:1rem;padding-inline:1rem}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__search{padding:0}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__search--with-actions{display:flex;align-items:flex-end}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__search-input{flex:1}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__actions{display:flex;align-items:flex-end}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__header{display:flex;align-items:center;padding:1rem;border-block-end:1px solid var(--cds-border-subtle-01,#c6c6c6)}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__title-wrapper{display:flex;align-items:center;gap:.5rem}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__title{font-size:var(--cds-heading-compact-01-font-size,.875rem);font-weight:var(--cds-heading-compact-01-font-weight,600);line-height:var(--cds-heading-compact-01-line-height,1.28572);letter-spacing:var(--cds-heading-compact-01-letter-spacing,.16px);margin-inline-end:.5rem}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__select-all::part(label){display:flex;align-items:center;gap:.5rem}:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__rows{flex:1;overflow-x:clip;overflow-y:auto}@supports (overflow-block:auto){:host(cds-custom-add-select-column) .cds-custom--add-select__next-column__rows{overflow-block:auto;overflow-inline:clip}}"]);
//#endregion
export { add_select_column_default as default };

//# sourceMappingURL=add-select-column.scss.js.map