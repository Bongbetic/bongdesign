/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../skeleton-text/index.js";
import "../checkbox/index.js";
import "../radio-button/index.js";
import "../icon-button/index.js";
import "../skeleton-icon/index.js";
import add_select_row_default$1 from "./add-select-row.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import ChevronRight16 from "@carbon/icons/es/chevron--right/16";
import View16 from "@carbon/icons/es/view/16";
//#region src/components/add-select/add-select-row.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next-row`;
/**
* Add Select Row component - represents a single selectable row
* @element cds-custom-add-select-row
* @slot default - Custom content to render after the title/subtitle section.
* @slot icon - Optional icon slot
* @slot meta - Optional metadata slot
* @fires cds-custom-add-select-row-select - Fired when row is selected/deselected
* @fires cds-custom-add-select-row-navigate - Fired when navigating to children
* @fires cds-custom-add-select-row-item-panel-click - Fired when the item panel icon button is clicked
*/
let CDSAddSelectRow = class CDSAddSelectRow extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._columnMulti = false;
		this.itemId = "";
		this.title = "";
		this.subtitle = "";
		this.value = "";
		this.selected = false;
		this.indeterminate = false;
		this.disabled = false;
		this.skeleton = false;
		this._hasIconSlot = false;
		this._hasRowContentSlot = false;
		this.hasItemPanel = false;
		this.itemPanelOpen = false;
		this.itemPanelIconDescription = "View details";
		this.hasChildren = false;
		this.parentId = "";
	}
	get _multi() {
		if (this.hasAttribute("_column-multi")) return this._columnMulti;
		return this.closest(`cds-custom-add-select`)?.multi ?? false;
	}
	_handleIconSlotChange(e) {
		const slot = e.target;
		this._hasIconSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleRowContentSlotChange(e) {
		const slot = e.target;
		this._hasRowContentSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	/**
	* Handle item panel icon button click
	*/
	_handleItemPanelClick(event) {
		event.stopPropagation();
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { itemId: this.itemId }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventItemPanelClick, init));
	}
	/**
	* Handle navigation to children
	*/
	_handleNavigate(event) {
		event.stopPropagation();
		if (!this.hasChildren) return;
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: {
				itemId: this.itemId,
				title: this.title,
				parentId: this.parentId
			}
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventNavigate, init));
	}
	/**
	* Handle selection change from checkbox/radio button
	*/
	_handleSelect(event) {
		if (this.disabled) {
			event.preventDefault();
			return;
		}
		const target = event.target;
		this.selected = target.checked || false;
		this._emitSelectionEvent();
	}
	/**
	* Emit selection event
	*/
	_emitSelectionEvent() {
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: {
				itemId: this.itemId,
				selected: this.selected,
				value: this.value
			}
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventSelect, init));
	}
	render() {
		const { itemId, title, subtitle, selected, indeterminate, disabled, hasChildren, hasItemPanel, itemPanelOpen, itemPanelIconDescription, skeleton, _handleSelect: handleSelect } = this;
		const rowClasses = classMap({
			[`${blockClass}`]: true,
			[`${blockClass}--selected`]: selected,
			[`${blockClass}--disabled`]: disabled,
			[`${blockClass}--skeleton`]: skeleton
		});
		if (skeleton) return html`
        <div class=${rowClasses} aria-hidden="true">
          <div class="${blockClass}__cell">
            <div class="${blockClass}__cell-wrapper">
              <div class="${blockClass}__skeleton-control"></div>
              <div class="${blockClass}__content">
                <!-- Hidden slot kept so slotchange fires and _hasIconSlot is accurate -->
                <slot
                  name="icon"
                  style="display:none"
                  @slotchange=${this._handleIconSlotChange}></slot>
                ${this._hasIconSlot ? html`
                      <div class="${blockClass}__icon">
                        <cds-custom-skeleton-icon></cds-custom-skeleton-icon>
                      </div>
                    ` : nothing}
                <div class="${blockClass}__text">
                  <cds-custom-skeleton-text
                    class="${blockClass}__skeleton-title"></cds-custom-skeleton-text>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
		return html`
      <div
        class=${rowClasses}
        role="row"
        aria-selected=${selected}
        tabindex="-1"
        ?data-has-children=${hasChildren}>
        <div class="${blockClass}__cell" role="gridcell">
          <div class="${blockClass}__cell-wrapper">
            ${this._multi ? html`
                  <cds-custom-checkbox
                    class="${blockClass}__checkbox"
                    ?checked=${selected}
                    ?indeterminate=${indeterminate}
                    ?disabled=${disabled}
                    @cds-custom-checkbox-changed=${handleSelect}
                    label-text=${title}
                    ?hide-label=${true}
                    tabindex="-1"></cds-custom-checkbox>
                ` : html`
                  <cds-custom-radio-button
                    class="${blockClass}__radio"
                    ?checked=${selected}
                    ?disabled=${disabled}
                    @cds-custom-radio-button-changed=${handleSelect}
                    label-text=" "
                    aria-label=${title}
                    value=${itemId}
                    tabindex="-1"></cds-custom-radio-button>
                `}

            <div class="${blockClass}__content">
              <slot
                name="icon"
                class="${blockClass}__icon"
                @slotchange=${this._handleIconSlotChange}></slot>
              ${this._hasRowContentSlot ? nothing : html`
                    <div class="${blockClass}__text">
                      <div class="${blockClass}__title">${title}</div>
                      ${subtitle ? html`<div class="${blockClass}__subtitle">
                            ${subtitle}
                          </div>` : nothing}
                    </div>
                    <slot></slot>
                  `}
              <slot
                name="row-content"
                @slotchange=${this._handleRowContentSlotChange}></slot>
              <slot name="meta"></slot>
            </div>

            ${hasItemPanel ? html`
                  <cds-custom-icon-button
                    class="${blockClass}__view-item-panel"
                    kind="ghost"
                    size="sm"
                    autoalign
                    ?aria-pressed=${itemPanelOpen}
                    @click=${this._handleItemPanelClick}>
                    ${iconLoader(View16, { slot: "icon" })}
                    <span slot="tooltip-content"
                      >${itemPanelIconDescription}</span
                    >
                  </cds-custom-icon-button>
                ` : nothing}
            ${hasChildren ? html`
                  <div
                    class="${blockClass}__nav-indicator"
                    @click=${this._handleNavigate}
                    role="button"
                    tabindex="-1"
                    aria-label="Navigate into ${title}">
                    <slot name="nav-icon">
                      ${iconLoader(ChevronRight16, { slot: "icon" })}
                    </slot>
                  </div>
                ` : nothing}
          </div>
        </div>
      </div>
    `;
	}
	/**
	* The name of the custom event fired when row is selected/deselected
	*/
	static get eventSelect() {
		return `cds-custom-add-select-row-select`;
	}
	/**
	* The name of the custom event fired when navigating to children
	*/
	static get eventNavigate() {
		return `cds-custom-add-select-row-navigate`;
	}
	/**
	* The name of the custom event fired when item panel icon button is clicked
	*/
	static get eventItemPanelClick() {
		return `cds-custom-add-select-row-item-panel-click`;
	}
	static {
		this.styles = add_select_row_default$1;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "_column-multi",
	reflect: true
})], CDSAddSelectRow.prototype, "_columnMulti", void 0);
__decorate([property({
	type: String,
	attribute: "item-id"
})], CDSAddSelectRow.prototype, "itemId", void 0);
__decorate([property({ type: String })], CDSAddSelectRow.prototype, "title", void 0);
__decorate([property({ type: String })], CDSAddSelectRow.prototype, "subtitle", void 0);
__decorate([property({ type: String })], CDSAddSelectRow.prototype, "value", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelectRow.prototype, "selected", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelectRow.prototype, "indeterminate", void 0);
__decorate([property({ type: Boolean })], CDSAddSelectRow.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelectRow.prototype, "skeleton", void 0);
__decorate([state()], CDSAddSelectRow.prototype, "_hasIconSlot", void 0);
__decorate([state()], CDSAddSelectRow.prototype, "_hasRowContentSlot", void 0);
__decorate([property({
	type: Boolean,
	attribute: "has-item-panel"
})], CDSAddSelectRow.prototype, "hasItemPanel", void 0);
__decorate([property({
	type: Boolean,
	attribute: "item-panel-open",
	reflect: true
})], CDSAddSelectRow.prototype, "itemPanelOpen", void 0);
__decorate([property({
	type: String,
	attribute: "item-panel-icon-description"
})], CDSAddSelectRow.prototype, "itemPanelIconDescription", void 0);
__decorate([property({
	type: Boolean,
	attribute: "has-children"
})], CDSAddSelectRow.prototype, "hasChildren", void 0);
__decorate([property({
	type: String,
	attribute: "parent-id"
})], CDSAddSelectRow.prototype, "parentId", void 0);
CDSAddSelectRow = __decorate([carbonElement(`cds-custom-add-select-row`)], CDSAddSelectRow);
var add_select_row_default = CDSAddSelectRow;
//#endregion
export { add_select_row_default as default };

//# sourceMappingURL=add-select-row.js.map