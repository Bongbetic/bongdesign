/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/add-select/add-select-body.scss?lit
var add_select_body_default = css([":host(cds-custom-add-select-body){display:block;block-size:100%}:host(cds-custom-add-select-body) .cds-custom--add-select__next__body{display:flex;flex-direction:column;block-size:100%;inline-size:100%}:host(cds-custom-add-select-body) .cds-custom--add-select__next__header{padding:1rem;border-block-end:1px solid var(--cds-border-subtle-01,#c6c6c6)}:host(cds-custom-add-select-body) .cds-custom--add-select__next__header--custom .cds-custom--add-select__next__search,:host(cds-custom-add-select-body) .cds-custom--add-select__next__header--custom .cds-custom--add-select__next__sub-header{display:none}:host(cds-custom-add-select-body) .cds-custom--add-select__next__search--with-actions{display:flex;align-items:flex-end;margin-block-end:1rem}:host(cds-custom-add-select-body) .cds-custom--add-select__next__search-input{flex:1}:host(cds-custom-add-select-body) .cds-custom--add-select__next__global-actions{display:flex;align-items:flex-end}:host(cds-custom-add-select-body) .cds-custom--add-select__next__sub-header{display:flex;align-items:center;justify-content:space-between}:host(cds-custom-add-select-body) .cds-custom--add-select__next__tags{display:flex;align-items:center;gap:.5rem}:host(cds-custom-add-select-body) .cds-custom--add-select__next__tags-label{font-size:var(--cds-heading-compact-02-font-size,1rem);font-weight:var(--cds-heading-compact-02-font-weight,600);line-height:var(--cds-heading-compact-02-line-height,1.375);letter-spacing:var(--cds-heading-compact-02-letter-spacing,0);margin:0;color:var(--cds-text-primary,#161616)}:host(cds-custom-add-select-body) .cds-custom--add-select__next__sub-header-actions{display:flex;align-items:center;gap:.5rem;margin-inline-start:1rem}:host(cds-custom-add-select-body) .cds-custom--add-select__next__content{display:flex;overflow:auto;flex:1;flex-direction:column;min-block-size:0}:host(cds-custom-add-select-body) .cds-custom--add-select__next-list-body{display:flex;flex-direction:column;overflow-x:clip;overflow-y:auto}:host(cds-custom-add-select-body) .cds-custom--add-select__next-list-body--horizontal{overflow:visible;flex-direction:row;align-items:stretch;block-size:100%}"]);
//#endregion
export { add_select_body_default as default };

//# sourceMappingURL=add-select-body.scss.js.map