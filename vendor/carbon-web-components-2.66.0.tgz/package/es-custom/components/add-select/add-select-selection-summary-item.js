/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../icon-button/index.js";
import add_select_selection_summary_item_default$1 from "./add-select-selection-summary-item.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import ChevronRight16 from "@carbon/icons/es/chevron--right/16";
import SubtractAlt16 from "@carbon/icons/es/subtract--alt/16";
//#region src/components/add-select/add-select-selection-summary-item.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select Selection Summary Item — individual selected item display.
* @element cds-custom-add-select-selection-summary-item
* @slot default - Highest priority: replaces all rendering when populated
* @slot render-item - Custom full-row renderer; replaces title/subtitle/body but keeps remove button
* @slot accordion-title - Custom accordion title (used when use-accordion is true)
* @slot accordion-body - Custom accordion body (used when use-accordion is true)
* @fires cds-custom-add-select-selection-summary-item-remove - Fired when remove button clicked; detail: { itemId }
*/
let CDSAddSelectSelectionSummaryItem = class CDSAddSelectSelectionSummaryItem extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.item = null;
		this.useAccordion = false;
		this.removeButtonLabel = "Remove item";
		this.hideRemoveButton = false;
		this._hasDefaultSlot = false;
		this._hasRenderItemSlot = false;
		this._hasAccordionTitleSlot = false;
		this._hasAccordionBodySlot = false;
		this._accordionOpen = false;
	}
	_handleDefaultSlotChange(e) {
		const slot = e.target;
		this._hasDefaultSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleAccordionTitleSlotChange(e) {
		const slot = e.target;
		this._hasAccordionTitleSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleAccordionBodySlotChange(e) {
		const slot = e.target;
		this._hasAccordionBodySlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleRenderItemSlotChange(e) {
		const slot = e.target;
		this._hasRenderItemSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleRemove() {
		if (!this.item) return;
		this.dispatchEvent(new CustomEvent(this.constructor.eventRemove, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { itemId: this.item.id }
		}));
	}
	_renderDefaultItemDetails() {
		const { item } = this;
		if (!item?.itemDetails || !Array.isArray(item.itemDetails)) return nothing;
		if (item.itemDetails.length === 0) return nothing;
		return html`
      ${item.itemDetails.map(({ label, value: val }) => html`
          <div class="${blockClass}__selection-summary-item-entry">
            <p class="${blockClass}__selection-summary-item-header">${label}</p>
            <p class="${blockClass}__selection-summary-item-body">
              ${String(val)}
            </p>
          </div>
        `)}
    `;
	}
	_renderRemoveButton() {
		if (this.hideRemoveButton) return nothing;
		return html`
      <div
        class="${blockClass}__selection-summary-item-remove-button-container">
        <cds-custom-icon-button
          kind="ghost"
          size="sm"
          autoalign
          class="${blockClass}__selection-summary-item-remove-button"
          @click=${(e) => {
			e.stopPropagation();
			this._handleRemove();
		}}>
          ${iconLoader(SubtractAlt16, { slot: "icon" })}
          <span slot="tooltip-content">${this.removeButtonLabel}</span>
        </cds-custom-icon-button>
      </div>
    `;
	}
	render() {
		const { item, useAccordion } = this;
		const itemClasses = classMap({
			[`${blockClass}__selection-summary-item`]: true,
			[`${blockClass}__selection-summary-item--accordion`]: useAccordion,
			[`${blockClass}__selection-summary-item--default`]: !useAccordion
		});
		const defaultTitle = item ? html`
          <div class="${blockClass}__selection-summary-item-selected-item">
            <p class="${blockClass}__selection-summary-item-title">
              ${item.title}
            </p>
            ${item.subtitle ? html`<p class="${blockClass}__selection-summary-item-subtitle">
                  ${item.subtitle}
                </p>` : nothing}
          </div>
        ` : nothing;
		const showDefault = this._hasDefaultSlot;
		const showRenderItem = !showDefault && this._hasRenderItemSlot;
		const showAccordion = !showDefault && !showRenderItem && useAccordion;
		const showPlain = !showDefault && !showRenderItem && !useAccordion;
		return html`
      <div class=${itemClasses}>
        <!-- Default slot — hidden wrapper, always present for detection -->
        <div style=${showDefault ? "" : "display:none"}>
          <slot @slotchange=${this._handleDefaultSlotChange}></slot>
        </div>

        <!-- render-item slot — slot content owns full width; remove button is absolute -->
        <div
          class="${blockClass}__selection-summary-item-render-item-wrapper"
          style=${showRenderItem ? "" : "display:none"}>
          <slot
            name="render-item"
            @slotchange=${this._handleRenderItemSlotChange}></slot>
          ${showRenderItem ? this._renderRemoveButton() : nothing}
        </div>

        <!-- accordion mode wrapper — always rendered when useAccordion, hidden otherwise -->
        <div style=${showAccordion ? "" : "display:none"}>
          <div class="${blockClass}__selection-summary-item-accordion">
            <!--
              The heading row is a flex container that holds the <button> and the
              remove button as siblings. The remove button must NOT be inside the
              <button> — nesting interactive content within <button> violates the
              HTML interactive content model and ARIA authoring practices.
              This mirrors the React implementation which uses renderToggle for
              the same reason (see AddSelectSelectionSummaryItem.tsx).
            -->
            <div
              class="${blockClass}__selection-summary-item-accordion-heading-row">
              <button
                type="button"
                class="${blockClass}__selection-summary-item-accordion-heading"
                aria-expanded=${this._accordionOpen}
                @click=${() => {
			this._accordionOpen = !this._accordionOpen;
		}}>
                <span
                  class="${blockClass}__selection-summary-item-accordion-arrow ${this._accordionOpen ? `${blockClass}__selection-summary-item-accordion-arrow--open` : ""}">
                  ${iconLoader(ChevronRight16, {})}
                </span>

                <span
                  class="${blockClass}__selection-summary-item-accordion-title"
                  style=${this._hasAccordionTitleSlot ? "display:none" : ""}>
                  ${defaultTitle}
                </span>
                <span
                  class="${blockClass}__selection-summary-item-accordion-title ${blockClass}__selection-summary-item-accordion-title--slot"
                  style=${this._hasAccordionTitleSlot ? "" : "display:none"}>
                  <slot
                    name="accordion-title"
                    @slotchange=${this._handleAccordionTitleSlotChange}></slot>
                </span>
              </button>
              ${this._renderRemoveButton()}
            </div>

            <!-- accordion-body: shown only when open -->
            <div
              class="${blockClass}__selection-summary-item-accordion-body"
              style=${this._accordionOpen ? "" : "display:none"}>
              <div style=${this._hasAccordionBodySlot ? "display:none" : ""}>
                ${this._renderDefaultItemDetails()}
              </div>
              <div style=${this._hasAccordionBodySlot ? "" : "display:none"}>
                <slot
                  name="accordion-body"
                  @slotchange=${this._handleAccordionBodySlotChange}></slot>
              </div>
            </div>
          </div>
        </div>

        <!-- plain (non-accordion) mode -->
        ${showPlain ? html`
              <div class="${blockClass}__selection-summary-item-title-wrapper">
                ${defaultTitle} ${this._renderRemoveButton()}
              </div>
              <div class="${blockClass}__selection-summary-item-content">
                ${this._renderDefaultItemDetails()}
              </div>
            ` : nothing}
      </div>
    `;
	}
	/**
	* The name of the custom event fired when the remove button is clicked.
	* detail: { itemId: string }
	*/
	static get eventRemove() {
		return `cds-custom-add-select-selection-summary-item-remove`;
	}
	static {
		this.styles = add_select_selection_summary_item_default$1;
	}
};
__decorate([property({ attribute: false })], CDSAddSelectSelectionSummaryItem.prototype, "item", void 0);
__decorate([property({
	type: Boolean,
	attribute: "use-accordion",
	reflect: true
})], CDSAddSelectSelectionSummaryItem.prototype, "useAccordion", void 0);
__decorate([property({
	type: String,
	attribute: "remove-button-label"
})], CDSAddSelectSelectionSummaryItem.prototype, "removeButtonLabel", void 0);
__decorate([property({
	type: Boolean,
	attribute: "hide-remove-button"
})], CDSAddSelectSelectionSummaryItem.prototype, "hideRemoveButton", void 0);
__decorate([state()], CDSAddSelectSelectionSummaryItem.prototype, "_hasDefaultSlot", void 0);
__decorate([state()], CDSAddSelectSelectionSummaryItem.prototype, "_hasRenderItemSlot", void 0);
__decorate([state()], CDSAddSelectSelectionSummaryItem.prototype, "_hasAccordionTitleSlot", void 0);
__decorate([state()], CDSAddSelectSelectionSummaryItem.prototype, "_hasAccordionBodySlot", void 0);
__decorate([state()], CDSAddSelectSelectionSummaryItem.prototype, "_accordionOpen", void 0);
CDSAddSelectSelectionSummaryItem = __decorate([carbonElement(`cds-custom-add-select-selection-summary-item`)], CDSAddSelectSelectionSummaryItem);
var add_select_selection_summary_item_default = CDSAddSelectSelectionSummaryItem;
//#endregion
export { add_select_selection_summary_item_default as default };

//# sourceMappingURL=add-select-selection-summary-item.js.map