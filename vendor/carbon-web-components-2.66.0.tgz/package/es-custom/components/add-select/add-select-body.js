/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../button/index.js";
import "../search/index.js";
import "../tag/index.js";
import "../breadcrumb/index.js";
import "../link/index.js";
import add_select_body_default$1 from "./add-select-body.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
//#region src/components/add-select/add-select-body.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select Body component - contains the main content area
* @element cds-custom-add-select-body
* @slot default - The main content area containing cds-custom-add-select-column or rows
* @slot header - Replaces the entire header section
* @slot actions - Custom actions (filter/sort) rendered next to the search input
* @slot sub-header-actions - Custom content rendered after breadcrumbs and item count
* @fires cds-custom-add-select-body-search - Fired when search term changes; detail: { searchTerm }
* @fires cds-custom-add-select-body-breadcrumb-click - Fired when a breadcrumb link is clicked; detail: { index }
*/
let CDSAddSelectBody = class CDSAddSelectBody extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.itemsLabel = "";
		this.globalSearchLabel = "";
		this.globalSearchPlaceholder = "Search";
		this.searchResultsTitle = "Search results";
		this._searchTerm = "";
		this.itemCount = void 0;
		this.hideSearch = false;
		this.layout = "vertical";
		this.path = [];
		this._hasHeaderSlot = false;
		this._focusedRowIndex = 0;
		this._gridEl = null;
		this._handleGridKeydown = (event) => {
			const rows = this._getRowHosts();
			if (rows.length === 0) return;
			let handled = false;
			const currentRow = rows[this._focusedRowIndex];
			switch (event.key) {
				case "ArrowDown":
					event.preventDefault();
					this._updateRowFocus(this._focusedRowIndex + 1);
					handled = true;
					break;
				case "ArrowUp":
					event.preventDefault();
					this._updateRowFocus(this._focusedRowIndex - 1);
					handled = true;
					break;
				case "ArrowRight":
					if (currentRow && currentRow.hasAttribute("has-children")) {
						event.preventDefault();
						(currentRow.shadowRoot?.querySelector("[class*=\"nav-indicator\"]"))?.click();
						handled = true;
					}
					break;
				case "Enter":
				case " ":
					event.preventDefault();
					if (currentRow) ((currentRow.shadowRoot?.querySelector(`cds-custom-checkbox, cds-custom-radio-button`))?.shadowRoot?.querySelector("input[type=\"checkbox\"], input[type=\"radio\"]"))?.click();
					handled = true;
					break;
				case "Home":
					if (event.ctrlKey) {
						event.preventDefault();
						this._updateRowFocus(0);
						handled = true;
					}
					break;
				case "End": if (event.ctrlKey) {
					event.preventDefault();
					this._updateRowFocus(rows.length - 1);
					handled = true;
				}
			}
			if (handled) event.stopPropagation();
		};
		this._handleContentSlotChange = () => {
			this._focusedRowIndex = 0;
			this._updateRowFocus(0, false);
		};
	}
	/**
	* Handle search input
	*/
	_handleSearch(event) {
		this._searchTerm = event.detail.value || "";
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { searchTerm: this._searchTerm }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventSearch, init));
	}
	_handleHeaderSlotChange(e) {
		const slot = e.target;
		this._hasHeaderSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	/**
	* Returns all cds-custom-add-select-row host elements in document order.
	* These are in the light DOM of this element, so querySelectorAll finds them.
	*/
	_getRowHosts() {
		return Array.from(this.querySelectorAll(`cds-custom-add-select-row`));
	}
	/**
	* Mirrors React's updateItemFocus:
	* - Sets tabindex="0" on the target row host so it is the Tab stop inside
	*   the grid (Tab into grid → focused row, Tab out → next element after grid).
	* - Sets tabindex="-1" on all other row hosts.
	* - Calls .focus() on the target row host when shouldFocus is true.
	*
	* We set tabindex on the cds-custom-add-select-row host elements (light DOM) rather
	* than their inner shadow divs because host elements are real browser Tab
	* stops; shadow-internal elements are not reachable by Tab from outside.
	*/
	_updateRowFocus(targetIndex, shouldFocus = true) {
		const rows = this._getRowHosts();
		if (rows.length === 0) return;
		this._focusedRowIndex = Math.max(0, Math.min(targetIndex, rows.length - 1));
		rows.forEach((row, idx) => {
			if (idx === this._focusedRowIndex) {
				row.setAttribute("tabindex", "0");
				if (shouldFocus) row.focus();
			} else row.setAttribute("tabindex", "-1");
		});
	}
	/**
	* After first render, wire the shadow div[role="grid"] as the Tab stop and
	* attach the keydown listener to it (mirrors React: tabIndex={0} + onKeyDown
	* on the grid div).
	*/
	firstUpdated() {
		const gridEl = this.renderRoot.querySelector("[role=\"grid\"]");
		if (gridEl) {
			this._gridEl = gridEl;
			gridEl.setAttribute("tabindex", "0");
			gridEl.addEventListener("keydown", this._handleGridKeydown);
		}
		this._updateRowFocus(0, false);
	}
	disconnectedCallback() {
		super.disconnectedCallback();
		if (this._gridEl) {
			this._gridEl.removeEventListener("keydown", this._handleGridKeydown);
			this._gridEl = null;
		}
	}
	render() {
		const { itemsLabel, globalSearchLabel, globalSearchPlaceholder, searchResultsTitle, itemCount, hideSearch, layout, path, _searchTerm: searchTerm, _handleSearch: handleSearch } = this;
		const hasHeader = !hideSearch || this._hasHeaderSlot || itemCount !== void 0 || path && path.length > 0;
		return html`
      <div class="${blockClass}__body">
        ${hasHeader ? html`
              <div class="${blockClass}__header">
                <!-- Named slot: consumer can replace the entire header -->
                <slot
                  name="header"
                  @slotchange=${this._handleHeaderSlotChange}></slot>

                ${!this._hasHeaderSlot ? html`
                      <!-- Search + optional actions -->
                      ${!hideSearch ? html`
                            <div
                              class="${blockClass}__search ${blockClass}__search--with-actions">
                              <div class="${blockClass}__search-input">
                                <cds-custom-search
                                  label-text=${globalSearchLabel}
                                  placeholder=${globalSearchPlaceholder}
                                  size="lg"
                                  @cds-custom-search-input=${handleSearch}></cds-custom-search>
                              </div>
                              <div class="${blockClass}__global-actions">
                                <slot name="actions"></slot>
                              </div>
                            </div>
                          ` : nothing}

                      <!-- Sub-header: breadcrumbs / label + item count + optional actions -->
                      <div class="${blockClass}__sub-header">
                        <div class="${blockClass}__tags">
                          ${searchTerm ? html`
                                <p class="${blockClass}__tags-label">
                                  ${searchResultsTitle}
                                </p>
                              ` : path && path.length > 0 ? html`
                                  <cds-custom-breadcrumb
                                    no-trailing-slash
                                    class="${blockClass}__breadcrumbs">
                                    ${path.map((entry, idx) => {
			const isCurrentPage = idx === path.length - 1;
			return html`
                                        <cds-custom-breadcrumb-item
                                          ?is-current-page=${isCurrentPage}>
                                          ${isCurrentPage ? entry.title : html`
                                                <cds-custom-link
                                                  href="#"
                                                  @click=${(e) => {
				e.preventDefault();
				this.dispatchEvent(new CustomEvent(this.constructor.eventBreadcrumbClick, {
					bubbles: true,
					cancelable: true,
					composed: true,
					detail: { index: idx }
				}));
			}}>
                                                  ${entry.title}
                                                </cds-custom-link>
                                              `}
                                        </cds-custom-breadcrumb-item>
                                      `;
		})}
                                  </cds-custom-breadcrumb>
                                ` : html`
                                  <p class="${blockClass}__tags-label">
                                    ${itemsLabel}
                                  </p>
                                `}
                          ${itemCount !== void 0 ? html`<cds-custom-tag type="gray" size="sm"
                                >${itemCount}</cds-custom-tag
                              >` : nothing}
                        </div>
                        <slot name="sub-header-actions"></slot>
                      </div>
                    ` : nothing}
              </div>
            ` : nothing}

        <!-- Body Content -->
        <div class="${blockClass}__content" role="grid">
          <div
            class="${blockClass}-list-body${layout === "horizontal" ? ` ${blockClass}-list-body--horizontal` : ""}"
            role="rowgroup">
            <slot @slotchange=${this._handleContentSlotChange}></slot>
          </div>
        </div>
      </div>
    `;
	}
	/**
	* The name of the custom event fired when search term changes
	*/
	static get eventSearch() {
		return `cds-custom-add-select-body-search`;
	}
	/**
	* The name of the custom event fired when breadcrumb is clicked
	*/
	static get eventBreadcrumbClick() {
		return `cds-custom-add-select-body-breadcrumb-click`;
	}
	static {
		this.styles = add_select_body_default$1;
	}
};
__decorate([property({
	type: String,
	attribute: "items-label"
})], CDSAddSelectBody.prototype, "itemsLabel", void 0);
__decorate([property({
	type: String,
	attribute: "global-search-label"
})], CDSAddSelectBody.prototype, "globalSearchLabel", void 0);
__decorate([property({
	type: String,
	attribute: "global-search-placeholder"
})], CDSAddSelectBody.prototype, "globalSearchPlaceholder", void 0);
__decorate([property({
	type: String,
	attribute: "search-results-title"
})], CDSAddSelectBody.prototype, "searchResultsTitle", void 0);
__decorate([state()], CDSAddSelectBody.prototype, "_searchTerm", void 0);
__decorate([property({
	type: Number,
	attribute: "item-count"
})], CDSAddSelectBody.prototype, "itemCount", void 0);
__decorate([property({
	type: Boolean,
	attribute: "hide-search",
	reflect: true
})], CDSAddSelectBody.prototype, "hideSearch", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSAddSelectBody.prototype, "layout", void 0);
__decorate([property({ type: Array })], CDSAddSelectBody.prototype, "path", void 0);
__decorate([state()], CDSAddSelectBody.prototype, "_hasHeaderSlot", void 0);
CDSAddSelectBody = __decorate([carbonElement(`cds-custom-add-select-body`)], CDSAddSelectBody);
var add_select_body_default = CDSAddSelectBody;
//#endregion
export { add_select_body_default as default };

//# sourceMappingURL=add-select-body.js.map