/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/add-select/add-select.scss?lit
var add_select_default = css([":host(cds-custom-add-select){display:block}:host(cds-custom-add-select) .cds-custom--add-select__next{position:relative;display:flex;flex-direction:column;block-size:100%;inline-size:100%}"]);
//#endregion
export { add_select_default as default };

//# sourceMappingURL=add-select.scss.js.map