/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../checkbox/index.js";
import "../search/index.js";
import "../tag/index.js";
import add_select_column_default$1 from "./add-select-column.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/add-select/add-select-column.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select Column component — optional column wrapper providing column-level
* search, title, and "Select All" functionality. Propagates `multi` context to
* child rows via the `multi` property/attribute.
* @element cds-custom-add-select-column
* @slot default - AddSelectRow elements
* @slot actions - Custom actions (filter/sort) placed next to column search
* @fires cds-custom-add-select-column-search - Fired when column search changes; detail: { searchTerm }
* @fires cds-custom-add-select-column-select-all - Fired when "Select All" checkbox changes; detail: { checked }
*/
let CDSAddSelectColumn = class CDSAddSelectColumn extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.title = "";
		this.searchLabel = "Search";
		this.searchPlaceholder = "Search";
		this.hideSearch = false;
		this.multi = false;
		this.showSelectAll = false;
		this.itemCount = 0;
		this.allSelected = false;
		this.allIndeterminate = false;
		this._searchTerm = "";
		this._hasActionsSlot = false;
	}
	_handleActionsSlotChange(e) {
		const slot = e.target;
		this._hasActionsSlot = slot.assignedElements({ flatten: true }).length > 0;
	}
	_handleSearch(event) {
		this._searchTerm = event.detail?.value ?? "";
		this.dispatchEvent(new CustomEvent(this.constructor.eventSearch, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { searchTerm: this._searchTerm }
		}));
	}
	_handleSelectAll(event) {
		const checked = !!event.detail?.checked;
		this.dispatchEvent(new CustomEvent(this.constructor.eventSelectAll, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { checked }
		}));
	}
	_handleSlotChange() {
		const slot = this.shadowRoot?.querySelector("slot:not([name])");
		if (!slot) return;
		slot.assignedElements({ flatten: true }).forEach((el) => {
			if (el.tagName.toLowerCase() === `cds-custom-add-select-row`) {
				if (this.multi) el.setAttribute("_column-multi", "");
				else el.removeAttribute("_column-multi");
			}
		});
	}
	updated(changed) {
		if (changed.has("multi")) this._handleSlotChange();
	}
	render() {
		const { title, searchLabel, searchPlaceholder, hideSearch, multi, showSelectAll, itemCount, allSelected, allIndeterminate } = this;
		const columnClasses = classMap({ [`${blockClass}-column`]: true });
		const showHeader = showSelectAll || !!title;
		return html`
      <div class=${columnClasses} part="column">
        <!-- Column search with optional actions slot -->
        ${!hideSearch ? html`
              <div
                class="${classMap({
			[`${blockClass}-column__search`]: true,
			[`${blockClass}-column__search--with-actions`]: this._hasActionsSlot
		})}">
                <div
                  class="${this._hasActionsSlot ? `${blockClass}-column__search-input` : ""}">
                  <cds-custom-search
                    label-text=${searchLabel}
                    placeholder=${searchPlaceholder}
                    size="md"
                    @cds-custom-search-input=${this._handleSearch}></cds-custom-search>
                </div>
                <slot
                  name="actions"
                  class="${blockClass}-column__actions"
                  @slotchange=${this._handleActionsSlotChange}></slot>
              </div>
            ` : nothing}

        <!-- Column header: Select All checkbox or title -->
        ${showHeader ? html`
              <div class="${blockClass}-column__header">
                ${showSelectAll && multi ? html`
                      <cds-custom-checkbox
                        class="${blockClass}-column__select-all"
                        ?checked=${allSelected}
                        ?indeterminate=${allIndeterminate}
                        @cds-custom-checkbox-changed=${this._handleSelectAll}>
                        <span class="${blockClass}-column__title"
                          >${title}</span
                        >
                        ${itemCount > 0 ? html`<cds-custom-tag type="gray" size="sm"
                              >${itemCount}</cds-custom-tag
                            >` : nothing}
                      </cds-custom-checkbox>
                    ` : html`
                      <div class="${blockClass}-column__title-wrapper">
                        <span class="${blockClass}-column__title"
                          >${title}</span
                        >
                        ${itemCount > 0 ? html`<cds-custom-tag type="gray" size="sm"
                              >${itemCount}</cds-custom-tag
                            >` : nothing}
                      </div>
                    `}
              </div>
            ` : nothing}

        <!-- Rows container -->
        <div class="${blockClass}-column__rows" role="rowgroup">
          <slot @slotchange=${this._handleSlotChange}></slot>
        </div>
      </div>
    `;
	}
	/**
	* The name of the custom event fired when column search changes.
	* detail: { searchTerm: string }
	*/
	static get eventSearch() {
		return `cds-custom-add-select-column-search`;
	}
	/**
	* The name of the custom event fired when "Select All" is toggled.
	* detail: { checked: boolean }
	*/
	static get eventSelectAll() {
		return `cds-custom-add-select-column-select-all`;
	}
	static {
		this.styles = add_select_column_default$1;
	}
};
__decorate([property({ type: String })], CDSAddSelectColumn.prototype, "title", void 0);
__decorate([property({
	type: String,
	attribute: "search-label"
})], CDSAddSelectColumn.prototype, "searchLabel", void 0);
__decorate([property({
	type: String,
	attribute: "search-placeholder"
})], CDSAddSelectColumn.prototype, "searchPlaceholder", void 0);
__decorate([property({
	type: Boolean,
	attribute: "hide-search",
	reflect: true
})], CDSAddSelectColumn.prototype, "hideSearch", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAddSelectColumn.prototype, "multi", void 0);
__decorate([property({
	type: Boolean,
	attribute: "show-select-all",
	reflect: true
})], CDSAddSelectColumn.prototype, "showSelectAll", void 0);
__decorate([property({
	type: Number,
	attribute: "item-count"
})], CDSAddSelectColumn.prototype, "itemCount", void 0);
__decorate([property({
	type: Boolean,
	attribute: "all-selected",
	reflect: true
})], CDSAddSelectColumn.prototype, "allSelected", void 0);
__decorate([property({
	type: Boolean,
	attribute: "all-indeterminate",
	reflect: true
})], CDSAddSelectColumn.prototype, "allIndeterminate", void 0);
__decorate([state()], CDSAddSelectColumn.prototype, "_searchTerm", void 0);
__decorate([state()], CDSAddSelectColumn.prototype, "_hasActionsSlot", void 0);
CDSAddSelectColumn = __decorate([carbonElement(`cds-custom-add-select-column`)], CDSAddSelectColumn);
var add_select_column_default = CDSAddSelectColumn;
//#endregion
export { add_select_column_default as default };

//# sourceMappingURL=add-select-column.js.map