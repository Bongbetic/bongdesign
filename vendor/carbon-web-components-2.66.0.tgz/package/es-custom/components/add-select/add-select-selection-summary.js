/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../icon-button/index.js";
import "../tag/index.js";
import add_select_selection_summary_default$1 from "./add-select-selection-summary.scss.js";
import { LitElement, html, nothing } from "lit";
import { property } from "lit/decorators.js";
import Edit16 from "@carbon/icons/es/edit/16";
//#region src/components/add-select/add-select-selection-summary.ts
/**
* @license
*
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--add-select__next`;
/**
* Add Select Selection Summary — displays the list of selected items.
* @element cds-custom-add-select-selection-summary
* @slot default - SelectionSummaryItem components or custom body content
* @slot header - Replaces the entire header section
* @slot header-actions - Custom actions alongside the edit icon
* @slot empty-state - Shown when selectedItemCount is 0 or not set
* @fires cds-custom-add-select-selection-summary-edit - Fired when edit icon is clicked
*/
let CDSAddSelectSelectionSummary = class CDSAddSelectSelectionSummary extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.title = "Selected items";
		this.selectedItemCount = void 0;
		this.showEditIcon = false;
		this.editIconDescription = "Edit selections";
	}
	_handleEdit() {
		this.dispatchEvent(new CustomEvent(this.constructor.eventEdit, {
			bubbles: true,
			cancelable: true,
			composed: true
		}));
	}
	render() {
		const { title, selectedItemCount, showEditIcon, editIconDescription } = this;
		const showBody = selectedItemCount !== void 0 && selectedItemCount > 0;
		return html`
      <div class="${blockClass}__selection-summary">
        <!-- Header -->
        <div class="${blockClass}__selection-summary-header">
          <slot name="header">
            <p class="${blockClass}__selection-summary-title">${title}</p>
            ${selectedItemCount !== void 0 ? html`<cds-custom-tag type="gray" size="sm"
                  >${selectedItemCount}</cds-custom-tag
                >` : nothing}
            ${showEditIcon ? html`
                  <div class="${blockClass}__selection-summary-header-actions">
                    <slot name="header-actions"></slot>
                    <cds-custom-icon-button
                      kind="ghost"
                      size="sm"
                      autoalign
                      class="${blockClass}__selection-summary-edit-button"
                      @click=${this._handleEdit}>
                      ${iconLoader(Edit16, { slot: "icon" })}
                      <span slot="tooltip-content">${editIconDescription}</span>
                    </cds-custom-icon-button>
                  </div>
                ` : html`<slot name="header-actions"></slot>`}
          </slot>
        </div>

        <!-- Body: empty state or items -->
        <div class="${blockClass}__selection-summary-body">
          ${showBody ? html`<slot></slot>` : html`<slot name="empty-state"></slot>`}
        </div>
      </div>
    `;
	}
	/**
	* The name of the custom event fired when the edit icon is clicked.
	*/
	static get eventEdit() {
		return `cds-custom-add-select-selection-summary-edit`;
	}
	static {
		this.styles = add_select_selection_summary_default$1;
	}
};
__decorate([property({ type: String })], CDSAddSelectSelectionSummary.prototype, "title", void 0);
__decorate([property({
	type: Number,
	attribute: "selected-item-count"
})], CDSAddSelectSelectionSummary.prototype, "selectedItemCount", void 0);
__decorate([property({
	type: Boolean,
	attribute: "show-edit-icon",
	reflect: true
})], CDSAddSelectSelectionSummary.prototype, "showEditIcon", void 0);
__decorate([property({
	type: String,
	attribute: "edit-icon-description"
})], CDSAddSelectSelectionSummary.prototype, "editIconDescription", void 0);
CDSAddSelectSelectionSummary = __decorate([carbonElement(`cds-custom-add-select-selection-summary`)], CDSAddSelectSelectionSummary);
var add_select_selection_summary_default = CDSAddSelectSelectionSummary;
//#endregion
export { add_select_selection_summary_default as default };

//# sourceMappingURL=add-select-selection-summary.js.map