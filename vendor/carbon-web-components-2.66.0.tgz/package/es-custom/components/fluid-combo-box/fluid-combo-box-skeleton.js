/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_combo_box_default from "./fluid-combo-box.scss.js";
import { LitElement, html } from "lit";
//#region src/components/fluid-combo-box/fluid-combo-box-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid combo box skeleton.
*
* @element cds-custom-fluid-combo-box-skeleton
*/
let CDSFluidComboBoxSkeleton = class CDSFluidComboBoxSkeleton extends LitElement {
	render() {
		return html`
      <div class="${"cds-custom"}--list-box__wrapper--fluid">
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--list-box">
          <span class="${"cds-custom"}--list-box__label"></span>
          <div class="${"cds-custom"}--list-box__field"></div>
        </div>
      </div>
    `;
	}
	static {
		this.styles = fluid_combo_box_default;
	}
};
CDSFluidComboBoxSkeleton = __decorate([carbonElement(`cds-custom-fluid-combo-box-skeleton`)], CDSFluidComboBoxSkeleton);
var fluid_combo_box_skeleton_default = CDSFluidComboBoxSkeleton;
//#endregion
export { fluid_combo_box_skeleton_default as default };

//# sourceMappingURL=fluid-combo-box-skeleton.js.map