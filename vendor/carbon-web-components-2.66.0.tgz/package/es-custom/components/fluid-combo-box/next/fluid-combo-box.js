/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_combo_box_default$1 from "../fluid-combo-box.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/fluid-combo-box/next/fluid-combo-box.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated preview of `cds-custom-fluid-combo-box`.
*
* Identical to `cds-custom-fluid-combo-box` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* @element cds-custom-preview-fluid-combo-box
*/
let CDSPreviewFluidComboBox = class CDSPreviewFluidComboBox extends FormAssociatedMixin(fluid_combo_box_default$1) {
	static get is() {
		return `cds-custom-preview-fluid-combo-box`;
	}
};
CDSPreviewFluidComboBox = __decorate([carbonElement(`cds-custom-preview-fluid-combo-box`)], CDSPreviewFluidComboBox);
var fluid_combo_box_default = CDSPreviewFluidComboBox;
//#endregion
export { fluid_combo_box_default as default };

//# sourceMappingURL=fluid-combo-box.js.map