/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import combo_box_default from "../combo-box/combo-box.js";
import fluid_combo_box_default$1 from "./fluid-combo-box.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/fluid-combo-box/fluid-combo-box.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid combo box.
*
* @element cds-custom-fluid-combo-box
*/
let CDSFluidComboBox = class CDSFluidComboBox extends combo_box_default {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readOnly") || changedProperties.has("warn") || changedProperties.has("isCondensed")) this.requestUpdate();
	}
	static {
		this.styles = [combo_box_default.styles, fluid_combo_box_default$1];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidComboBox.prototype, "isCondensed", void 0);
CDSFluidComboBox = __decorate([carbonElement(`cds-custom-fluid-combo-box`)], CDSFluidComboBox);
var fluid_combo_box_default = CDSFluidComboBox;
//#endregion
export { fluid_combo_box_default as default };

//# sourceMappingURL=fluid-combo-box.js.map