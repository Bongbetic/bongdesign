/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/card/card-context.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const cardDefaultContext = {
	clickable: false,
	disabled: false,
	horizontal: false,
	hasAILabel: false
};
/**
* Lit context shared by cds-custom-card (provider) and
* cds-custom-card-footer, cds-custom-card-media (consumers).
*/
const cardContext = createContext("cds-custom-card-context");
//#endregion
export { cardContext, cardDefaultContext };

//# sourceMappingURL=card-context.js.map