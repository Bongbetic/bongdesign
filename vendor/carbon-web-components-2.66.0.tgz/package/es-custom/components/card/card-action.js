/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/card/card-action.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card action — wrapper for a single interactive element inside cds-custom-card-actions.
* The `label` property provides a fallback string for the overflow menu when this
* action is hidden due to container overflow.
*
* @element cds-custom-card-action
* @slot - Default slot for a button or icon-button.
*/
let CDSCardAction = class CDSCardAction extends LitElement {
	_handleSlotChange({ target }) {
		if (target.assignedElements({ flatten: true }).some((el) => el.matches(`cds-custom-icon-button`))) this.setAttribute("icon-only", "");
		else this.removeAttribute("icon-only");
	}
	render() {
		return html`<div class="${"cds-custom"}--card__action">
      <slot @slotchange=${this._handleSlotChange}></slot>
    </div>`;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSCardAction.prototype, "label", void 0);
CDSCardAction = __decorate([carbonElement(`cds-custom-card-action`)], CDSCardAction);
var card_action_default = CDSCardAction;
//#endregion
export { card_action_default as default };

//# sourceMappingURL=card-action.js.map