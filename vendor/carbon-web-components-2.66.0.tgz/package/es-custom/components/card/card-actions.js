/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../menu/index.js";
import card_default from "./card.scss.js";
import "../overflow-menu/index.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { createOverflowHandler } from "@carbon/utilities/overflowHandler";
import OverflowMenuVertical16 from "@carbon/icons/es/overflow-menu--vertical/16.js";
//#region src/components/card/card-actions.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const _overflowIcon = iconLoader(OverflowMenuVertical16, {
	slot: "icon",
	class: `cds-custom--overflow-menu__icon`
});
/**
* Card actions
*
* @element cds-custom-card-actions
* @slot - Default slot for cds-custom-card-action elements.
*/
let CDSCardActions = class CDSCardActions extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.overflowMenuLabel = "More actions";
		this._hiddenIds = /* @__PURE__ */ new Set();
		this._actionItems = [];
		this._pendingAttach = false;
	}
	disconnectedCallback() {
		super.disconnectedCallback();
		this._overflowHandler?.disconnect();
		this._overflowHandler = void 0;
		this._offsetEl?.remove();
		this._offsetEl = void 0;
		this._pendingAttach = false;
		this._hiddenIds = /* @__PURE__ */ new Set();
		this._actionItems = [];
	}
	_ensureOffsetEl() {
		if (this._offsetEl) return;
		const div = document.createElement("div");
		div.setAttribute("data-offset", "");
		div.style.inlineSize = `var(--cds-spacing-07, 2rem)`;
		div.style.blockSize = `var(--cds-spacing-07, 2rem)`;
		div.style.flexShrink = "0";
		div.style.display = "none";
		this._offsetEl = div;
		this.appendChild(div);
	}
	_handleSlotChange({ target }) {
		const actions = target.assignedElements({ flatten: true }).filter((el) => el instanceof HTMLElement && el.localName === `cds-custom-card-action`);
		this._assignActionIds(actions);
		this._actionItems = this._resolveActionItems(actions);
		if (!this._pendingAttach) {
			this._pendingAttach = true;
			this.updateComplete.then(() => {
				this._pendingAttach = false;
				if (this.isConnected) this._attachOverflowHandler();
			});
		}
	}
	_attachOverflowHandler() {
		this._overflowHandler?.disconnect();
		this._overflowHandler = void 0;
		if (this._actionItems.length === 0) return;
		this._ensureOffsetEl();
		const idByEl = new Map(this._actionItems.map(({ el, id }) => [el, id]));
		const offsetEl = this._offsetEl;
		this._overflowHandler = createOverflowHandler({
			container: this,
			gap: 8,
			onChange: (_, hidden) => {
				if (offsetEl) offsetEl.style.display = hidden.length > 0 ? "block" : "none";
				this._hiddenIds = new Set(hidden.map((el) => idByEl.get(el)).filter((id) => id !== void 0));
			}
		});
	}
	_assignActionIds(actions) {
		actions.forEach((action, index) => {
			action.dataset.actionId = `card-action-${index}`;
		});
	}
	_resolveActionItems(actions) {
		return actions.map((action, index) => {
			const id = `card-action-${index}`;
			const actionLabel = action.getAttribute("label");
			if (actionLabel) return {
				el: action,
				label: actionLabel,
				id
			};
			const button = action.querySelector(`cds-custom-button, cds-custom-icon-button`);
			if (button) {
				const btnLabel = button.getAttribute("label") || button.getAttribute("tooltip-text") || button.getAttribute("tooltip-content");
				if (btnLabel) return {
					el: action,
					label: btnLabel,
					id
				};
			}
			const tooltipContent = action.querySelector("[slot=\"tooltip-content\"]");
			if (tooltipContent?.textContent?.trim()) return {
				el: action,
				label: tooltipContent.textContent.trim(),
				id
			};
			return {
				el: action,
				label: `Action ${index + 1}`,
				id
			};
		});
	}
	render() {
		const { _actionItems, _hiddenIds, overflowMenuLabel } = this;
		const hasHidden = _hiddenIds.size > 0;
		const hiddenItems = _actionItems.filter(({ id }) => _hiddenIds.has(id));
		return html`
      <slot @slotchange=${this._handleSlotChange}></slot>

      ${hasHidden ? html`
            <cds-custom-overflow-menu
              size="sm"
              enable-v12-overflowmenu
              autoalign
              menu-alignment="bottom-end"
              label=${overflowMenuLabel}
              class="${"cds-custom"}--card__actions-overflow-menu">
              ${_overflowIcon}
              <cds-custom-menu>
                ${hiddenItems.map(({ id, label }) => html`
                    <cds-custom-menu-item
                      data-action-id=${id}
                      label=${label}></cds-custom-menu-item>
                  `)}
              </cds-custom-menu>
            </cds-custom-overflow-menu>
          ` : nothing}
    `;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([property({
	attribute: "overflow-menu-label",
	reflect: true
})], CDSCardActions.prototype, "overflowMenuLabel", void 0);
__decorate([state()], CDSCardActions.prototype, "_hiddenIds", void 0);
__decorate([state()], CDSCardActions.prototype, "_actionItems", void 0);
CDSCardActions = __decorate([carbonElement(`cds-custom-card-actions`)], CDSCardActions);
var card_actions_default = CDSCardActions;
//#endregion
export { card_actions_default as default };

//# sourceMappingURL=card-actions.js.map