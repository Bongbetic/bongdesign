/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import card_default from "./card.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { styleMap } from "lit/directives/style-map.js";
//#region src/components/card/card-title.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card title — primary heading within cds-custom-card-header.
*
* @element cds-custom-card-title
* @slot - Title text (required).
* @slot label - Rich label content rendered above the title (overrides `label` attr).
* @slot title-start - Leading icon/content (16px productive, 24px expressive).
* @slot title-end - Trailing icon/content.
* @slot description - Rich description rendered below the title (overrides `description` attr).
*/
let CDSCardTitle = class CDSCardTitle extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.titleTruncate = null;
		this.maxWidth = "100%";
		this.labelTruncate = null;
		this.descriptionTruncate = null;
		this._hasTitleStart = false;
	}
	_onTitleStartSlotChange(e) {
		const slot = e.target;
		this._hasTitleStart = slot.assignedElements().length > 0;
	}
	_parseTruncate(value) {
		if (value === null) return false;
		const num = Number(value);
		if (!isNaN(num) && num > 0) return num;
		return true;
	}
	render() {
		const blockClass = `cds-custom--card`;
		const titleTruncate = this._parseTruncate(this.titleTruncate);
		const labelTruncate = this._parseTruncate(this.labelTruncate);
		const descTruncate = this._parseTruncate(this.descriptionTruncate);
		const isTitleMulti = typeof titleTruncate === "number";
		const isLabelMulti = typeof labelTruncate === "number";
		const isDescMulti = typeof descTruncate === "number";
		const titleVars = titleTruncate !== false ? {
			[`--cds--card--title-max-width`]: this.maxWidth,
			...isTitleMulti && { [`--cds--card--title-line-clamp`]: String(titleTruncate) }
		} : {};
		const labelVars = isLabelMulti ? { [`--cds--card--label-line-clamp`]: String(labelTruncate) } : {};
		const descVars = isDescMulti ? { [`--cds--card--description-line-clamp`]: String(descTruncate) } : {};
		const textRowClasses = classMap({
			[`${blockClass}__title-text-row`]: true,
			[`${blockClass}__title-text-row--truncate`]: titleTruncate === true,
			[`${blockClass}__title-text-row--truncate-multi`]: isTitleMulti,
			[`${blockClass}__title-text-row--with-start-icon`]: this._hasTitleStart
		});
		const labelClasses = classMap({
			[`${blockClass}__label`]: true,
			[`${blockClass}__label--truncate`]: labelTruncate === true,
			[`${blockClass}__label--truncate-multi`]: isLabelMulti
		});
		const descClasses = classMap({
			[`${blockClass}__description`]: true,
			[`${blockClass}__description--truncate`]: descTruncate === true,
			[`${blockClass}__description--truncate-multi`]: isDescMulti
		});
		return html`
      <div class="${blockClass}__title">
        <slot name="label">
          ${this.label ? html`<div class=${labelClasses} style=${styleMap(labelVars)}>
                ${this.label}
              </div>` : nothing}
        </slot>

        <span class=${textRowClasses} style=${styleMap(titleVars)}>
          <span class="${blockClass}__title-start-icon">
            <slot
              name="title-start"
              @slotchange=${this._onTitleStartSlotChange}></slot>
          </span>
          <slot></slot>
          <span class="${blockClass}__title-end-icon">
            <slot name="title-end"></slot>
          </span>
        </span>

        <slot name="description">
          ${this.description ? html`<div class=${descClasses} style=${styleMap(descVars)}>
                ${this.description}
              </div>` : nothing}
        </slot>
      </div>
    `;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([property({
	attribute: "title-truncate",
	reflect: true
})], CDSCardTitle.prototype, "titleTruncate", void 0);
__decorate([property({
	attribute: "max-width",
	reflect: true
})], CDSCardTitle.prototype, "maxWidth", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCardTitle.prototype, "label", void 0);
__decorate([property({
	attribute: "label-truncate",
	reflect: true
})], CDSCardTitle.prototype, "labelTruncate", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCardTitle.prototype, "description", void 0);
__decorate([property({
	attribute: "description-truncate",
	reflect: true
})], CDSCardTitle.prototype, "descriptionTruncate", void 0);
__decorate([state()], CDSCardTitle.prototype, "_hasTitleStart", void 0);
CDSCardTitle = __decorate([carbonElement(`cds-custom-card-title`)], CDSCardTitle);
var card_title_default = CDSCardTitle;
//#endregion
export { card_title_default as default };

//# sourceMappingURL=card-title.js.map