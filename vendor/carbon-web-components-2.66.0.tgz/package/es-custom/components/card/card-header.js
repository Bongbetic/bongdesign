/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { cardContext, cardDefaultContext } from "./card-context.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
import { state } from "lit/decorators.js";
import { consume } from "@lit/context";
//#region src/components/card/card-header.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card header — header section of the card.
*
* @element cds-custom-card-header
* @slot - Default slot for cds-custom-card-title, cds-custom-card-title-media, cds-custom-card-actions.
* @slot decorator - Slot for cds-custom-ai-label or other decorator element.
*/
let CDSCardHeader = class CDSCardHeader extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._cardContext = cardDefaultContext;
	}
	_handleDefaultSlotChange({ target }) {
		if (target.assignedElements({ flatten: true }).some((el) => el.matches(`cds-custom-card-title-media`))) this.setAttribute("has-title-media", "");
		else this.removeAttribute("has-title-media");
	}
	_handleDecoratorInteraction(e) {
		e.stopPropagation();
	}
	render() {
		const { hasAILabel } = this._cardContext;
		return html`
      <div class="${"cds-custom"}--card__header" ?data-has-ai-label=${hasAILabel}>
        <slot @slotchange=${this._handleDefaultSlotChange}></slot>
        <div
          class="${"cds-custom"}--card__decorator"
          role="presentation"
          @click=${this._handleDecoratorInteraction}
          @keydown=${this._handleDecoratorInteraction}>
          <slot name="decorator"></slot>
        </div>
      </div>
    `;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([consume({
	context: cardContext,
	subscribe: true
}), state()], CDSCardHeader.prototype, "_cardContext", void 0);
CDSCardHeader = __decorate([carbonElement(`cds-custom-card-header`)], CDSCardHeader);
var card_header_default = CDSCardHeader;
//#endregion
export { card_header_default as default };

//# sourceMappingURL=card-header.js.map