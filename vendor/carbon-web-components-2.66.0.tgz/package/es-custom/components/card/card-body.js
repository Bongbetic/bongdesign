/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/card/card-body.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card body — primary content area.
*
* @element cds-custom-card-body
* @slot - Default slot for free-form content.
*/
let CDSCardBody = class CDSCardBody extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.isFlush = false;
	}
	render() {
		const { isFlush } = this;
		const classes = classMap({
			[`cds-custom--card__body`]: true,
			[`cds-custom--card__body--flush`]: isFlush
		});
		return html`<div class=${classes}><slot></slot></div>`;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "is-flush",
	reflect: true
})], CDSCardBody.prototype, "isFlush", void 0);
CDSCardBody = __decorate([carbonElement(`cds-custom-card-body`)], CDSCardBody);
var card_body_default = CDSCardBody;
//#endregion
export { card_body_default as default };

//# sourceMappingURL=card-body.js.map