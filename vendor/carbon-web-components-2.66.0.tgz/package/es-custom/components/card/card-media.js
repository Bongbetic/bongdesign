/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { cardContext, cardDefaultContext } from "./card-context.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { consume } from "@lit/context";
import { styleMap } from "lit/directives/style-map.js";
//#region src/components/card/card-media.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card media — aspect-ratio media slot.
*
* @element cds-custom-card-media
* @slot - Default slot for an image, video, or other media content.
*/
let CDSCardMedia = class CDSCardMedia extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._cardContext = cardDefaultContext;
		this.ratio = "";
		this.mediaWidth = "33.33%";
	}
	updated() {
		if (this._cardContext.horizontal) this.setAttribute("slot", "media");
		else this.removeAttribute("slot");
	}
	render() {
		const blockClass = `cds-custom--card`;
		const { ratio, mediaWidth, _cardContext } = this;
		if (_cardContext.horizontal) return html`
        <div
          class="${blockClass}__media ${blockClass}__media--horizontal"
          style=${styleMap({ [`--cds--card--media-width`]: mediaWidth })}>
          <slot></slot>
        </div>
      `;
		const classes = classMap({
			[`${blockClass}__media`]: true,
			[`cds-custom--aspect-ratio`]: Boolean(ratio),
			[`cds-custom--aspect-ratio--${ratio}`]: Boolean(ratio)
		});
		return html`<div class=${classes}><slot></slot></div>`;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([consume({
	context: cardContext,
	subscribe: true
}), state()], CDSCardMedia.prototype, "_cardContext", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCardMedia.prototype, "ratio", void 0);
__decorate([property({
	attribute: "media-width",
	reflect: true
})], CDSCardMedia.prototype, "mediaWidth", void 0);
CDSCardMedia = __decorate([carbonElement(`cds-custom-card-media`)], CDSCardMedia);
var card_media_default = CDSCardMedia;
//#endregion
export { card_media_default as default };

//# sourceMappingURL=card-media.js.map