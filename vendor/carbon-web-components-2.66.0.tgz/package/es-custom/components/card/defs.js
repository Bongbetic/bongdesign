/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/card/defs.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card density.
*/
let CARD_DENSITY = /* @__PURE__ */ function(CARD_DENSITY) {
	/**
	* Productive density — heading-compact-02 typography.
	*/
	CARD_DENSITY["PRODUCTIVE"] = "productive";
	/**
	* Expressive density — heading-03 typography.
	*/
	CARD_DENSITY["EXPRESSIVE"] = "expressive";
	return CARD_DENSITY;
}({});
/**
* Horizontal card media position.
*/
let CARD_MEDIA_POSITION = /* @__PURE__ */ function(CARD_MEDIA_POSITION) {
	/**
	* Media on the inline-start side (default).
	*/
	CARD_MEDIA_POSITION["START"] = "start";
	/**
	* Media on the inline-end side.
	*/
	CARD_MEDIA_POSITION["END"] = "end";
	return CARD_MEDIA_POSITION;
}({});
//#endregion
export { CARD_DENSITY, CARD_MEDIA_POSITION };

//# sourceMappingURL=defs.js.map