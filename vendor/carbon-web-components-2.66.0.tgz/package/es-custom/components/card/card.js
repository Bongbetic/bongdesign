/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import link_default from "../link/link.js";
import { cardContext, cardDefaultContext } from "./card-context.js";
import { CARD_DENSITY, CARD_MEDIA_POSITION } from "./defs.js";
import card_default$1 from "./card.scss.js";
import { html, nothing } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { provide } from "@lit/context";
import ArrowRight16 from "@carbon/icons/es/arrow--right/16.js";
//#region src/components/card/card.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card — composable container component.
*
* @element cds-custom-card
* @slot - Default slot for cds-custom-card-header, cds-custom-card-body, cds-custom-card-footer, cds-custom-card-media.
* @slot decorator - Slot for cds-custom-ai-label. Sets `has-ai-label` attribute when populated.
* @slot footer-icon - Override the default ArrowRight icon in the clickable footer.
*/
let CDSCard = class CDSCard extends link_default {
	constructor(..._args) {
		super(..._args);
		this.cardContext = cardDefaultContext;
		this._hasAILabel = false;
		this.clickable = false;
		this.disabled = false;
		this.density = "productive";
		this.horizontal = false;
		this.mediaPosition = "start";
	}
	connectedCallback() {
		super.connectedCallback();
		if (this.clickable && !this.href && !this.getAttribute("aria-label") && !this.getAttribute("aria-labelledby")) console.error("[cds-custom-card] A clickable card must have an accessible name. Set `aria-label` or `aria-labelledby` on the element.");
	}
	willUpdate(changed) {
		super.willUpdate?.(changed);
		if (changed.has("clickable") || changed.has("disabled") || changed.has("horizontal") || changed.has("_hasAILabel")) this.cardContext = {
			clickable: this.clickable,
			disabled: this.disabled,
			horizontal: this.horizontal,
			hasAILabel: this._hasAILabel
		};
	}
	_handleDecoratorSlotChange({ target }) {
		const hasAILabel = target.assignedElements().some((el) => el.matches(`cds-custom-ai-label`));
		this._hasAILabel = hasAILabel;
		if (hasAILabel) this.setAttribute("has-ai-label", "");
		else this.removeAttribute("has-ai-label");
	}
	_handleDefaultSlotChange({ target }) {
		if (target.assignedElements({ flatten: true }).some((el) => el.matches(`cds-custom-card-actions`))) this.setAttribute("has-actions", "");
		else this.removeAttribute("has-actions");
	}
	_handleClick(e) {
		if (this.disabled) {
			e.stopPropagation();
			e.preventDefault();
		}
	}
	_handleKeydown(e) {
		if (this.disabled) return;
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault();
			e.currentTarget.click();
		}
	}
	/** The BEM class map for the root card div/anchor. */
	get _cardClasses() {
		const { clickable, disabled, density, _hasAILabel, horizontal } = this;
		return classMap({
			[`cds-custom--card`]: true,
			[`cds-custom--card--clickable`]: clickable && !disabled,
			[`cds-custom--card--disabled`]: disabled,
			[`cds-custom--card--${density}`]: true,
			[`cds-custom--card--has-ai-label`]: _hasAILabel,
			[`cds-custom--card--horizontal`]: horizontal
		});
	}
	/**
	* The card's inner content layout.
	*/
	_renderContent() {
		const { horizontal, mediaPosition } = this;
		if (!horizontal) return html`<slot @slotchange=${this._handleDefaultSlotChange}></slot>`;
		const mediaSlot = html`<slot name="media"></slot>`;
		const contentDiv = html`
      <div class="${"cds-custom"}--card__content">
        <slot @slotchange=${this._handleDefaultSlotChange}></slot>
      </div>
    `;
		return mediaPosition === "end" ? html`${contentDiv}${mediaSlot}` : html`${mediaSlot}${contentDiv}`;
	}
	/** Clickable-footer affordance (aria-hidden, purely decorative). */
	_renderClickableFooter() {
		return html`
      <div class="${"cds-custom"}--card__clickable-footer" aria-hidden="true">
        <slot name="footer-icon">
          ${iconLoader(ArrowRight16, { "aria-hidden": "true" })}
        </slot>
      </div>
    `;
	}
	_renderInner() {
		const { clickable } = this;
		return html`
      <div class=${this._cardClasses}>
        ${this._renderContent()}
        ${clickable ? this._renderClickableFooter() : nothing}
        <div class="${"cds-custom"}--card__decorator">
          <slot
            name="decorator"
            @slotchange=${this._handleDecoratorSlotChange}></slot>
        </div>
      </div>
    `;
	}
	render() {
		return this._renderLink();
	}
	_renderLink() {
		const { href, clickable, disabled } = this;
		if (href) return disabled ? this._renderDisabledLink() : super._renderLink();
		if (clickable) return html`
        <div
          role="button"
          tabindex=${disabled ? -1 : 0}
          aria-disabled=${disabled}
          @click=${this._handleClick}
          @keydown=${this._handleKeydown}>
          ${this._renderInner()}
        </div>
      `;
		return html`<div>${this._renderInner()}</div>`;
	}
	/**
	* Selector matching the AI Label element.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.styles = card_default$1;
	}
};
__decorate([provide({ context: cardContext }), property({ attribute: false })], CDSCard.prototype, "cardContext", void 0);
__decorate([state()], CDSCard.prototype, "_hasAILabel", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCard.prototype, "clickable", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCard.prototype, "disabled", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSCard.prototype, "density", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCard.prototype, "horizontal", void 0);
__decorate([property({
	attribute: "media-position",
	reflect: true
})], CDSCard.prototype, "mediaPosition", void 0);
CDSCard = __decorate([carbonElement(`cds-custom-card`)], CDSCard);
var card_default = CDSCard;
//#endregion
export { CARD_DENSITY, CARD_MEDIA_POSITION, card_default as default };

//# sourceMappingURL=card.js.map