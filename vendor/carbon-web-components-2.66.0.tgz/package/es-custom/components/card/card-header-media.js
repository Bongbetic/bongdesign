/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
//#region src/components/card/card-header-media.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card header media — full-width icon/image slot rendered above the title row.
*
* @element cds-custom-card-header-media
* @slot - Default slot for an icon, image, or pictogram.
*/
let CDSCardHeaderMedia = class CDSCardHeaderMedia extends LitElement {
	render() {
		return html`<div class="${"cds-custom"}--card__header-media"><slot></slot></div>`;
	}
	static {
		this.styles = card_default;
	}
};
CDSCardHeaderMedia = __decorate([carbonElement(`cds-custom-card-header-media`)], CDSCardHeaderMedia);
var card_header_media_default = CDSCardHeaderMedia;
//#endregion
export { card_header_media_default as default };

//# sourceMappingURL=card-header-media.js.map