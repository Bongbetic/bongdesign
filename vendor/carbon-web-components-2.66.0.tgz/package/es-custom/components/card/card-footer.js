/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { cardContext, cardDefaultContext } from "./card-context.js";
import card_default from "./card.scss.js";
import { LitElement, html, nothing } from "lit";
import { state } from "lit/decorators.js";
import { consume } from "@lit/context";
//#region src/components/card/card-footer.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card footer — bottom content/action bar.
*
* Must not be used inside a `clickable` card. When placed inside one,
* this element renders nothing and logs a console.error — a clickable
* card renders its own built-in footer affordance automatically.
*
* Reflects `has-actions` when any `cds-custom-card-action` element is slotted,
* enabling CSS rule [17] to apply zero-padding / border-top layout without
* any cross-boundary `:has(> .cds-custom--card__action)`.
*
* @element cds-custom-card-footer
* @slot - Default slot for footer content or cds-custom-card-action elements.
*/
let CDSCardFooter = class CDSCardFooter extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._cardContext = cardDefaultContext;
	}
	/**
	* Reflects `has-actions` attribute when at least one `cds-custom-card-action`
	* is present in the default slot. CSS rule [17] keys off this attribute
	* to switch the footer to its action-set layout (padding:0, border-top).
	*/
	_handleDefaultSlotChange({ target }) {
		if (target.assignedElements({ flatten: true }).some((el) => el.matches(`cds-custom-card-action`))) this.setAttribute("has-actions", "");
		else this.removeAttribute("has-actions");
	}
	render() {
		if (this._cardContext.clickable) {
			console.error("[cds-custom-card-footer] Cannot be used inside a clickable card. A clickable card renders its own footer affordance automatically. Use the `footer-icon` slot on `cds-custom-card` to customise the icon.");
			return nothing;
		}
		return html`
      <div class="${"cds-custom"}--card__footer">
        <slot @slotchange=${this._handleDefaultSlotChange}></slot>
      </div>
    `;
	}
	static {
		this.styles = card_default;
	}
};
__decorate([consume({
	context: cardContext,
	subscribe: true
}), state()], CDSCardFooter.prototype, "_cardContext", void 0);
CDSCardFooter = __decorate([carbonElement(`cds-custom-card-footer`)], CDSCardFooter);
var card_footer_default = CDSCardFooter;
//#endregion
export { card_footer_default as default };

//# sourceMappingURL=card-footer.js.map