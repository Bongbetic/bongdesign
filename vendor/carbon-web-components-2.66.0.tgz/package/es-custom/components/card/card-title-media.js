/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import card_default from "./card.scss.js";
import { LitElement, html } from "lit";
//#region src/components/card/card-title-media.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Card title media — media slot positioned to the left of the card title.
*
* @element cds-custom-card-title-media
* @slot - Default slot for an icon, avatar, or pictogram.
*/
let CDSCardTitleMedia = class CDSCardTitleMedia extends LitElement {
	render() {
		return html`<div class="${"cds-custom"}--card__title-media"><slot></slot></div>`;
	}
	static {
		this.styles = card_default;
	}
};
CDSCardTitleMedia = __decorate([carbonElement(`cds-custom-card-title-media`)], CDSCardTitleMedia);
var card_title_media_default = CDSCardTitleMedia;
//#endregion
export { card_title_media_default as default };

//# sourceMappingURL=card-title-media.js.map