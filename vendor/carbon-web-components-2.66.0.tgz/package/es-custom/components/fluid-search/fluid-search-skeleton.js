/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import search_skeleton_default from "../search/search-skeleton.js";
import fluid_search_default from "./fluid-search.scss.js";
import { html } from "lit";
//#region src/components/fluid-search/fluid-search-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid Search.
*
* @element cds-custom-fluid-search-skeleton
*/
let CDSFluidSearchSkeleton = class CDSFluidSearchSkeleton extends search_skeleton_default {
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [search_skeleton_default.styles, fluid_search_default];
	}
};
CDSFluidSearchSkeleton = __decorate([carbonElement(`cds-custom-fluid-search-skeleton`)], CDSFluidSearchSkeleton);
var fluid_search_skeleton_default = CDSFluidSearchSkeleton;
//#endregion
export { fluid_search_skeleton_default as default };

//# sourceMappingURL=fluid-search-skeleton.js.map