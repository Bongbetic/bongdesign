/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import search_default from "../search/search.js";
import fluid_search_default$1 from "./fluid-search.scss.js";
import { html } from "lit";
//#region src/components/fluid-search/fluid-search.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text input.
*
* @element cds-custom-fluid-search
*/
let CDSFluidSearch = class CDSFluidSearch extends search_default {
	render() {
		const { labelText, id } = this;
		return html`
      <label for="${id}" part="label-text" class="${"cds-custom"}--label"
        >${labelText}</label
      >
      ${super.render()}
    `;
	}
	static {
		this.styles = [search_default.styles, fluid_search_default$1];
	}
};
CDSFluidSearch = __decorate([carbonElement(`cds-custom-fluid-search`)], CDSFluidSearch);
var fluid_search_default = CDSFluidSearch;
//#endregion
export { fluid_search_default as default };

//# sourceMappingURL=fluid-search.js.map