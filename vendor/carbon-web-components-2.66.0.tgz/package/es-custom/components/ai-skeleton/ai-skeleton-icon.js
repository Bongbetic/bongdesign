/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import "../skeleton-icon/skeleton-icon.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ai-skeleton/ai-skeleton-icon.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton icon.
*
* @element cds-custom-ai-skeleton-icon
*/
let CDSAISkeletonIcon = class CDSAISkeletonIcon extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.customStyles = "";
	}
	render() {
		return html`<cds-custom-skeleton-icon
      class="${"cds-custom"}--skeleton__icon--ai"
      style="${this.customStyles}"></cds-custom-skeleton-icon>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
__decorate([property({ attribute: "custom-styles" })], CDSAISkeletonIcon.prototype, "customStyles", void 0);
CDSAISkeletonIcon = __decorate([carbonElement(`cds-custom-ai-skeleton-icon`)], CDSAISkeletonIcon);
var ai_skeleton_icon_default = CDSAISkeletonIcon;
//#endregion
export { ai_skeleton_icon_default as default };

//# sourceMappingURL=ai-skeleton-icon.js.map