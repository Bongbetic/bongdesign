/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import "../skeleton-placeholder/skeleton-placeholder.js";
import { LitElement, html } from "lit";
//#region src/components/ai-skeleton/ai-skeleton-placeholder.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton placeholder.
*
* @element cds-custom-ai-skeleton-placeholder
*/
let CDSAISkeletonPlaceholder = class CDSAISkeletonPlaceholder extends LitElement {
	render() {
		return html`<cds-custom-skeleton-placeholder
      exportparts="placeholder:skeleton-placeholder"
      optional-classes="${"cds-custom"}--skeleton__placeholder--ai"></cds-custom-skeleton-placeholder>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
CDSAISkeletonPlaceholder = __decorate([carbonElement(`cds-custom-ai-skeleton-placeholder`)], CDSAISkeletonPlaceholder);
var ai_skeleton_placeholder_default = CDSAISkeletonPlaceholder;
//#endregion
export { ai_skeleton_placeholder_default as default };

//# sourceMappingURL=ai-skeleton-placeholder.js.map