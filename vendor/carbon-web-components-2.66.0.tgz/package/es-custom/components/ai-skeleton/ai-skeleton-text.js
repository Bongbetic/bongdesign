/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../skeleton-text/skeleton-text.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ai-skeleton/ai-skeleton-text.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton text.
*
* @element cds-custom-ai-skeleton-text
*/
let CDSAISkeletonText = class CDSAISkeletonText extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.heading = false;
		this.width = "100%";
		this.paragraph = false;
		this.lineCount = 3;
	}
	render() {
		const { heading, width, lineCount, paragraph } = this;
		return html`<cds-custom-skeleton-text
      type="${heading ? "heading" : ""}"
      width="${width}"
      linecount="${lineCount}"
      ?paragraph="${paragraph}"
      optional-classes="${"cds-custom"}--skeleton__text--ai"></cds-custom-skeleton-text>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAISkeletonText.prototype, "heading", void 0);
__decorate([property({ reflect: true })], CDSAISkeletonText.prototype, "width", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAISkeletonText.prototype, "paragraph", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSAISkeletonText.prototype, "lineCount", void 0);
CDSAISkeletonText = __decorate([carbonElement(`cds-custom-ai-skeleton-text`)], CDSAISkeletonText);
var ai_skeleton_text_default = CDSAISkeletonText;
//#endregion
export { ai_skeleton_text_default as default };

//# sourceMappingURL=ai-skeleton-text.js.map