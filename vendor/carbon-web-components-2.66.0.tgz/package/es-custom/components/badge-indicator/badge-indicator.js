/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import badge_indicator_default$1 from "./badge-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/badge-indicator/badge-indicator.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Badge Indicator.
*
* @element cds-custom-badge-indicator
*/
let CDSBadgeIndicator = class CDSBadgeIndicator extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.slot = "badge-indicator";
	}
	render() {
		const displayCount = this.count && this.count > 999 ? "999+" : this.count;
		return html`${displayCount}`;
	}
	static {
		this.styles = badge_indicator_default$1;
	}
};
__decorate([property({ type: Number })], CDSBadgeIndicator.prototype, "count", void 0);
__decorate([property({ reflect: true })], CDSBadgeIndicator.prototype, "slot", void 0);
CDSBadgeIndicator = __decorate([carbonElement(`cds-custom-badge-indicator`)], CDSBadgeIndicator);
var badge_indicator_default = CDSBadgeIndicator;
//#endregion
export { badge_indicator_default as default };

//# sourceMappingURL=badge-indicator.js.map