/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import multi_select_default from "../multi-select/multi-select.js";
import fluid_multi_select_default$1 from "./fluid-multi-select.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-multi-select/fluid-multi-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid multi select.
*
* @element cds-custom-fluid-multi-select
*/
let CDSFluidMultiSelect = class CDSFluidMultiSelect extends multi_select_default {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	connectedCallback() {
		super.connectedCallback();
		this.isFluid = true;
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readonly") || changedProperties.has("warn")) this.requestUpdate();
	}
	render() {
		const wrapperClasses = classMap({
			[`cds-custom--multi-select__wrapper`]: true,
			[`cds-custom--list-box__wrapper`]: true,
			[`cds-custom--list-box__wrapper--fluid`]: true,
			[`cds-custom--list-box__wrapper--fluid--invalid`]: this.invalid
		});
		return html`<div class="${wrapperClasses}">${super.render()}</div>`;
	}
	static {
		this.styles = [multi_select_default.styles, fluid_multi_select_default$1];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidMultiSelect.prototype, "isCondensed", void 0);
CDSFluidMultiSelect = __decorate([carbonElement(`cds-custom-fluid-multi-select`)], CDSFluidMultiSelect);
var fluid_multi_select_default = CDSFluidMultiSelect;
//#endregion
export { fluid_multi_select_default as default };

//# sourceMappingURL=fluid-multi-select.js.map