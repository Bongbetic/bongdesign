/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_multi_select_default$1 from "../fluid-multi-select.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/fluid-multi-select/next/fluid-multi-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated preview of `cds-custom-fluid-multi-select`.
*
* Identical to `cds-custom-fluid-multi-select` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* Submits the same joined `value` string the v2 component does, so the wire
* format is unchanged.
*
* @element cds-custom-preview-fluid-multi-select
*/
let CDSPreviewFluidMultiSelect = class CDSPreviewFluidMultiSelect extends FormAssociatedMixin(fluid_multi_select_default$1) {
	static get is() {
		return `cds-custom-preview-fluid-multi-select`;
	}
};
CDSPreviewFluidMultiSelect = __decorate([carbonElement(`cds-custom-preview-fluid-multi-select`)], CDSPreviewFluidMultiSelect);
var fluid_multi_select_default = CDSPreviewFluidMultiSelect;
//#endregion
export { fluid_multi_select_default as default };

//# sourceMappingURL=fluid-multi-select.js.map