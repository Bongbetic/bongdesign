/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/page-header/context.ts
/**
* @license
*
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const pageHeaderContext = createContext({
	headerOffset: 0,
	breadcrumbOffset: 0,
	fullyCollapsed: false,
	root: null,
	titleClipped: false,
	contentActionsClipped: false,
	disableStickyTabBar: false,
	fullWidthGrid: false,
	narrowGrid: false
});
//#endregion
export { pageHeaderContext };

//# sourceMappingURL=context.js.map