/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "./page-header-content.js";
import "./page-header.js";
import "./page-header-breadcrumb.js";
import "./page-header-content-text.js";
import "./page-header-hero-image.js";
import "./page-header-tabs.js";
import "./page-header-title-breadcrumb.js";
import "./page-header-scroller.js";
import "./page-header-breadcrumbs-set/index.js";
import "./page-header-actions-set/index.js";
import "./page-header-tags-set/index.js";
//#region src/components/page-header/index.ts
/**
* @license
*
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
//#endregion

//# sourceMappingURL=index.js.map