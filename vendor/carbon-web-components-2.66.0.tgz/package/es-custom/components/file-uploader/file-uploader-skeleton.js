/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../skeleton-text/defs.js";
import "../skeleton-text/skeleton-text.js";
import "../button/button-skeleton.js";
import { LitElement, html } from "lit";
//#region src/components/file-uploader/file-uploader-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The File uploader skeleton.
*
* @element cds-custom-file-uploader-skeleton
*/
let CDSFileUploaderSkeleton = class CDSFileUploaderSkeleton extends LitElement {
	render() {
		return html`
      <cds-custom-skeleton-text
        type="${"heading"}"
        width="100px"></cds-custom-skeleton-text>
      <cds-custom-skeleton-text width="225px"></cds-custom-skeleton-text>
      <cds-custom-button-skeleton></cds-custom-button-skeleton>
    `;
	}
};
CDSFileUploaderSkeleton = __decorate([carbonElement(`cds-custom-file-uploader-skeleton`)], CDSFileUploaderSkeleton);
var file_uploader_skeleton_default = CDSFileUploaderSkeleton;
//#endregion
export { file_uploader_skeleton_default as default };

//# sourceMappingURL=file-uploader-skeleton.js.map