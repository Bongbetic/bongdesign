/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import number_input_default from "../number-input/number-input.js";
import fluid_number_input_default$1 from "./fluid-number-input.scss.js";
import { html } from "lit";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-number-input/fluid-number-input.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid number input.
*
* @element cds-custom-fluid-number-input
*/
let CDSFluidNumberInput = class CDSFluidNumberInput extends number_input_default {
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
	}
	render() {
		const wrapperClasses = classMap({
			[`cds-custom--number-input--fluid`]: true,
			[`cds-custom--number-input--fluid--invalid`]: this.invalid,
			[`cds-custom--number-input--fluid--warning`]: this.warn && !this.invalid,
			[`cds-custom--number-input--fluid--disabled`]: this.disabled,
			[`cds-custom--number-input--fluid--readonly`]: this.readonly
		});
		return html`<div class="${wrapperClasses}">${super.render()}</div>`;
	}
	static {
		this.styles = [number_input_default.styles, fluid_number_input_default$1];
	}
};
CDSFluidNumberInput = __decorate([carbonElement(`cds-custom-fluid-number-input`)], CDSFluidNumberInput);
var fluid_number_input_default = CDSFluidNumberInput;
//#endregion
export { fluid_number_input_default as default };

//# sourceMappingURL=fluid-number-input.js.map