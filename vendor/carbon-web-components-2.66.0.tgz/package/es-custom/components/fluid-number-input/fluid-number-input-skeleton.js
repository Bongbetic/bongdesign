/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import number_input_skeleton_default from "../number-input/number-input-skeleton.js";
import fluid_number_input_default from "./fluid-number-input.scss.js";
import { html } from "lit";
//#region src/components/fluid-number-input/fluid-number-input-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid number input.
*
* @element cds-custom-fluid-number-input-skeleton
*/
let CDSFluidNumberInputSkeleton = class CDSFluidNumberInputSkeleton extends number_input_skeleton_default {
	render() {
		return html` ${super.render()} `;
	}
	static {
		this.styles = [number_input_skeleton_default.styles, fluid_number_input_default];
	}
};
CDSFluidNumberInputSkeleton = __decorate([carbonElement(`cds-custom-fluid-number-input-skeleton`)], CDSFluidNumberInputSkeleton);
var fluid_number_input_skeleton_default = CDSFluidNumberInputSkeleton;
//#endregion
export { fluid_number_input_skeleton_default as default };

//# sourceMappingURL=fluid-number-input-skeleton.js.map