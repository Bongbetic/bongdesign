/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_password_input_default$1 from "./fluid-password-input.scss.js";
import password_input_default from "../password-input/password-input.js";
import { html } from "lit";
import { query } from "lit/decorators.js";
//#region src/components/fluid-password-input/fluid-password-input.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid password input.
*
* @element cds-custom-fluid-password-input
*/
let CDSFluidPasswordInput = class CDSFluidPasswordInput extends password_input_default {
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated() {
		super.updated();
		if (this._formItem) this._formItem.classList.add(`cds-custom--text-input--fluid`);
	}
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [password_input_default.styles, fluid_password_input_default$1];
	}
};
__decorate([query(`.cds-custom--form-item`)], CDSFluidPasswordInput.prototype, "_formItem", void 0);
CDSFluidPasswordInput = __decorate([carbonElement(`cds-custom-fluid-password-input`)], CDSFluidPasswordInput);
var fluid_password_input_default = CDSFluidPasswordInput;
//#endregion
export { fluid_password_input_default as default };

//# sourceMappingURL=fluid-password-input.js.map