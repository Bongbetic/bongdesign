/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "../button/button.scss.js";
import "../button/button.js";
import { CHAT_BUTTON_KIND, CHAT_BUTTON_SIZE } from "./defs.js";
import chat_button_default$1 from "./chat-button.scss.js";
import { LitElement, adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/chat-button/chat-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Chat Button
*
* @element cds-custom-chat-button
*
*/
let CDSChatButton = class CDSChatButton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._hasIcon = false;
		this.disabled = false;
		this.kind = "primary";
		this.size = "lg";
		this.isQuickAction = false;
		this.isSelected = false;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		this._hasIcon = target.assignedNodes().some((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim());
		this.requestUpdate();
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [button_default, chat_button_default$1]);
	}
	render() {
		const allowedSizes = [
			"sm",
			"md",
			"lg"
		];
		let kind = this.kind;
		let size = this.size;
		if (this.isQuickAction) {
			kind = "ghost";
			size = "sm";
		} else if (!allowedSizes.includes(size)) size = "lg";
		let classes = `cds-custom--chat-btn`;
		classes += this._hasIcon ? ` cds-custom--chat-btn--with-icon` : "";
		classes += this.isQuickAction ? ` cds-custom--chat-btn--quick-action` : "";
		classes += this.isSelected ? ` cds-custom--chat-btn--quick-action--selected` : "";
		return html`
      <cds-custom-button
        button-class-name="${classes}"
        size="${size}"
        kind="${kind}"
        ?disabled="${this.disabled}">
        <slot></slot
        ><slot
          name="icon"
          slot="icon"
          @slotchange="${this._handleSlotChange}"></slot>
      </cds-custom-button>
    `;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSChatButton.prototype, "disabled", void 0);
__decorate([property({ reflect: true })], CDSChatButton.prototype, "kind", void 0);
__decorate([property({ reflect: true })], CDSChatButton.prototype, "size", void 0);
__decorate([property({
	attribute: "is-quick-action",
	type: Boolean
})], CDSChatButton.prototype, "isQuickAction", void 0);
__decorate([property({
	attribute: "is-selected",
	type: Boolean
})], CDSChatButton.prototype, "isSelected", void 0);
CDSChatButton = __decorate([carbonElement(`cds-custom-chat-button`)], CDSChatButton);
var chat_button_default = CDSChatButton;
//#endregion
export { CHAT_BUTTON_KIND, CHAT_BUTTON_SIZE, chat_button_default as default };

//# sourceMappingURL=chat-button.js.map