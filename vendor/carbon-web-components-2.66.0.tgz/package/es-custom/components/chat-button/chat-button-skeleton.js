/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "../button/button.scss.js";
import { CHAT_BUTTON_SIZE } from "./defs.js";
import chat_button_default from "./chat-button.scss.js";
import { LitElement, adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/chat-button/chat-button-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Chat button skeleton.
*
* @element cds-custom-chat-button-skeleton
*/
let CDSChatButtonSkeleton = class CDSChatButtonSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.size = "lg";
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [button_default, chat_button_default]);
	}
	render() {
		const skeletonClasses = classMap({
			[`cds-custom--skeleton`]: true,
			[`cds-custom--btn`]: true,
			[`cds-custom--chat-btn`]: true,
			[`cds-custom--layout--size-${this.size}`]: this.size
		});
		return html` <div class="${skeletonClasses}"></div> `;
	}
};
__decorate([property({ reflect: true })], CDSChatButtonSkeleton.prototype, "size", void 0);
CDSChatButtonSkeleton = __decorate([carbonElement(`cds-custom-chat-button-skeleton`)], CDSChatButtonSkeleton);
var chat_button_skeleton_default = CDSChatButtonSkeleton;
//#endregion
export { CHAT_BUTTON_SIZE, chat_button_skeleton_default as default };

//# sourceMappingURL=chat-button-skeleton.js.map