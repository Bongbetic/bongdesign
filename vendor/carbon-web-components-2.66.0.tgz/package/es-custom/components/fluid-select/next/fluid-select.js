/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_select_default$1 from "../fluid-select.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/fluid-select/next/fluid-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated preview of `cds-custom-fluid-select`.
*
* Identical to `cds-custom-fluid-select` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* @element cds-custom-preview-fluid-select
*/
let CDSPreviewFluidSelect = class CDSPreviewFluidSelect extends FormAssociatedMixin(fluid_select_default$1) {
	static get is() {
		return `cds-custom-preview-fluid-select`;
	}
};
CDSPreviewFluidSelect = __decorate([carbonElement(`cds-custom-preview-fluid-select`)], CDSPreviewFluidSelect);
var fluid_select_default = CDSPreviewFluidSelect;
//#endregion
export { fluid_select_default as default };

//# sourceMappingURL=fluid-select.js.map