/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import select_default from "../select/select.js";
import fluid_select_default$1 from "./fluid-select.scss.js";
import { html } from "lit";
import { state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-select/fluid-select.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text select.
*
* @element cds-custom-fluid-select
*/
let CDSFluidSelect = class CDSFluidSelect extends select_default {
	constructor(..._args) {
		super(..._args);
		this._hasFocus = false;
		this._handleToggleTipLabelClick = (event) => {
			const path = event.composedPath();
			const hasLabel = path.some((node) => node instanceof HTMLLabelElement);
			const hasToggleTip = path.some((node) => node instanceof HTMLElement && (node.matches?.(`cds-custom-toggletip`) || node.classList.contains(`cds-custom--toggletip-button`)));
			if (hasLabel && hasToggleTip) event.preventDefault();
		};
		this._handleFocusIn = (event) => {
			if (event.target?.matches?.("select")) this._hasFocus = true;
		};
		this._handleFocusOut = (event) => {
			if (event.target?.matches?.("select")) this._hasFocus = false;
		};
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
		this.addEventListener("click", this._handleToggleTipLabelClick, { capture: true });
	}
	disconnectedCallback() {
		this.removeEventListener("click", this._handleToggleTipLabelClick, { capture: true });
		super.disconnectedCallback?.();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readonly") || changedProperties.has("warn")) this.requestUpdate();
	}
	render() {
		const wrapperClasses = classMap({
			[`cds-custom--select`]: true,
			[`cds-custom--select--invalid`]: this.invalid,
			[`cds-custom--select--warning`]: this.warn && !this.invalid,
			[`cds-custom--select--disabled`]: this.disabled,
			[`cds-custom--select--readonly`]: this.readonly,
			[`cds-custom--select--fluid--focus`]: this._hasFocus
		});
		return html`<div
      class="${wrapperClasses}"
      @focusin="${this._handleFocusIn}"
      @focusout="${this._handleFocusOut}">
      ${super.render()}
    </div>`;
	}
	static {
		this.styles = [select_default.styles, fluid_select_default$1];
	}
};
__decorate([state()], CDSFluidSelect.prototype, "_hasFocus", void 0);
CDSFluidSelect = __decorate([carbonElement(`cds-custom-fluid-select`)], CDSFluidSelect);
var fluid_select_default = CDSFluidSelect;
//#endregion
export { fluid_select_default as default };

//# sourceMappingURL=fluid-select.js.map