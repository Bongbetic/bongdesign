/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import select_skeleton_default from "../select/select-skeleton.js";
import fluid_select_default from "./fluid-select.scss.js";
import { html } from "lit";
//#region src/components/fluid-select/fluid-select-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-select-skeleton
*/
let CDSFluidSelectSkeleton = class CDSFluidSelectSkeleton extends select_skeleton_default {
	render() {
		return html`
      <div class="${"cds-custom"}--select--fluid__skeleton">${super.render()}</div>
    `;
	}
	static {
		this.styles = [select_skeleton_default.styles, fluid_select_default];
	}
};
CDSFluidSelectSkeleton = __decorate([carbonElement(`cds-custom-fluid-select-skeleton`)], CDSFluidSelectSkeleton);
var fluid_select_skeleton_default = CDSFluidSelectSkeleton;
//#endregion
export { fluid_select_skeleton_default as default };

//# sourceMappingURL=fluid-select-skeleton.js.map