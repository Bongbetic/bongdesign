/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import "../fluid-select/fluid-select-skeleton.js";
import "../fluid-text-input/fluid-text-input-skeleton.js";
import fluid_time_picker_default from "./fluid-time-picker.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-time-picker/fluid-time-picker-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid time picker skeleton.
*
* @element cds-custom-fluid-time-picker-skeleton
*/
let CDSFluidTimePickerSkeleton = class CDSFluidTimePickerSkeleton extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.isOnlyTwo = false;
	}
	render() {
		const wrapperClasses = classMap({
			[`cds-custom--time-picker--fluid--skeleton`]: true,
			[`cds-custom--time-picker--equal-width`]: this.isOnlyTwo
		});
		return html`
      <div class="${wrapperClasses}">
        <cds-custom-fluid-text-input-skeleton></cds-custom-fluid-text-input-skeleton>
        <cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>
        ${this.isOnlyTwo ? null : html`<cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>`}
      </div>
    `;
	}
	static {
		this.styles = fluid_time_picker_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "is-only-two",
	reflect: true
})], CDSFluidTimePickerSkeleton.prototype, "isOnlyTwo", void 0);
CDSFluidTimePickerSkeleton = __decorate([carbonElement(`cds-custom-fluid-time-picker-skeleton`)], CDSFluidTimePickerSkeleton);
var fluid_time_picker_skeleton_default = CDSFluidTimePickerSkeleton;
//#endregion
export { fluid_time_picker_skeleton_default as default };

//# sourceMappingURL=fluid-time-picker-skeleton.js.map