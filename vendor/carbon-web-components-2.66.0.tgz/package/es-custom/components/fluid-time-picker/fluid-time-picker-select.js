/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_select_default from "../fluid-select/fluid-select.js";
import fluid_time_picker_default from "./fluid-time-picker.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/fluid-time-picker/fluid-time-picker-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid time picker select.
*
* @element cds-custom-fluid-time-picker-select
*/
let CDSFluidTimePickerSelect = class CDSFluidTimePickerSelect extends fluid_select_default {
	constructor(..._args) {
		super(..._args);
		this.defaultValue = "";
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("defaultValue") && this.defaultValue && !this.value) this.value = this.defaultValue;
	}
	static {
		this.styles = [...fluid_select_default.styles, fluid_time_picker_default];
	}
};
__decorate([property({ attribute: "default-value" })], CDSFluidTimePickerSelect.prototype, "defaultValue", void 0);
CDSFluidTimePickerSelect = __decorate([carbonElement(`cds-custom-fluid-time-picker-select`)], CDSFluidTimePickerSelect);
var fluid_time_picker_select_default = CDSFluidTimePickerSelect;
//#endregion
export { fluid_time_picker_select_default as default };

//# sourceMappingURL=fluid-time-picker-select.js.map