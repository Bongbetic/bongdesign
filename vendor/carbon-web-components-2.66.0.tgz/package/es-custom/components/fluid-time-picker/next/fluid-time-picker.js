/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/settings.js";
import { carbonElement } from "../../../globals/decorators/carbon-element.js";
import __decorate from "../../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import fluid_time_picker_default$1 from "../fluid-time-picker.js";
import FormAssociatedMixin from "../../../globals/mixins/form-associated.js";
//#region src/components/fluid-time-picker/next/fluid-time-picker.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A form-associated preview of `cds-custom-fluid-time-picker`.
*
* Identical to `cds-custom-fluid-time-picker` in markup, styling and events. The only
* difference is that it participates in its form natively through
* `ElementInternals` instead of the deprecated `formdata` event, so
* `<label for>`, `form.elements`, `form.reset()` and `<fieldset disabled>` all
* work as they do for a native control.
*
* @element cds-custom-preview-fluid-time-picker
*/
let CDSPreviewFluidTimePicker = class CDSPreviewFluidTimePicker extends FormAssociatedMixin(fluid_time_picker_default$1) {
	static get is() {
		return `cds-custom-preview-fluid-time-picker`;
	}
};
CDSPreviewFluidTimePicker = __decorate([carbonElement(`cds-custom-preview-fluid-time-picker`)], CDSPreviewFluidTimePicker);
var fluid_time_picker_default = CDSPreviewFluidTimePicker;
//#endregion
export { fluid_time_picker_default as default };

//# sourceMappingURL=fluid-time-picker.js.map