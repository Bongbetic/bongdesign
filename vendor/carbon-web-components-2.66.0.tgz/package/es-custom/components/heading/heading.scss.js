/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/heading/heading.scss?lit
var heading_default = css([":host(cds-custom-heading){display:block}:host(cds-custom-heading) h1,:host(cds-custom-heading) h2,:host(cds-custom-heading) h3,:host(cds-custom-heading) h4,:host(cds-custom-heading) h5,:host(cds-custom-heading) h6{margin-block-end:0;margin-block-start:0;margin-inline-end:0;margin-inline-start:0;unicode-bidi:-webkit-isolate;unicode-bidi:-moz-isolate;unicode-bidi:isolate}:host(cds-custom-heading) h1{font-size:var(--cds-heading-06-font-size,2.625rem);font-weight:var(--cds-heading-06-font-weight,300);line-height:var(--cds-heading-06-line-height,1.199);letter-spacing:var(--cds-heading-06-letter-spacing,0)}:host(cds-custom-heading) h2{font-size:var(--cds-heading-05-font-size,2rem);font-weight:var(--cds-heading-05-font-weight,400);line-height:var(--cds-heading-05-line-height,1.25);letter-spacing:var(--cds-heading-05-letter-spacing,0)}:host(cds-custom-heading) h3{font-size:var(--cds-heading-04-font-size,1.75rem);font-weight:var(--cds-heading-04-font-weight,400);line-height:var(--cds-heading-04-line-height,1.28572);letter-spacing:var(--cds-heading-04-letter-spacing,0)}:host(cds-custom-heading) h4{font-size:var(--cds-heading-03-font-size,1.25rem);font-weight:var(--cds-heading-03-font-weight,400);line-height:var(--cds-heading-03-line-height,1.4);letter-spacing:var(--cds-heading-03-letter-spacing,0)}:host(cds-custom-heading) h5{font-size:var(--cds-heading-02-font-size,1rem);font-weight:var(--cds-heading-02-font-weight,600);line-height:var(--cds-heading-02-line-height,1.5);letter-spacing:var(--cds-heading-02-letter-spacing,0)}:host(cds-custom-heading) h6{font-size:var(--cds-heading-01-font-size,.875rem);font-weight:var(--cds-heading-01-font-weight,600);line-height:var(--cds-heading-01-line-height,1.42857);letter-spacing:var(--cds-heading-01-letter-spacing,.16px)}"]);
//#endregion
export { heading_default as default };

//# sourceMappingURL=heading.scss.js.map