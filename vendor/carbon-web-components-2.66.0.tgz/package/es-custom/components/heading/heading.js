/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import heading_default$1 from "./heading.scss.js";
import { LitElement, html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { unsafeHTML } from "lit/directives/unsafe-html.js";
//#region src/components/heading/heading.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
let CDSSection = class CDSSection extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._currentLevel = 1;
	}
	getParentLevel() {
		const parentSection = this.parentElement?.closest(`cds-custom-section`);
		return parentSection ? parentSection.getCurrentLevel() : 1;
	}
	connectedCallback() {
		super.connectedCallback();
		const parentLevel = this.getParentLevel();
		this._currentLevel = this.level ?? Math.min(parentLevel + 1, 6);
	}
	getCurrentLevel() {
		return this._currentLevel;
	}
	render() {
		return html`<slot></slot>`;
	}
};
__decorate([property({ type: Number })], CDSSection.prototype, "level", void 0);
CDSSection = __decorate([customElement(`cds-custom-section`)], CDSSection);
/**
* The heading component
*
* @element cds-custom-heading
*/
let CDSHeading = class CDSHeading extends LitElement {
	constructor(..._args2) {
		super(..._args2);
		this._level = 1;
	}
	connectedCallback() {
		super.connectedCallback();
		const section = this.closest(`cds-custom-section`);
		this._level = section ? section.getCurrentLevel() : 1;
	}
	render() {
		const headingElement = `
      <h${this._level}>
        <slot></slot>
      </h${this._level}>
    `;
		return html`${unsafeHTML(headingElement)}`;
	}
	static {
		this.styles = heading_default$1;
	}
};
CDSHeading = __decorate([customElement(`cds-custom-heading`)], CDSHeading);
var heading_default = CDSHeading;
//#endregion
export { CDSSection, heading_default as default };

//# sourceMappingURL=heading.js.map