/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { FeatureFlags, createScope, notifyAvailableFlag } from "../../packages/feature-flags/es/index.js";
import { LitElement, html } from "lit";
//#region src/components/feature-flags/index.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* <feature-flags> provides scoped feature flags to child components.
*
* Usage:
* Wrap any child components inside <feature-flags> to provide scoped feature flags like this:
* <feature-flags enable-dialog-element="true">
*   <component></component>
* </feature-flags>
*
* The supported flags are documented as `@attr` tags on `FeatureFlagsElement`
* below, which is also what surfaces them in `custom-elements.json`.
*
* How to check a Flag in your component:
*   import { isFeatureFlagEnabled } from './feature-flags';
*   isFeatureFlagEnabled('enable-dialog-element', this)
*   Returns true if the flag is enabled in the nearest <feature-flags> ancestor
*/
var _FeatureFlagsElement;
const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
/**
* Feature Flags
*
* Provides scoped feature flags to child components. Flags are read from the
* nearest `<feature-flags>` ancestor, and nested elements inherit any flag they
* do not set themselves.
*
* Attributes are declared below rather than inferred, because the flag list is
* built at runtime from `observedAttributes` and cannot be read statically.
*
* @element feature-flags
*
* @attr {boolean} enable-v12-release - Enable the features and functionality
* for the v12 Release. Enabling this turns on every `enable-v12-*` flag at
* once, as well as `enable-focus-wrap-without-sentinels`.
* @attr {boolean} enable-v12-tile-default-icons - Enable rendering of default
* icons in the tile components. Becomes the default behavior in v12.
* @attr {boolean} enable-v12-tile-radio-icons - Enable rendering of radio icons
* in the `cds-custom-radio-tile` component. Becomes the default behavior in v12.
* @attr {boolean} enable-v12-overflowmenu - Enable the use of the v12
* `cds-custom-overflow-menu` leveraging the menu subcomponents. Becomes the default
* behavior in v12.
* @attr {boolean} enable-v12-dynamic-floating-styles - Enable dynamic setting
* of floating styles for components like `cds-custom-popover`, `cds-custom-tooltip`, etc.
* Becomes the default behavior in v12.
* @attr {boolean} enable-v12-autoalign - Enable `autoalign` by default for
* components that support it, like `cds-custom-popover`, `cds-custom-tooltip`, etc. An
* explicit `autoalign` attribute or property always takes precedence. A
* component reads this flag once, when it connects, so changing the flag later
* does not affect components that are already on the page. Becomes the default
* behavior in v12.
* @attr {boolean} enable-v12-toggle-reduced-label-spacing - Enable a reduced
* spacing between the toggle control and its label. Becomes the default
* behavior in v12.
* @attr {boolean} enable-treeview-controllable - Enable the new `cds-custom-treeview`
* controllable API.
* @attr {boolean} enable-dialog-element - Enable components to utilize the
* native `dialog` element.
* @attr {boolean} enable-focus-wrap-without-sentinels - Enable the new focus
* wrap behavior that doesn't use sentinel nodes.
* @attr {boolean} enable-experimental-focus-wrap-without-sentinels - Deprecated,
* use `enable-focus-wrap-without-sentinels` instead.
*/
let FeatureFlagsElement = class FeatureFlagsElement extends LitElement {
	static {
		_FeatureFlagsElement = this;
	}
	static {
		this.flagComponentMap = {
			"enable-v12-release": null,
			"enable-v12-tile-default-icons": "CDS-CLICKABLE-TILE",
			"enable-v12-tile-radio-icons": "CDS-TILE",
			"enable-v12-overflowmenu": "CDS-OVERFLOW-MENU",
			"enable-treeview-controllable": "CDS-TREEVIEW",
			"enable-experimental-focus-wrap-without-sentinels": "CDS-FOCUS-WRAP",
			"enable-focus-wrap-without-sentinels": "CDS-FOCUS-WRAP",
			"enable-dialog-element": "CDS-MODAL",
			"enable-v12-dynamic-floating-styles": "CDS-FLOATING",
			"enable-v12-autoalign": null,
			"enable-v12-toggle-reduced-label-spacing": "CDS-TOGGLE"
		};
	}
	static get observedAttributes() {
		return Object.keys(_FeatureFlagsElement.flagComponentMap);
	}
	constructor() {
		super();
		this.scope = FeatureFlags;
		this.flags = {};
		this.attachShadow({ mode: "open" });
	}
	connectedCallback() {
		super.connectedCallback();
		this.updateScope();
	}
	attributeChangedCallback(name, _oldVal, newVal) {
		const value = newVal !== null && newVal !== "false";
		this.flags[name] = value;
		const relatedComponent = hasOwn(_FeatureFlagsElement.flagComponentMap, name) ? _FeatureFlagsElement.flagComponentMap[name] : null;
		if (relatedComponent && this.firstElementChild?.tagName === relatedComponent) this.firstElementChild.setAttribute(name, "");
		this.updateScope();
	}
	syncFeatureFlagAttributes() {
		for (const [flag, relatedComponent] of Object.entries(_FeatureFlagsElement.flagComponentMap)) {
			if (!relatedComponent) continue;
			let isEnabled = false;
			try {
				isEnabled = this.scope.enabled(flag);
			} catch {
				isEnabled = false;
			}
			for (const element of this.querySelectorAll(relatedComponent.toLowerCase())) {
				if (findParentFeatureFlags(element) !== this) continue;
				if (isEnabled) element.setAttribute(flag, "");
				else element.removeAttribute(flag);
			}
		}
	}
	getParentFeatureFlagsElement() {
		let parent = this.parentNode;
		while (parent) {
			if (parent instanceof ShadowRoot) {
				parent = parent.host;
				continue;
			}
			if (parent instanceof _FeatureFlagsElement) return parent;
			parent = parent.parentNode;
		}
		return null;
	}
	getParentScope() {
		return this.getParentFeatureFlagsElement()?.getScope() ?? null;
	}
	syncChildFeatureFlagScopes() {
		for (const element of this.querySelectorAll("feature-flags")) if (element instanceof _FeatureFlagsElement && element.getParentFeatureFlagsElement() === this) element.updateScope();
	}
	updateScope() {
		const newScope = createScope(this.flags);
		const parentScope = this.getParentScope() || FeatureFlags;
		if (parentScope) newScope.mergeWithScope(parentScope);
		this.scope = newScope;
		this.syncFeatureFlagAttributes();
		this.syncChildFeatureFlagScopes();
	}
	render() {
		return html` <slot></slot> `;
	}
	isFeatureFlagEnabled(flag) {
		return this.scope.enabled(flag);
	}
	getScope() {
		return this.scope;
	}
};
FeatureFlagsElement = _FeatureFlagsElement = __decorate([carbonElement("feature-flags")], FeatureFlagsElement);
var feature_flags_default = FeatureFlagsElement;
function findParentFeatureFlags(el) {
	let parent = el.parentNode;
	while (parent) {
		if (parent instanceof ShadowRoot) {
			parent = parent.host;
			continue;
		}
		if (parent instanceof FeatureFlagsElement) return parent;
		parent = parent.parentNode;
	}
	return null;
}
function isFeatureFlagEnabled(flag, context) {
	const enabled = findParentFeatureFlags(context)?.isFeatureFlagEnabled(flag) ?? FeatureFlags.enabled(flag);
	notifyAvailableFlag(flag, enabled);
	return enabled;
}
//#endregion
export { feature_flags_default as default, findParentFeatureFlags, isFeatureFlagEnabled };

//# sourceMappingURL=index.js.map