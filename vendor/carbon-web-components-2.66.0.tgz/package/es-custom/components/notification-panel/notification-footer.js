/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { selectorTabbable } from "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import notification_footer_default$1 from "./notification-footer.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import Settings16 from "@carbon/icons/es/settings/16";
//#region src/components/notification-panel/notification-footer.ts
/**
* Copyright IBM Corp. 2023, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const blockClass = `cds-custom--notifications-panel`;
/**
* Notification Footer.
*
* @element cds-custom-notification-footer
* @csspart dialog The dialog.
* @fires cds-custom-notification-view-all
*   The custom event is fired when a user clicks on View All button.
* @fires cds-custom-notification-settings - The custom event is fired when User clicks on settings button.
*/
let CDSNotificationFooter = class CDSNotificationFooter extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.viewAllLabel = "View All";
	}
	render() {
		const { viewAllLabel, _viewAllNotification: viewAllNotification, _onClickSettings: onClickSettings } = this;
		return html`
      <cds-custom-button
        kind="ghost"
        class="${blockClass}__view-all-button"
        @click=${viewAllNotification}>
        ${viewAllLabel}
      </cds-custom-button>
      <cds-custom-button
        kind="ghost"
        size="sm"
        tooltip-text="Settings"
        class="${blockClass}__settings-button"
        @click=${onClickSettings}>
        ${iconLoader(Settings16, { slot: "icon" })}
      </cds-custom-button>
    `;
	}
	_viewAllNotification(event) {
		const triggeredBy = event.target;
		event.stopPropagation();
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { triggeredBy }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.notificationViewAll, init));
	}
	_onClickSettings(event) {
		const triggeredBy = event.target;
		event.stopPropagation();
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { triggeredBy }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.notificationSettings, init));
	}
	/**
	* A selector selecting tabbable nodes.
	*/
	static get selectorTabbable() {
		return selectorTabbable;
	}
	/**
	* The custom event is fired when a notification is clicked or when the Enter key is pressed on it.
	*/
	static get notificationViewAll() {
		return `cds-custom-notification-view-all`;
	}
	/**
	* The custom event is fired when the notification is closed by a user gesture.
	*/
	static get notificationSettings() {
		return `cds-custom-notification-settings`;
	}
	static {
		this.styles = notification_footer_default$1;
	}
};
__decorate([property({
	reflect: true,
	type: String,
	attribute: "view-all-label"
})], CDSNotificationFooter.prototype, "viewAllLabel", void 0);
CDSNotificationFooter = __decorate([carbonElement(`cds-custom-notification-footer`)], CDSNotificationFooter);
var notification_footer_default = CDSNotificationFooter;
//#endregion
export { notification_footer_default as default };

//# sourceMappingURL=notification-footer.js.map