/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/notification-panel/date-time-context.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const dateTimeLocaleContext = createContext("dateTimeLocale");
//#endregion
export { dateTimeLocaleContext };

//# sourceMappingURL=date-time-context.js.map