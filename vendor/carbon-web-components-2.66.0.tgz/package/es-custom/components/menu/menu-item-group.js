/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import menu_item_default from "./menu-item.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/menu/menu-item-group.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu Item.
*
* @element cds-custom-menu-item-group
*/
let CDSmenuItemGroup = class CDSmenuItemGroup extends LitElement {
	render() {
		const { label } = this;
		return html`
      <ul role="group" aria-label="${label}">
        <slot></slot>
      </ul>
    `;
	}
	static {
		this.styles = menu_item_default;
	}
};
__decorate([property({ type: String })], CDSmenuItemGroup.prototype, "label", void 0);
CDSmenuItemGroup = __decorate([carbonElement(`cds-custom-menu-item-group`)], CDSmenuItemGroup);
var menu_item_group_default = CDSmenuItemGroup;
//#endregion
export { menu_item_group_default as default };

//# sourceMappingURL=menu-item-group.js.map