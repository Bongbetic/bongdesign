/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import { MenuContext } from "./menu-context.js";
import menu_item_default from "./menu-item.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { consume } from "@lit/context";
//#region src/components/menu/menu-item-radio-group.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu Item.
*
* @element cds-custom-menu-item-radio-group
*/
let CDSmenuItemRadioGroup = class CDSmenuItemRadioGroup extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.items = [];
	}
	/**
	* The name of the custom event fired when the selection state changes.
	*/
	static get eventOnChange() {
		return `cds-custom-item-changed`;
	}
	firstUpdated() {
		this.context.updateFromChild({ hasSelectableItems: true });
		this.addEventListener(`click`, (e) => {
			this.selectedItem = e.target;
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: { triggeredBy: e.target }
			};
			if (this.dispatchEvent(new CustomEvent(this.constructor.eventOnChange, init))) this.dispatchEvent(new CustomEvent(this.constructor.eventOnChange, init));
		});
	}
	updated(_changedProperties) {
		if (_changedProperties.has("selectedItem")) this.querySelectorAll(`cds-custom-menu-item`).forEach((item) => {
			if (item === this.selectedItem) item.setAttribute("aria-checked", "true");
			else item.setAttribute("aria-checked", "false");
		});
	}
	render() {
		const { label } = this;
		return html`
      <ul role="group" aria-label="${label}">
        <slot></slot>
      </ul>
    `;
	}
	static {
		this.styles = menu_item_default;
	}
};
__decorate([consume({ context: MenuContext })], CDSmenuItemRadioGroup.prototype, "context", void 0);
__decorate([property({ type: String })], CDSmenuItemRadioGroup.prototype, "label", void 0);
__decorate([property({ type: Array })], CDSmenuItemRadioGroup.prototype, "items", void 0);
__decorate([property({
	type: String,
	attribute: true
})], CDSmenuItemRadioGroup.prototype, "selectedItem", void 0);
__decorate([property()], CDSmenuItemRadioGroup.prototype, "itemToString", void 0);
CDSmenuItemRadioGroup = __decorate([carbonElement(`cds-custom-menu-item-radio-group`)], CDSmenuItemRadioGroup);
var menu_item_radio_group_default = CDSmenuItemRadioGroup;
//#endregion
export { menu_item_radio_group_default as default };

//# sourceMappingURL=menu-item-radio-group.js.map