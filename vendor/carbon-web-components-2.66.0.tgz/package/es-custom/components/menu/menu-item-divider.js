/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import menu_item_default from "./menu-item.scss.js";
import { LitElement } from "lit";
//#region src/components/menu/menu-item-divider.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu Item.
*
* @element cds-custom-menu-item-divider
*/
let CDSmenuItemDivider = class CDSmenuItemDivider extends LitElement {
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "separator");
		super.connectedCallback();
	}
	static {
		this.styles = menu_item_default;
	}
};
CDSmenuItemDivider = __decorate([carbonElement(`cds-custom-menu-item-divider`)], CDSmenuItemDivider);
var menu_item_divider_default = CDSmenuItemDivider;
//#endregion
export { menu_item_divider_default as default };

//# sourceMappingURL=menu-item-divider.js.map