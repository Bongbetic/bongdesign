/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import iconLoader from "../../../globals/internal/icon-loader.js";
import "../../button/defs.js";
import "../../breadcrumb/index.js";
import "../../notification/index.js";
import story_styles_default from "../story-styles.scss.js";
import { html } from "lit";
import Settings16 from "@carbon/icons/es/settings/16";
import TrashCan16 from "@carbon/icons/es/trash-can/16";
//#region src/components/side-panel/_story-assets/index.ts
/**
* Copyright IBM Corp. 2024, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const storyPrefix = "side-panel-stories__";
const getContent = (index) => {
	switch (index) {
		case 1: return html`
        <style>
          ${story_styles_default}
        </style>
        <h5>Section</h5>
        <cds-custom-text-input
          label="Input A"
          id="side-panel-story-text-input-a"
          class="${storyPrefix}text-input"></cds-custom-text-input>
        <cds-custom-text-input
          label="Input B"
          id="side-panel-story-text-input-b"
          class="${storyPrefix}text-input"></cds-custom-text-input>
      `;
		case 2: return html`
        <style>
          ${story_styles_default}
        </style>
        <h5>Section</h5>
        <div class="${storyPrefix}text-inputs">
          <cds-custom-text-input
            label="Input A"
            id="side-panel-story-text-input-a"></cds-custom-text-input>
          <cds-custom-text-input
            label="Input B"
            id="side-panel-story-text-input-b"></cds-custom-text-input>
        </div>
        <div class="${storyPrefix}text-inputs">
          <cds-custom-text-input
            label="Input C"
            id="side-panel-story-text-input-c"></cds-custom-text-input>
          <cds-custom-text-input
            label="Input D"
            id="side-panel-story-text-input-d"></cds-custom-text-input>
        </div>
        <div class="${storyPrefix}textarea-container">
          <cds-custom-textarea
            label="Notes"
            value="This is a text area"></cds-custom-textarea>
          <cds-custom-textarea
            label="Notes"
            value="This is a text area"></cds-custom-textarea>
          <cds-custom-textarea
            label="Notes"
            value="This is a text area"></cds-custom-textarea>
        </div>
      `;
		default: return null;
	}
};
const getSubTitle = (index) => {
	switch (index) {
		case 1: return html`<div slot="subtitle">This is your subtitle slot.</div>`;
		case 2: return html`<div slot="subtitle">
        I am your subtitle slot for <strong>adding detail</strong> that can be
        one or two lines.
      </div>`;
		default: return null;
	}
};
const getActionToolbarItems = (index) => {
	switch (index) {
		case 1: return html`
        <cds-custom-button slot="action-toolbar">Copy</cds-custom-button>
        <cds-custom-button
          slot="action-toolbar"
          aria-label="Settings"
          has-icon-only="true"
          kind=${"ghost"}
          size="sm"
          tooltip-text="Settings">
          ${iconLoader(Settings16, { slot: "icon" })}
        </cds-custom-button>
        <cds-custom-button
          slot="action-toolbar"
          aria-label="Delete"
          has-icon-only="true"
          kind=${"ghost"}
          size="sm"
          tooltip-text="Delete">
          ${iconLoader(TrashCan16, { slot: "icon" })}
        </cds-custom-button>
      `;
		default: return null;
	}
};
const getActionItems = (index) => {
	switch (index) {
		case 1: return html`<cds-custom-button slot="actions" kind=${"primary"}
        >Primary</cds-custom-button
      >`;
		case 2: return html`<cds-custom-button slot="actions" kind=${"ghost"}
        >Ghost</cds-custom-button
      >`;
		case 3: return html`<cds-custom-button slot="actions" kind=${"danger"}
        >Danger</cds-custom-button
      >`;
		case 4: return html`
        <cds-custom-button slot="actions" kind=${"secondary"}
          >Secondary</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >
      `;
		case 5: return html`
        <cds-custom-button slot="actions" kind=${"ghost"}>Ghost</cds-custom-button>
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >
      `;
		case 6: return html`<cds-custom-button slot="actions" kind=${"danger"}
          >Danger</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >`;
		case 7: return html`<cds-custom-button slot="actions" kind=${"ghost"}
          >Ghost</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"secondary"}
          >Secondary</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >`;
		case 8: return html`<cds-custom-button slot="actions" kind=${"danger"}
          >Danger</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"secondary"}
          >Secondary</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >`;
		case 9: return html`<cds-custom-button slot="actions" kind=${"secondary"}
          >Secondary</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"secondary"}
          >Secondary</cds-custom-button
        >
        <cds-custom-button slot="actions" kind=${"primary"}
          >Primary</cds-custom-button
        >`;
		default: return null;
	}
};
const getSlug = (index) => {
	switch (index) {
		case 1: return html`<cds-custom-slug size="xs" alignment="bottom-right">
        <div slot="body-text">
          <p class="secondary">AI Explained</p>
          <h1>84%</h1>
          <p class="secondary bold">Confidence score</p>
          <!-- //cspell: disable -->
          <p class="secondary">
            Lorem ipsum dolor sit amet, di os consectetur adipiscing elit, sed
            do eiusmod tempor incididunt ut fsil labore et dolore magna aliqua.
          </p>
          <!-- //cspell: enable -->
          <hr />
          <p class="secondary">Model type</p>
          <p class="bold">Foundation model</p>
        </div>
      </cds-custom-slug>`;
		default: return null;
	}
};
const getCustomHeaderComponents = (index) => {
	switch (index) {
		case 1: return html` <style>
          ${story_styles_default}
        </style>
        <div slot="above-title" class="${storyPrefix}custom-header-content">
          <cds-custom-breadcrumb aria-label="">
            <cds-custom-breadcrumb-item>
              <cds-custom-breadcrumb-link href="#">Breadcrumb 1</cds-custom-breadcrumb-link>
            </cds-custom-breadcrumb-item>
            <cds-custom-breadcrumb-item>
              <cds-custom-breadcrumb-link href="#">Breadcrumb 2</cds-custom-breadcrumb-link>
            </cds-custom-breadcrumb-item>
          </cds-custom-breadcrumb>
        </div>`;
		case 2: return html` <style>
          ${story_styles_default}
        </style>
        <div slot="below-title" class="${storyPrefix}custom-header-content">
          <cds-custom-inline-notification
            title="Notification title"
            subtitle="Subtitle text goes here"
            kind="error">
          </cds-custom-inline-notification>
        </div>`;
		case 3: return html` <style>
          ${story_styles_default}
        </style>
        <div slot="above-title" class="${storyPrefix}custom-header-content">
          <cds-custom-breadcrumb aria-label="">
            <cds-custom-breadcrumb-item>
              <cds-custom-breadcrumb-link href="#">Breadcrumb 1</cds-custom-breadcrumb-link>
            </cds-custom-breadcrumb-item>
            <cds-custom-breadcrumb-item>
              <cds-custom-breadcrumb-link href="#">Breadcrumb 2</cds-custom-breadcrumb-link>
            </cds-custom-breadcrumb-item>
          </cds-custom-breadcrumb>
        </div>

        <div slot="below-title" class="${storyPrefix}custom-header-content">
          <cds-custom-inline-notification
            title="Notification title"
            subtitle="Subtitle text goes here"
            kind="error">
          </cds-custom-inline-notification>
        </div>`;
		default: return null;
	}
};
//#endregion
export { getActionItems, getActionToolbarItems, getContent, getCustomHeaderComponents, getSlug, getSubTitle };

//# sourceMappingURL=index.js.map