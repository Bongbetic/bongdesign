/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/side-panel/defs.ts
/**
* @license
*
* Copyright IBM Corp. 2023, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal size.
*/
let SIDE_PANEL_SIZE = /* @__PURE__ */ function(SIDE_PANEL_SIZE) {
	/**
	* Extra small size.
	*/
	SIDE_PANEL_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	SIDE_PANEL_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	SIDE_PANEL_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	SIDE_PANEL_SIZE["LARGE"] = "lg";
	/**
	* Extra Large size.
	*/
	SIDE_PANEL_SIZE["EXTRA_LARGE"] = "xl";
	/**
	* 2X-Large size.
	*/
	SIDE_PANEL_SIZE["EXTRA_EXTRA_LARGE"] = "2xl";
	return SIDE_PANEL_SIZE;
}({});
let SIDE_PANEL_PLACEMENT = /* @__PURE__ */ function(SIDE_PANEL_PLACEMENT) {
	/** right / default */
	SIDE_PANEL_PLACEMENT["RIGHT"] = "right";
	/** left  */
	SIDE_PANEL_PLACEMENT["LEFT"] = "left";
	return SIDE_PANEL_PLACEMENT;
}({});
//#endregion
export { SIDE_PANEL_PLACEMENT, SIDE_PANEL_SIZE };

//# sourceMappingURL=defs.js.map