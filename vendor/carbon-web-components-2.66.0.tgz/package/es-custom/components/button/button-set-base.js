/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "./button.scss.js";
import { LitElement, html } from "lit";
//#region src/components/button/button-set-base.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Button set without button checks
*
* @element cds-custom-button-set-base
*/
let CDSButtonSetBase = class CDSButtonSetBase extends LitElement {
	render() {
		return html`<slot></slot>`;
	}
	connectedCallback() {
		super.connectedCallback();
		this.setAttribute("role", "list");
	}
	static {
		this.styles = button_default;
	}
};
CDSButtonSetBase = __decorate([carbonElement(`cds-custom-button-set-base`)], CDSButtonSetBase);
var button_set_base_default = CDSButtonSetBase;
//#endregion
export { button_set_base_default as default };

//# sourceMappingURL=button-set-base.js.map