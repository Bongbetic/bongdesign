/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "./button.scss.js";
import button_default$1 from "./button.js";
import { html } from "lit";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/button/button-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Button skeleton.
*/
let CDSButtonSkeleton = class CDSButtonSkeleton extends button_default$1 {
	/**
	* Handles `click` event on the `<a>.
	*
	* @param event The event.
	*/
	_handleClickLinkSkeleton(event) {
		if (this.disabled) {
			event.preventDefault();
			event.stopPropagation();
		}
	}
	render() {
		const { autofocus, disabled, download, href, hreflang, ping, rel, size, target, type } = this;
		const classes = classMap({
			[`cds-custom--btn`]: true,
			[`cds-custom--skeleton`]: true,
			[`cds-custom--btn--${size}`]: !!size,
			[`cds-custom--layout--size-${size}`]: !!size
		});
		return href ? html`
          <a
            id="button"
            role="button"
            class="${classes}"
            download="${ifDefined(download)}"
            href="${ifDefined(href)}"
            hreflang="${ifDefined(hreflang)}"
            ping="${ifDefined(ping)}"
            rel="${ifDefined(rel)}"
            target="${ifDefined(target)}"
            type="${ifDefined(type)}"
            @click="${this._handleClickLinkSkeleton}"></a>
        ` : html`
          <button
            id="button"
            class="${classes}"
            ?autofocus="${autofocus}"
            ?disabled="${disabled}"
            type="${ifDefined(type)}"></button>
        `;
	}
	static {
		this.styles = button_default;
	}
};
CDSButtonSkeleton = __decorate([carbonElement(`cds-custom-button-skeleton`)], CDSButtonSkeleton);
var button_skeleton_default = CDSButtonSkeleton;
//#endregion
export { button_skeleton_default as default };

//# sourceMappingURL=button-skeleton.js.map