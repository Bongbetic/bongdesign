/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import AutoAlignMixin from "../../globals/mixins/auto-align.js";
import button_default from "../button/button.scss.js";
import button_default$1 from "../button/button.js";
import icon_button_default$1 from "./icon-button.scss.js";
import tooltip_default from "../tooltip/tooltip.scss.js";
import "../tooltip/index.js";
import "../button/index.js";
import { ICON_BUTTON_SIZE, ICON_BUTTON_TOOLTIP_ALIGNMENT } from "./defs.js";
import { adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/icon-button/icon-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Icon Button
*
* @element cds-custom-icon-button
*/
let CDSIconButton = class CDSIconButton extends AutoAlignMixin(button_default$1) {
	constructor(..._args) {
		super(..._args);
		this.align = "top";
		this.closeOnActivation = true;
		this.defaultOpen = false;
		this.enterDelayMs = 100;
		this.leaveDelayMs = 100;
		this.size = "lg";
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [
			tooltip_default,
			button_default,
			icon_button_default$1
		]);
	}
	updated(changedProperties) {
		super.updated?.(changedProperties);
		if (changedProperties) {
			this.shadowRoot?.querySelector(`cds-custom-tooltip`)?.shadowRoot?.querySelector(`.cds-custom--tooltip`)?.classList.add(`cds-custom--icon-tooltip`);
			const tooltipContent = this.querySelector("[slot=tooltip-content]")?.textContent;
			this.shadowRoot?.querySelector(`cds-custom-tooltip`)?.querySelector(`button`)?.setAttribute("aria-label", String(tooltipContent));
		}
	}
	_renderTooltipContent() {
		return html`
      <cds-custom-tooltip-content ?hidden=${this.disabled}>
        <slot name="tooltip-content"></slot>
      </cds-custom-tooltip-content>
    `;
	}
	render() {
		const { align, autoalign, closeOnActivation, defaultOpen, enterDelayMs, leaveDelayMs } = this;
		return html`
      <cds-custom-tooltip
        .autoalign=${autoalign}
        align=${align}
        ?defaultOpen=${defaultOpen}
        ?closeOnActivation=${closeOnActivation}
        enter-delay-ms=${enterDelayMs}
        leave-delay-ms=${leaveDelayMs}
        .dropShadow=${false}>
        ${super.render()} ${this._renderTooltipContent()}
      </cds-custom-tooltip>
    `;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSIconButton.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSIconButton.prototype, "autoalign", void 0);
__decorate([property({
	attribute: "close-on-activation",
	reflect: true,
	type: Boolean
})], CDSIconButton.prototype, "closeOnActivation", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSIconButton.prototype, "defaultOpen", void 0);
__decorate([property({
	attribute: "enter-delay-ms",
	type: Number
})], CDSIconButton.prototype, "enterDelayMs", void 0);
__decorate([property({
	attribute: "leave-delay-ms",
	type: Number
})], CDSIconButton.prototype, "leaveDelayMs", void 0);
__decorate([property({ reflect: true })], CDSIconButton.prototype, "size", void 0);
CDSIconButton = __decorate([carbonElement(`cds-custom-icon-button`)], CDSIconButton);
var icon_button_default = CDSIconButton;
//#endregion
export { ICON_BUTTON_SIZE, ICON_BUTTON_TOOLTIP_ALIGNMENT, icon_button_default as default };

//# sourceMappingURL=icon-button.js.map