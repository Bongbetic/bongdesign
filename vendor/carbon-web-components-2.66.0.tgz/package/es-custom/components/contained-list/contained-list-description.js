/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import contained_list_default from "./contained-list.scss.js";
import { LitElement, html } from "lit";
//#region src/components/contained-list/contained-list-description.ts
/**
* Copyright IBM Corp. 2022, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Contained list description text.
*
* @element cds-custom-contained-list-description
* @slot - The description text content
*/
let CDSContainedListDescription = class CDSContainedListDescription extends LitElement {
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = contained_list_default;
	}
};
CDSContainedListDescription = __decorate([carbonElement(`cds-custom-contained-list-description`)], CDSContainedListDescription);
var contained_list_description_default = CDSContainedListDescription;
//#endregion
export { contained_list_description_default as default };

//# sourceMappingURL=contained-list-description.js.map