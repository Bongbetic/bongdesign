/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import textarea_default from "../textarea/textarea.js";
import fluid_textarea_default$1 from "./fluid-textarea.scss.js";
import { html } from "lit";
//#region src/components/fluid-textarea/fluid-textarea.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-textarea
*/
let CDSFluidTextArea = class CDSFluidTextArea extends textarea_default {
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	render() {
		return html`
      <div class="${"cds-custom"}--text-area--fluid ${"cds-custom"}--form-item">
        ${super.render()}
      </div>
    `;
	}
	static {
		this.styles = [textarea_default.styles, fluid_textarea_default$1];
	}
};
CDSFluidTextArea = __decorate([carbonElement(`cds-custom-fluid-textarea`)], CDSFluidTextArea);
var fluid_textarea_default = CDSFluidTextArea;
//#endregion
export { fluid_textarea_default as default };

//# sourceMappingURL=fluid-textarea.js.map