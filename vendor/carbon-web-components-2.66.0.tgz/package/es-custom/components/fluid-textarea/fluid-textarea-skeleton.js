/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import textarea_skeleton_default from "../textarea/textarea-skeleton.js";
import fluid_textarea_default from "./fluid-textarea.scss.js";
import { html } from "lit";
//#region src/components/fluid-textarea/fluid-textarea-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area skeleton.
*
* @element cds-custom-fluid-textarea-skeleton
*/
let CDSFluidTextareaSkeleton = class CDSFluidTextareaSkeleton extends textarea_skeleton_default {
	render() {
		return html`
      <div class="${"cds-custom"}--text-area--fluid__skeleton ${"cds-custom"}--form-item">
        ${super.render()}
      </div>
    `;
	}
	static {
		this.styles = [textarea_skeleton_default.styles, fluid_textarea_default];
	}
};
CDSFluidTextareaSkeleton = __decorate([carbonElement(`cds-custom-fluid-textarea-skeleton`)], CDSFluidTextareaSkeleton);
var fluid_textarea_skeleton_default = CDSFluidTextareaSkeleton;
//#endregion
export { fluid_textarea_skeleton_default as default };

//# sourceMappingURL=fluid-textarea-skeleton.js.map