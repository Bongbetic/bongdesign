/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import modal_label_default from "../modal/modal-label.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/dialog/dialog-subtitle.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog subtitle.
*
* @element cds-custom-dialog-subtitle
*/
let CDSDialogSubtitle = class CDSDialogSubtitle extends modal_label_default {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--dialog-subtitle--id-${Math.random().toString(16).slice(2)}`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = dialog_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSDialogSubtitle.prototype, "id", void 0);
CDSDialogSubtitle = __decorate([carbonElement(`cds-custom-dialog-subtitle`)], CDSDialogSubtitle);
var dialog_subtitle_default = CDSDialogSubtitle;
//#endregion
export { dialog_subtitle_default as default };

//# sourceMappingURL=dialog-subtitle.js.map