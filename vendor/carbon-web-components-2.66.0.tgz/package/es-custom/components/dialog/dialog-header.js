/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import { LitElement, html } from "lit";
//#region src/components/dialog/dialog-header.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog header.
*
* @element cds-custom-dialog-header
*/
let CDSDialogHeader = class CDSDialogHeader extends LitElement {
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = dialog_default;
	}
};
CDSDialogHeader = __decorate([carbonElement(`cds-custom-dialog-header`)], CDSDialogHeader);
var dialog_header_default = CDSDialogHeader;
//#endregion
export { dialog_header_default as default };

//# sourceMappingURL=dialog-header.js.map