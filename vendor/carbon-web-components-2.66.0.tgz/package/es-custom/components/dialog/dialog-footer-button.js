/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import button_default from "../button/button.scss.js";
import button_default$1 from "../button/button.js";
import dialog_default from "./dialog.scss.js";
//#region src/components/dialog/dialog-footer-button.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog footer button.
*
* @element cds-custom-dialog-footer-button
*/
let CDSDialogFooterButton = class CDSDialogFooterButton extends button_default$1 {
	static {
		this.styles = [button_default, dialog_default];
	}
};
CDSDialogFooterButton = __decorate([carbonElement(`cds-custom-dialog-footer-button`)], CDSDialogFooterButton);
var dialog_footer_button_default = CDSDialogFooterButton;
//#endregion
export { dialog_footer_button_default as default };

//# sourceMappingURL=dialog-footer-button.js.map