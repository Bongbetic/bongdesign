/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "./dialog.js";
import "./dialog-body.js";
import "./dialog-close-button.js";
import "./dialog-controls.js";
import "./dialog-footer.js";
import "./dialog-footer-button.js";
import "./dialog-header.js";
import "./dialog-subtitle.js";
import "./dialog-title.js";
