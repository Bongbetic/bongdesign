/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import modal_body_default from "../modal/modal-body.js";
//#region src/components/dialog/dialog-body.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog body.
*
* @element cds-custom-dialog-body
*/
let CDSDialogBody = class CDSDialogBody extends modal_body_default {
	_getAriaLabelledBy() {
		const dialog = this.closest(`cds-custom-dialog`);
		if (!dialog) return null;
		const subTitleEl = dialog.querySelector(`cds-custom-dialog-subtitle`);
		if (subTitleEl?.id) return subTitleEl.id;
		const titleEl = dialog.querySelector(`cds-custom-dialog-title`);
		if (titleEl?.id) return titleEl.id;
		return null;
	}
	_parentHasScrollingContent() {
		return this.closest(`cds-custom-dialog`)?.hasAttribute("has-scrolling-content") ?? false;
	}
	static {
		this.styles = dialog_default;
	}
};
CDSDialogBody = __decorate([carbonElement(`cds-custom-dialog-body`)], CDSDialogBody);
var dialog_body_default = CDSDialogBody;
//#endregion
export { dialog_body_default as default };

//# sourceMappingURL=dialog-body.js.map