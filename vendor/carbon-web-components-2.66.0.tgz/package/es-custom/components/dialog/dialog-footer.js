/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import modal_footer_default from "../modal/modal-footer.js";
//#region src/components/dialog/dialog-footer.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog footer.
*
* @element cds-custom-dialog-footer
*/
let CDSDialogFooter = class CDSDialogFooter extends modal_footer_default {
	/**
	* A selector that selects the child buttons.
	*/
	static get selectorButtons() {
		return `cds-custom-button,cds-custom-dialog-footer-button`;
	}
	static {
		this.styles = dialog_default;
	}
};
CDSDialogFooter = __decorate([carbonElement(`cds-custom-dialog-footer`)], CDSDialogFooter);
var dialog_footer_default = CDSDialogFooter;
//#endregion
export { dialog_footer_default as default };

//# sourceMappingURL=dialog-footer.js.map