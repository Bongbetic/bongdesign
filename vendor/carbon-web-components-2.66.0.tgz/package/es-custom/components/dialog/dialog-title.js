/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import modal_heading_default from "../modal/modal-heading.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/dialog/dialog-title.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog title.
*
* @element cds-custom-dialog-title
*/
let CDSDialogTitle = class CDSDialogTitle extends modal_heading_default {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--dialog-title--id-${Math.random().toString(16).slice(2)}`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = dialog_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSDialogTitle.prototype, "id", void 0);
CDSDialogTitle = __decorate([carbonElement(`cds-custom-dialog-title`)], CDSDialogTitle);
var dialog_title_default = CDSDialogTitle;
//#endregion
export { dialog_title_default as default };

//# sourceMappingURL=dialog-title.js.map