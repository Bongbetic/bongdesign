/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { carbonElement } from "../../globals/decorators/carbon-element.js";
import __decorate from "../../_virtual/_@oxc-project_runtime@0.149.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import dialog_default from "./dialog.scss.js";
import modal_close_button_default from "../modal/modal-close-button.js";
import { html } from "lit";
import { ifDefined } from "lit/directives/if-defined.js";
import Close20 from "@carbon/icons/es/close/20.js";
//#region src/components/dialog/dialog-close-button.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog close button.
*
* @element cds-custom-dialog-close-button
* @csspart button The button.
* @csspart close-icon The close icon.
*/
let CDSDialogCloseButton = class CDSDialogCloseButton extends modal_close_button_default {
	render() {
		const { closeButtonLabel } = this;
		return html`
      <cds-custom-icon-button
        part="button"
        align="left"
        enter-delay-ms=""
        aria-label="${ifDefined(closeButtonLabel)}"
        kind="ghost"
        size="lg"
        leave-delay-ms="">
        ${iconLoader(Close20, {
			slot: "icon",
			part: "close-icon",
			class: `cds-custom--dialog-close__icon`
		})}
        <span slot="tooltip-content">${closeButtonLabel}</span>
      </cds-custom-icon-button>
    `;
	}
	static {
		this.styles = dialog_default;
	}
};
CDSDialogCloseButton = __decorate([carbonElement(`cds-custom-dialog-close-button`)], CDSDialogCloseButton);
var dialog_close_button_default = CDSDialogCloseButton;
//#endregion
export { dialog_close_button_default as default };

//# sourceMappingURL=dialog-close-button.js.map